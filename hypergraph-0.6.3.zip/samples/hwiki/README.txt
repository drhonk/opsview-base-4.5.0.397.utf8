--------------------------------------------------------------------------
Installation of the Hypergraph JspWiki-Plugin
--------------------------------------------------------------------------

The distribution contains the following files for the JSPWiki-Plugin :

/lib/hwiki/hyperwiki.jar :
	This is the jar that contains the actual applet.
	This jar has to be copied into the root directory of the JSPWiki installation.
	(The directory where all the *.jsp files are located).

/lib/hwiki/hyperwikiPlugin.jar :
	This jar contains the plugin class : 
	"hypergraph.application.hwiki.HBreadcrumbJspWikiPlugin.class"
	This class creates the HTML code to start the plugin.
	It has to be in the same directory where the JSPWiki jars are, usually WEB-INF\lib.
	
/lib/hwiki/log4j.jar,
/lib/hwiki/McKessonApsWikiPlugins.jar :
	Both classes are needed to start the plugin.
	The JSPWiki distribution also contains a log4j.jar,
	but you have to use the jar in this distribution for the correct log4j version.
	It has to be in the same directory where the JSPWiki jars are, usually WEB-INF\lib.

--------------------------------------------------------------------------
Usage of the Hypergraph JspWiki-Plugin in a page
--------------------------------------------------------------------------

The plugin can be used in two different ways.
The first is to show the links from any given page,
the other to show the breadcrumbs and links starting at the breadcrumb pages.

Description of the available parameters :

xmlrpc		The url of the wiki XmlRpc service, for example http://www.jspwiki.org/RPCU/.
startPage	The page if you only want to show the links starting in one page.
			If you want to show the breadcrumb, don't provide this parameter.
width		The width of the applet.
height		The height of the applet.

Example :

[{hypergraph.applications.hwiki.HWikiJspWikiPlugin xmlrpc='http://www.jspwiki.org/RPCU/' startPage='Main' width='600' height='400'}]
This creates an applet of 600 * 400 pixels that shows the links starting at page "Main".

[{hypergraph.applications.hwiki.HWikiJspWikiPlugin xmlrpc='http://www.jspwiki.org/RPCU/' width='600' height='400'}]
This creates an applet of 600 * 400 pixels that shows the current breadcrumb and it's links.
