                            README
                            
     Hypergraph - visualization of graphs in hyperbolic space
                         Version 0.6.3

Hypergraph is an open source software project to visualize the hyperbolic space 
using java swing components and to visualize graphs in the hyperbolic space. 
The source code as well as some documentation and examples can be found on
      
                  http://hypergraph.sourceforge.net

Installation procedure :
This distribution contains an ant build file ("build.xml") which is used to
compile the code, create a javadoc documentation and to build the jar file
for the example applet "hypergraph.applications.hexplorer.HExplorerApplet".
To use this file, you need a version of the apache ant utility which can be downloaded from
http://ant.apache.org. After installation of ant, simply call "ant" 
in the path where you unzipped the hypergraph distribution. This will give
you some help on the targets that can be used.

System requirements :
The software uses swing and the xml classes in java. 
Therefore a java runtime environment version 1.4.2 or higher is necessary.

License :
This version is under the GNU Lesser General Public License (LGPL). In the distribution
that contained this file, there should also be a file LICENSE.txt which 
contains the full text of the GNU Lesser General Public License. If this is not the
case, please mail to JensKanschik@users.sourceforge.net 

