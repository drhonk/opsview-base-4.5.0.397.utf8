/*
 *  Copyright (C) 2003  Jens Kanschik,
 * 	mail : jensKanschik@users.sourceforge.net
 *
 *  Part of <hypergraph>, an open source project at sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
package hypergraph.applications.tm;

import hypergraph.graphApi.Edge;
import hypergraph.graphApi.Element;
import hypergraph.graphApi.Graph;
import hypergraph.graphApi.GraphException;
import hypergraph.graphApi.GraphSystem;
import hypergraph.graphApi.GraphSystemFactory;
import hypergraph.graphApi.Group;
import hypergraph.graphApi.Node;
import hypergraph.graphApi.algorithms.GraphUtilities;
import hypergraph.visualnet.GraphPanel;

import java.awt.Color;
import java.util.Iterator;
import java.util.Set;

import org.tmapi.core.Association;
import org.tmapi.core.AssociationRole;
import org.tmapi.core.Topic;
import org.tmapi.core.TopicMap;
import org.tmapi.core.TopicName;

/**
 * @author Jens Kanschik
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TMGraph {

	/** The graph which represents the topicmap. */
	private Graph graph;
		
	// groups for different types of nodes :
	private Group		assocNode;
	private Group		topicNode;
	
	// groups for different types of edges :
	private Group		scopeEdge;
	private Group		instanceEdge;
	private Group		memberEdge;
	
	// stores the scope(s) for the map; null = unconstrained
	private Set			scopes;
	
	private TopicMap	topicMap;
	
	public TMGraph(TopicMap tm) {
		topicMap = tm;

		GraphSystem graphSystem = null;
		try {
			graphSystem = GraphSystemFactory.createGraphSystem("hypergraph.graph.GraphSystemImpl",null); 
		} catch (Exception e) {
			e.printStackTrace();
		}
		graph = graphSystem.createGraph();

		
		assocNode		= graph.createGroup();
		topicNode		= graph.createGroup();
		memberEdge		= graph.createGroup();
		scopeEdge		= graph.createGroup();
		instanceEdge	= graph.createGroup();
		
		float[] instanceStroke = {1,2};
		
		graph.getAttributeManager().setAttribute(GraphPanel.NODE_ICON,topicNode,null);
		graph.getAttributeManager().setAttribute(GraphPanel.NODE_FOREGROUND,topicNode,Color.BLACK);

//		graph.getAttributeManager().setAttribute(GraphPanel.NODE_ICON,assocNode,new ImageIcon("hypergraph/applications/tm/assoc.gif"));
		graph.getAttributeManager().setAttribute(GraphPanel.NODE_FOREGROUND,assocNode,Color.GRAY);

		graph.getAttributeManager().setAttribute(GraphPanel.EDGE_LINECOLOR,memberEdge,new Color(230,230,230));
		graph.getAttributeManager().setAttribute(GraphPanel.EDGE_TEXTCOLOR,memberEdge, new Color(240,240,240));
//		graph.getAttributeManager().setAttribute(GraphPanel.EDGE_STROKE,memberEdge,memberStroke);

		graph.getAttributeManager().setAttribute(GraphPanel.EDGE_LINECOLOR,instanceEdge,Color.GRAY);
		graph.getAttributeManager().setAttribute(GraphPanel.EDGE_STROKE,instanceEdge,instanceStroke);
		
		// first create all nodes for the topics, but not yet edges for instances
		Set topics = tm.getTopics();
		for (Iterator iter = topics.iterator(); iter.hasNext();) {
			Topic t = (Topic) iter.next();
			try {
				Node n = graph.createNode(t.getObjectId());
				n.setGroup(topicNode);
				n.setLabel(createLabel(t));
//				if (!t.getBaseNames().isEmpty())
//					n.setLabel(((BaseName) t.getBaseNames().iterator().next()).getNameString());
			} catch (GraphException ge) {
				ge.printStackTrace();
			}
		}
		// now the edges for instances
//		for (Iterator iter = topics.iterator(); iter.hasNext();) {
//			Topic topic = (Topic) iter.next();
//			Node n1 = (Node) getElement(topic.getObjectId());
//			Set types = topic.getTypes();
//			for (Iterator t = types.iterator(); t.hasNext();) {
//				String id = ((Topic) t.next()).getObjectId();
//				Node n2 = (Node) getElement(id);
//				Edge edge = createEdge(n1, n2);
//				edge.setGroup(instanceEdge);
//			}
//		}

		// create all nodes for associations together with the edges
		Set associations = tm.getAssociations();
		for (Iterator iter = associations.iterator(); iter.hasNext();) {
			Association a = (Association) iter.next();
			createAssociationEdge(a);
		}
		// remove all discrete nodes
		Set c = GraphUtilities.getConnectedComponents(graph);
		for (Iterator i = c.iterator(); i.hasNext();) {
			Set comp = (Set) i.next();
			if (comp.size() == 1)
				graph.removeElement(((Element) comp.iterator().next()));
		}
	}

	public Graph getGraph() {
		return graph;
	}
	String getRoleName(AssociationRole member) {
		Topic role = member.getType();
		Topic type = member.getAssociation().getType();
		if (type == null)
			return null;
		String defaultName = null;
		Set baseNames = type.getTopicNames();
		if (baseNames == null)
			return null;
		for (Iterator i = baseNames.iterator(); i.hasNext();) {
			TopicName topicName = (TopicName) i.next();
			if (topicName.getScope().contains(role))
				return topicName.getValue();
			if (topicName.getScope().isEmpty())
				defaultName = topicName.getValue();
		}
		return defaultName;
	}
	String createLabel(Topic topic) {
		Set names = topic.getTopicNames();
		StringBuffer buf = new StringBuffer();
		for (Iterator i = names.iterator(); i.hasNext();) {
			TopicName name = (TopicName) i.next();
			boolean showName = false;
			if (scopes == null)
				showName = true;
			// TODO : Check scopes.
			if (showName)
				buf.append(name.getValue() + " ");				
		}
		if (buf.length() == 0)
			buf.append(topic.getObjectId());
		return buf.toString();
	}

	public void createAssociationEdge(Association assoc) {
		Node n = null;
		try {
			if (assoc.getAssociationRoles().size() == 2) {
				Iterator m = assoc.getAssociationRoles().iterator();
				AssociationRole m1 = (AssociationRole) m.next();
				AssociationRole m2 = (AssociationRole) m.next();
				AssociationEdge edge = new AssociationEdge(
											assoc.getObjectId(),
											(Node) graph.getElement(m1.getPlayer().getObjectId()),
											(Node) graph.getElement(m2.getPlayer().getObjectId()));
				graph.addElement(edge);
				edge.setGroup(memberEdge);
				edge.setLabel(getRoleName(m1));
				edge.setTooltip(
					createLabel(m1.getPlayer())
					+ getRoleName(m1) + " "
					+ createLabel(m2.getPlayer())
					+ "   |   "
					+ createLabel(m2.getPlayer())
					+ getRoleName(m2) + " "
					+ createLabel(m1.getPlayer())
					);
			} else {
//				Topic type = assoc.getType();
				n = graph.createNode(assoc.getObjectId());
				n.setGroup(assocNode);
				n.setLabel(createLabel(assoc.getType()));
//				n.setLabel("");
				for (Iterator m = assoc.getAssociationRoles().iterator(); m.hasNext();) {
					AssociationRole member = (AssociationRole) m.next();
					Edge edge = graph.createEdge(n, (Node) graph.getElement(member.getPlayer().getObjectId()));
					edge.setGroup(memberEdge);
					edge.setLabel(getRoleName(member));
				}
//				if (type != null) {
//					Node typeNode = (Node) getElement(type.getObjectId());
//					Edge edge = createEdge(n, typeNode);
//					edge.setGroup(instanceEdge);
//				}
			}
		} catch (GraphException ge) {
			ge.printStackTrace();
		}
	}
}
