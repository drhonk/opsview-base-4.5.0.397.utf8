/*
 *  Copyright (C) 2003  Jens Kanschik,
 * 	mail : jensKanschik@users.sourceforge.net
 *
 *  Part of <hypergraph>, an open source project at sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package hypergraph.applications.tm;

import hypergraph.graphApi.AttributeManager;
import hypergraph.graphApi.Element;
import hypergraph.graphApi.Node;
import hypergraph.visualnet.GenericMDSLayout;
import hypergraph.visualnet.MDSWeight;

import javax.swing.JApplet;

import java.applet.AppletContext;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.net.URL;


/**
 * @author Jens Kanschik
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TMPanel extends hypergraph.visualnet.GraphPanel {

	private static String	homepageUrl = "http://hypergraph.sourceforge.net";
	private JApplet			explorer;


	public TMPanel(TMGraph tmg, JApplet explorer) {
		super(tmg.getGraph());
		this.explorer = explorer;
		MDSWeight weights = new MDSWeight();
		weights.setGraph(tmg.getGraph());
		setGraphLayout(new GenericMDSLayout(null, getModel(), tmg.getGraph(), getPropertyManager()));
		getEdgeRenderer().setLabelVisible(true);
	}

	public void setHoverElement(Element element, boolean repaint) {
		if (getHoverElement() != element) {
			if (element == null) {
				AppletContext context = explorer.getAppletContext();
				context.showStatus("");
				setToolTipText(null);
			}
			// show a tooltip (xlink:href) if the element is a node
			if (element != null && element.getElementType() == Element.NODE_ELEMENT) {
				AppletContext context = explorer.getAppletContext();
				AttributeManager attrMgr = getGraph().getAttributeManager();
				String href = (String) attrMgr.getAttribute("xlink:href", element);
				if (href == null)
					href = "No reference";
				context.showStatus(href);
				setToolTipText(href);
			}
			// do something different if the element is an edge
			if (element != null && element.getElementType() == Element.EDGE_ELEMENT) {
				setToolTipText(((AssociationEdge) element).getTooltip());
			}
		}
		super.setHoverElement(element, repaint);
		if (getHoverElement() == null)
			explorer.getAppletContext().showStatus("");
	}
	protected void logoClicked(MouseEvent e) {
		super.logoClicked(e);
	    try {
			explorer.getAppletContext().showDocument(
	    		new URL(homepageUrl));
	    } catch (MalformedURLException mue) {}
	}

	public void mouseMoved(MouseEvent e) {
		super.mouseMoved(e);
		if (isOnLogo(e.getPoint()))
			explorer.getAppletContext().showStatus(homepageUrl);
	}
	public void nodeClicked(int clickCount, Node node) {
		super.nodeClicked(clickCount, node);
		if (clickCount == 2) {
			AttributeManager attrMgr = getGraph().getAttributeManager();
			String href = (String) attrMgr.getAttribute("xlink:href", node);
			String target = getPropertyManager().getString("hypergraph.applications.hexplorer.GraphPanel.target");
			if (target == null)
				target = "_top";
			try {
				URL url = new URL(explorer.getDocumentBase(), href);
				AppletContext context = explorer.getAppletContext();
				context.showDocument(url, target);
			} catch (Exception ex) {
				System.out.println(ex);
			}
		}
	}

}
