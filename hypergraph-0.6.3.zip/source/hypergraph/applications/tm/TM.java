/*
 *  Copyright (C) 2003  Jens Kanschik,
 * 	mail : jensKanschik@users.sourceforge.net
 *
 *  Part of <hypergraph>, an open source project at sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package hypergraph.applications.tm;

import hypergraph.visualnet.GraphPanel;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;

import javax.swing.JApplet;
import javax.swing.JOptionPane;

import org.tinyTIM.TopicMapSystemImpl;
import org.tinyTIM.XTMParser;
import org.tmapi.core.TopicMap;
import org.tmapi.core.TopicMapSystem;
import org.xml.sax.SAXException;

/**
 * @author Jens Kanschik
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class TM extends JApplet {

	TopicMap tm;
	TopicMapSystem tSystem;

	public TopicMap parse(URL url) throws Exception{
		return parse(url.openStream());
	}
	public TopicMap parse(InputStream is) throws Exception{
		tSystem  =   new TopicMapSystemImpl();
		XTMParser xtmP = new XTMParser(tSystem);
		tm  =   xtmP.parse(is);
		return tm;
	}

	 public void init() {
		String file = getParameter("file");
//		if (file == null)
//			file = JOptionPane.showInputDialog("Please entered the URL to start with :");
		if (file == null || file.length() == 0)
//			file = "hypergraph/applications/tm/resource/tests/music-xtm.xml";
//			file = "hypergraph/applications/tm/resource/tests/opera-xtm.xml";
//		file = "hypergraph/applications/tm/hugeproject.xtm";
//		file = "hypergraph/applications/tm/country.xtm";
//		file = "hypergraph/applications/tm/opera.xtm";
		file = "hypergraph/applications/tm/tmworld.xtm";
//		file = "hypergraph/applications/tm/kings_and_queens.xtm";
//		file = "hypergraph/applications/tm/ned1.xtm";
//		file = "hypergraph/applications/tm/blockworld.xtm";
//			file = "topicmaps/blockworld.xtm";
//			file = "hypergraph/applications/tm/resource/tests/kings_and_queens.xtm";
//			file = "hypergraph/applications/tm/tmworld.xtm";
//			file = "hypergraph/applications/tm/sitemap.xtm";

		URL url = null;
		try {
			url = new URL(getCodeBase(), file);
			tm = parse(url);
		} catch (FileNotFoundException fnfe) {
			JOptionPane.showMessageDialog(null,
				"Could not find file " + url.getFile() + ". \n" +
				"Start applet with default graph", "File not found", JOptionPane.ERROR_MESSAGE);
			System.out.println("Exception : " + fnfe);
			fnfe.printStackTrace(System.out);
		} catch (SAXException saxe) {
			JOptionPane.showMessageDialog(null,
				"Error while parsing file" + url.getFile() + ". \n" +
				"Exception : " + saxe + ". \n" +
				"Start applet with default graph", "Parsing error", JOptionPane.ERROR_MESSAGE);
			System.out.println("Exception : " + saxe);
			saxe.getException().printStackTrace();
			saxe.printStackTrace(System.out);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, 
				"General error while reading file " + url.getFile() + ". \n" +
				"Exception : " + e + ". \n" +
				"Start applet with default graph", "General error", JOptionPane.ERROR_MESSAGE);
			System.out.println(url);
			System.out.println("Exception : " + e);
			e.printStackTrace(System.out);
		}

		GraphPanel graphPanel = new TMPanel(new TMGraph(tm), this);

		getContentPane().add(graphPanel);
	 }
}