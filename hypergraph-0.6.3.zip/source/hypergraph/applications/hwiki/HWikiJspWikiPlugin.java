/*
 *  Copyright (C) 2003  Jens Kanschik,
 * 	mail : jensKanschik@users.sourceforge.net
 *
 *  Part of <hypergraph>, an open source project at sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
package hypergraph.applications.hwiki;

/**
 * @author Jens Kanschik
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Category;

import com.ecyrd.jspwiki.WikiContext;
import com.ecyrd.jspwiki.plugin.WikiPlugin;
import com.mckessonaps.jspwiki.plugin.util.ParamUtil;

public class HWikiJspWikiPlugin implements WikiPlugin
{
    private static final Category   log = Category.getInstance(HWikiJspWikiPlugin.class);

    private WikiContext	_context;
    private Map			_params;
    
    // FIXME We should use the constant from com.ecyrd.jspwiki.tags.BreadcrumbsTag,
    // but it's a private constant there.
    public static final String BREADCRUMBTRAIL_KEY = "breadCrumbTrail";
    
    /**
     * Return and APPLET tag
     * @see com.ecyrd.jspwiki.plugin.WikiPlugin#execute(com.ecyrd.jspwiki.WikiContext, java.util.Map)
     */
    public String execute(WikiContext context, Map params)
    {
    	log.debug("Execution of plugin started.");
    	
    	_context = context;
    	_params = params;
    	
        String xmlrpcUrl = ParamUtil.getString(null, params, "xmlrpc", guessXmlRpcUrl(context));
        if (null == xmlrpcUrl) 
            return "You must provide the 'xmlrpc' parameter.";
        
        String width = ParamUtil.getString(null, params, "width", "500");
        String height = ParamUtil.getString(null, params, "height", "200");
        String startPage = ParamUtil.getString(null, params, "startPage", null);

        String pages = startPage;
        if (pages == null)
        	pages = getPages();
        if (pages.length() == 0)
        	return "";
        
        StringBuffer buffer = new StringBuffer();
        buffer.append( "<APPLET ");
        buffer.append( "code=\"hypergraph.applications.hwiki.HWikiApplet.class\" " );
        buffer.append( "archive=\"hyperwiki.jar\" ");
        buffer.append( "width=" + width + " height=" + height + " >\n");
        buffer.append( "<PARAM name=\"wikiURL\" value=\"" + xmlrpcUrl + "\" >\n");
        buffer.append( "<PARAM name=\"pages\" value=\"" + pages + "\" >\n");
        buffer.append( "Sorry, but your browser doesn't support Java Applets.\n" );
        buffer.append( "</APPLET>" );
        return buffer.toString();
    }

    private String getPages() {
        StringBuffer pages = new StringBuffer();
        String currentPage = _context.getPage().getName();
    	
    	log.debug("Retrieve breadcrumb page list.");
    	HttpServletRequest httpRequest = _context.getHttpRequest();
    	HttpSession httpSession = httpRequest.getSession();
        List trail = (List) httpSession.getAttribute(BREADCRUMBTRAIL_KEY);
        if (trail != null) {
        	log.debug("Got breadcrumb trail, number of breadcrumbs : " + trail.size());
            for (int i = 0; i < trail.size(); i++) {
            	log.debug("Breadcrumb number " + i + " = " + trail.get(i));
            	pages.append(trail.get(i));
            	pages.append("|");
            }
        } else
        	log.debug("There are no breadcrumbs");
    	log.debug("List of breadcrumb pages = " + pages);
    	return pages.toString();
    }
    
    private String guessXmlRpcUrl(WikiContext context)
    {
        String baseUrl = context.getEngine().getBaseURL();
        
        if (null == baseUrl || "".equals( baseUrl ))
            return null;
        else
            return baseUrl + "/RPC2/";
    }

    
}
