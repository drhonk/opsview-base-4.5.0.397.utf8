/*
 *  Copyright (C) 2003  Jens Kanschik,
 * 	mail : jensKanschik@users.sourceforge.net
 *
 *  Part of <hypergraph>, an open source project at sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package hypergraph.applications.hwiki;

import hypergraph.graphApi.AttributeManager;
import hypergraph.graphApi.Edge;
import hypergraph.graphApi.Graph;
import hypergraph.graphApi.GraphException;
import hypergraph.graphApi.GraphSystem;
import hypergraph.graphApi.GraphSystemFactory;
import hypergraph.graphApi.Group;
import hypergraph.graphApi.Node;
import hypergraph.visualnet.ArrowLineRenderer;
import hypergraph.visualnet.ForceDirectedWeight;
import hypergraph.visualnet.GenericMDSLayout;
import hypergraph.visualnet.GraphLayout;

import java.awt.Color;
import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.JApplet;
import javax.swing.JOptionPane;

import org.apache.xmlrpc.XmlRpcClient;

/**
 * @author Jens Kanschik
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class HWikiApplet extends JApplet {
	
	private static Graph	graph;
	
	private static Group	groupNew;
	private static Group	groupPending;
	private static Group	groupDone;
	private static Group	groupFail;
	private static Group	groupBreadcrumb;
	
	private static final String LISTLINKS = "wiki.listLinks";
	
	//private String			clientName = "http://www.jspwiki.org/RPCU/";
	private String			clientName = "http://localhost:3035/JSPWiki/RPC2/";
	private String			jspWikiUrl = "http://localhost:3035/JSPWiki/";
	
	private List startPages;
	
	public void init() {
	
		// Read parameters
		String startPage = getParameter("startPage");
		String pages = getParameter("pages");
		String wiki = getParameter("wikiURL");
		// Show Main page and links of this page as default
		if (startPage == null && pages == null)
			startPage = "Main";
	
		startPages = getStartPages(startPage, pages);
		
		initGraph();
		
		GraphPanel graphPanel = new GraphPanel(graph, this);
		
		String file = getParameter("properties");
		URL url = null;
		if (file != null) 
			try {
				url = new URL(getCodeBase(), file);	
				graphPanel.loadProperties(url.openStream());
			}
		catch(FileNotFoundException fnfe){
			JOptionPane.showMessageDialog(null, 
					"Could not find propertyfile " + url.getFile() + ". \n" +
					"Start applet with default properties", "File not found", JOptionPane.ERROR_MESSAGE);
		}
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, 
					"General error while reading file " + url.getFile() + ". \n" +
					"Exception : " + e + ". \n" +
					"Start applet with default properties", "General error", JOptionPane.ERROR_MESSAGE);
			System.out.println(url);
			System.out.println("Exception : " + e);
			e.printStackTrace(System.out);
		}
		
		graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.repulsingForce",new Double(0.05));
		graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.repulsingForceCutOff",new Double(5));
		graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.connectedDisparity",new Double(0.2));
		
		GenericMDSLayout.MDSWeight weights = new ForceDirectedWeight();
		weights.setGraph(graph);
		GraphLayout layout = new GenericMDSLayout(null, graphPanel.getModel(), graph, graphPanel.getPropertyManager());
		graphPanel.setGraphLayout(layout);
		graphPanel.setLineRenderer(new ArrowLineRenderer());
		getContentPane().add(graphPanel);
	}

	public List getStartPages(String startPage, String pages) {
		List startPages = new ArrayList();
		
		if (pages != null) {
			StringTokenizer tokenizer = new StringTokenizer(pages, "|");
			while (tokenizer.hasMoreTokens()) {
				String page = tokenizer.nextToken();
				startPages.add(page);
			}
		} else
			if (startPage != null) {
				startPages.add(startPage);
		} else 
			startPages.add("Main");
		return startPages;
	}

	public void initGraph() {
		GraphSystem graphSystem = null;
		try {
			graphSystem = GraphSystemFactory.createGraphSystem("hypergraph.graph.GraphSystemImpl",null); 
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(8);
		}
		graph = graphSystem.createGraph();

		groupNew = graph.createGroup();
		groupPending = graph.createGroup();
		groupDone = graph.createGroup();
		groupFail = graph.createGroup();
		groupBreadcrumb = graph.createGroup();
		
		graph.getAttributeManager().setAttribute(GraphPanel.NODE_FOREGROUND, groupNew, Color.blue);
		graph.getAttributeManager().setAttribute(GraphPanel.NODE_FOREGROUND, groupPending, Color.green);
		graph.getAttributeManager().setAttribute(GraphPanel.NODE_FOREGROUND, groupFail, Color.red);
		graph.getAttributeManager().setAttribute(GraphPanel.NODE_FOREGROUND, groupDone, Color.black);
		graph.getAttributeManager().setAttribute(GraphPanel.EDGE_LINECOLOR, groupBreadcrumb, Color.red);

		Node previousPage = null;
		for (Iterator i = startPages.iterator(); i.hasNext(); ) {
			String page = (String) i.next();
			Node newPage = (Node) graph.getElement(page);
			if (newPage == null)
				try {
					newPage = graph.createNode(page);
				} catch (Exception e) {
					// ignore
				}
			if (previousPage != null) {
				Edge edge = graph.createEdge(previousPage, newPage);
				if (edge != null)
					edge.setGroup(groupBreadcrumb);
			}
			previousPage = newPage;
			addLinkedPages(page, 0);
		}
		
	}

	private XmlRpcClient getNewClient() throws MalformedURLException
	{
		URL url = null;
		try{
			url = new URL(getDocumentBase(), clientName);
			return new XmlRpcClient(url);
		} catch (Exception e) {
			System.out.println(url);
			System.out.println(clientName);
			e.printStackTrace();
		}
		return null;
	}
	
	
	public void addLinkedPages(final String page, final int level) {
		Runnable r = new Runnable() {
			public void run() {
				loadLinkedPages(page, level);
			}
		};
		Thread t = new Thread(r);
		t.start();
	}
	
	public void loadLinkedPages(String page, int level) {
		if (level < 0)
			return; 
		
		Vector args = new Vector(1);
		args.add(page);
		Node root = (Node) graph.getElement(page);
		if (root.getGroup() != null && !root.getGroup().equals(groupNew))
			return;
		root.setGroup(groupPending);
		AttributeManager attrMgr = graph.getAttributeManager();
		try {
			
			Vector list = (Vector) getNewClient().execute(LISTLINKS, args);
			
			for (int i = 0; i < list.size(); i++) {
				Hashtable item = (Hashtable) list.elementAt(i);
				String link = (String) item.get("page");
				String type = (String) item.get("type");
				String href = (String) item.get("href");
				if (type.equals("external"))
					continue;
				Node n = null;
				synchronized (graph) {
					n = (Node) graph.getElement(link);
					if (n == null) {
						try {
							n = graph.createNode(link);
							n.setGroup(groupNew);
						} catch (GraphException ge) {
							ge.printStackTrace();
						}
					}
					graph.createEdge(root, n);
				}
				try { 
					Thread.sleep(5);
				} catch (Exception e) {
					// ignore
				}
				if (n != null) {
					attrMgr.setAttribute("xlink:href", n, href);
					addLinkedPages(n.getName(), level - 1);
				}
			}
			root.setGroup(groupDone);
		} catch(Exception e) {
			root.setGroup(groupFail);
			System.out.println(page);
			System.out.println(clientName);
			e.printStackTrace();
		}
	}
	
	
	
}
