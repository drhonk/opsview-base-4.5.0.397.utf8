/*
 *  Copyright (C) 2003  Jens Kanschik,
 * 	mail : jensKanschik@users.sourceforge.net
 *
 *  Part of <hypergraph>, an open source project at sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package hypergraph.applications.google;

import hypergraph.graphApi.Graph;
import hypergraph.graphApi.GraphSystem;
import hypergraph.graphApi.GraphSystemFactory;
import hypergraph.visualnet.ForceDirectedWeight;
import hypergraph.visualnet.GenericMDSLayout;
import java.io.FileNotFoundException;
import java.net.URL;

import javax.swing.JApplet;
import javax.swing.JOptionPane;

/**
 * @author Jens Kanschik
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class HGoogleApplet extends JApplet {

static Graph graph;

 public void init() {
	GraphSystem graphSystem = null;
	try {
		graphSystem = GraphSystemFactory.createGraphSystem("hypergraph.graph.GraphSystemImpl",null); 
	} catch (Exception e) {
		e.printStackTrace();
		System.exit(8);
	}
	graph = graphSystem.createGraph();
	URL url = null;
	String urlString = JOptionPane.showInputDialog("Please entered the URL to start with :");
	if (urlString == null || urlString.length() == 0)
		urlString = "hypergraph.sourceforge.net";

	GraphPanel graphPanel = new GraphPanel(graph, this);
	graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.repulsingForce",new Double(0.1));
	graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.repulsingForceCutOff",new Double(5));
	graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.connectedDisparity",new Double(0.2));

	GenericMDSLayout.MDSWeight weights = new ForceDirectedWeight();
	weights.setGraph(graph);
	graphPanel.setGraphLayout(new GenericMDSLayout(null, graphPanel.getModel(), graph, graphPanel.getPropertyManager()));
//	GraphLayout layout = new GenericMDSLayout(null, graphPanel.getModel(), graph, graphPanel.getPropertyManager());
//	graphPanel.setGraphLayout(layout);
	graphPanel.addRelatedUrls(urlString, 0);
	String file = getParameter("properties");
	if (file != null) 
		try {
			url = new URL(getCodeBase(), file);	
			graphPanel.loadProperties(url.openStream());
		}
		catch(FileNotFoundException fnfe){
			JOptionPane.showMessageDialog(null, 
				"Could not find propertyfile " + url.getFile() + ". \n" +
				"Start applet with default properties", "File not found", JOptionPane.ERROR_MESSAGE);
		}
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, 
				"General error while reading file " + url.getFile() + ". \n" +
				"Exception : " + e + ". \n" +
				"Start applet with default properties", "General error", JOptionPane.ERROR_MESSAGE);
			System.out.println(url);
			System.out.println("Exception : " + e);
			e.printStackTrace(System.out);
		}
	getContentPane().add(graphPanel);
 }
}
