/*
 *  Copyright (C) 2003  Jens Kanschik,
 * 	mail : jensKanschik@users.sourceforge.net
 *
 *  Part of <hypergraph>, an open source project at sourceforge.net
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

package hypergraph.test;

import hypergraph.graphApi.AttributeManager;
import hypergraph.graphApi.Graph;
import hypergraph.graphApi.GraphSystem;
import hypergraph.graphApi.GraphSystemFactory;
import hypergraph.graphApi.Node;
import hypergraph.graphApi.algorithms.GraphUtilities;
import hypergraph.graphApi.algorithms.LayerAssignment;
import hypergraph.graphApi.io.ContentHandlerFactory;
import hypergraph.graphApi.io.GXLWriter;
import hypergraph.graphApi.io.GraphMLWriter;
import hypergraph.graphApi.io.GraphXMLWriter;
import hypergraph.graphApi.io.SAXReader;
import hypergraph.visualnet.GenericMDSLayout;
import hypergraph.visualnet.GraphPanel;
import hypergraph.visualnet.GraphSelectionEvent;
import hypergraph.visualnet.GraphSelectionListener;
import hypergraph.visualnet.GraphSelectionModel;

import java.net.URL;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.UIManager;

public class NetApplication implements GraphSelectionListener {
    static Graph graph;
    
    public void valueChanged(GraphSelectionEvent e) {
    	GraphSelectionModel gsm = (GraphSelectionModel) e.getSource();
    	Iterator i = gsm.getSelectionElementIterator();
    	if (i.hasNext()) {
    		Node node = (Node) i.next();
    		AttributeManager attrMgr = graph.getAttributeManager();
    		String href = (String) attrMgr.getAttribute("xlink:href",node);
//    		System.out.println(href);
    	}
    }
    public static void main(String[] args) {
//    	if (args.length == 0) {
//    		System.out.println("First parameter needs to be a valid URL");
//    		System.exit(8);
//    	}
    	NetApplication app = new NetApplication();
    	app.go(args);
    }
    public void go(String[] args) {
    	JFrame frame = new JFrame();
		UIManager.put("ModelPanelUI","hypergraph.hyperbolic.ModelPanelUI");
//		UIManager.put("ModelPanelUI","hypergraph.hyperbolic.HalfPlanePanelUI");
		GraphSystem graphSystem = null;
		try {
			graphSystem = GraphSystemFactory.createGraphSystem("hypergraph.graph.GraphSystemImpl",null); 
		} catch (Exception e) {
			e.printStackTrace();
			System.exit(8);
		}
		graph = null;
		try {
			URL url = new URL(args[0]);
			SAXReader reader = new SAXReader(graphSystem,url);
			reader.setContentHandlerFactory(new ContentHandlerFactory());
//			graph = reader.parse();
		} catch(Exception e){
			System.out.println("Exception : " + e);
			e.printStackTrace(System.out);
		} 
//		try {
//			URL url = new URL(args[0]);
//			DOMReader reader = new DOMReader(url);
//			graph = reader.parse();
//		} catch(Exception e){
//			System.out.println("Exception : " + e);
//			e.printStackTrace(System.out);
//		} 

		if (graph == null)
			//graph = ((GraphSystemImpl) graphSystem).createRandomGraph(10,0.7,0.01,0.3,0.01,100);
//		graph = ((GraphSystemImpl) graphSystem).createTree(5,3);
//		graph = ((GraphSystemImpl) graphSystem).createTreeDelayed(5,2,100);
//		graph = GraphUtilities.createGrid2(graphSystem, 10,10);
//		graph = ((GraphSystemImpl) graphSystem).createCompleteGraph(2);
//		graph = GraphFactory.createCompleteGraph(4);
//		graph.insertGraph(GraphFactory.createCompleteGraph(5));
//		graph.insertGraph(GraphFactory.createTree(2,2));
//		graph.insertGraph(GraphFactory.createGrid2(2,1));
//		graph.insertGraph(GraphFactory.createGrid2(5,20));
//		graph.insertGraph(GraphFactory.createTree(2,2));
//		graph.addNode(new Node("12"));
//		graph.addNode(new Node("asd12"));
		
//		graph = new DBReader().readFromDB();
		
//		if ( graph == null) 
//		graph = GraphFactory.createTreeDelayed(5,3,500);
		graph = GraphUtilities.createTree(graphSystem,5,2);
//		graph = GraphFactory.createGrid2(7,7);
//		graph = GraphFactory.createCompleteGraph(20);
//		graph = GraphFactory.createDiscreteGraph(20);
//		graph = TestLayoutAlgorithms.getExample2(graphSystem);

// write graph to file :
		try {
			new GraphXMLWriter("test-GraphXML.xml").write(graph);
			new GraphMLWriter("test-graphml.xml").write(graph);
			new GXLWriter("test-gxl.xml").write(graph);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
//		TestLayoutAlgorithms.makeAcyclic(graph);
		LayerAssignment la = new LayerAssignment();
		la.setGraph(graph);
		la.setCreateDummy(false);
	//	la.assignLayers(null, null);

		float[] stroke = {15,2,2,2,2,10};

    	GraphPanel graphPanel = new GraphPanel(graph);
		
		graph.getAttributeManager().setAttribute(GraphPanel.EDGE_STROKE, graph, stroke);
		
		graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.repulsingForce",new Double(0.05));
		graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.repulsingForceCutOff",new Double(5));
		graphPanel.getPropertyManager().setProperty("visualnet.GenericMDSLayout.connectedDisparity",new Double(0.3));

//		graphPanel.setGraphLayout(new TreeLayout(graph, graphPanel.getModel(), graphPanel.getPropertyManager()));
		graphPanel.setGraphLayout(new GenericMDSLayout(null, graphPanel.getModel(), graph, graphPanel.getPropertyManager()));
//		graphPanel.setGraphLayout(new GenericMDSLayoutCop());
    	graphPanel.getSelectionModel().addSelectionEventListener(this);
    	
    	
    	
    	frame.getContentPane().add(graphPanel);
    	frame.pack();
    	frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    }
}
