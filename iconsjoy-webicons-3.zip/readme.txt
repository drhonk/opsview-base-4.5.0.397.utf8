"34aL volume2" Icons Set v1.0

Ammount of icons:
26

Icon Sizes:
16x16

File Types:
.ico (RGBA, 256 color), 
.icns (RGBA, 256 color, 16 color),
.tif (RGBA), 
.gif (indexed), 
.bmp (RGB - 1 color background), 
.png (RGBA)

Colors:
Colored, grey

Note: These icons are free for use.