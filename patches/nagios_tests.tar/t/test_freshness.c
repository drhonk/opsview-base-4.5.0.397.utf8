/******************************************************************************

 This program is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2 of the License, or
 (at your option) any later version.

 This program is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 GNU General Public License for more details.

 You should have received a copy of the GNU General Public License
 along with this program; if not, write to the Free Software
 Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

 $Id: test_disk.c,v 1.3 2007/03/30 09:00:05 psychotrahe Exp $
 
******************************************************************************/

#define NSCORE 1
#include "../include/config.h"
#include "../include/nagios.h"
#include "../include/objects.h"
#include "tap.h"

int interval_length=60;
int additional_freshness_latency=15;
time_t program_start=1234567890;

service *create_base_test_service() {
	service *temp_service;
	temp_service = (service *)malloc(sizeof(service));
	temp_service->freshness_threshold=0;
	temp_service->state_type=HARD_STATE;
	temp_service->current_state=STATE_OK;
	temp_service->check_interval=5;
	temp_service->retry_interval=1;
	temp_service->latency=0.0;
	temp_service->has_been_checked=FALSE;
	temp_service->last_check=(time_t)0;
	return temp_service;
}

host *create_base_test_host() {
	host *temp_host;
	temp_host = (host *)malloc(sizeof(host));
	temp_host->freshness_threshold=0;
	temp_host->check_interval=10;
	temp_host->latency=0.0;
	temp_host->has_been_checked=FALSE;
	temp_host->last_check=(time_t)0;
	return temp_host;
}
int
main (int argc, char **argv)
{
	service *service;
	host *host;
	int t;
	plan_tests(24);

#ifdef DIAG
	diag("Running service checks");
#endif
	service=create_base_test_service();
	service->freshness_threshold=600;
	ok( calculate_service_freshness_threshold(service) == 600, "Use freshness_threshold value if set");

	service->freshness_threshold=0;
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+0.0+15), "Initial calculated freshness");
	service->has_been_checked=TRUE;
	service->latency=53.7;
	service->last_check=(time_t)1234569000;
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+53.7+15), "Freshness after an OK check");
	service->current_state=STATE_WARNING;
	service->state_type=SOFT_STATE;
	ok( calculate_service_freshness_threshold(service) == (int)((1*60)+53.7+15), "Freshness reduced when service has gone into soft state");
	service->state_type=HARD_STATE;
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+53.7+15), "Now in hard failure state");
	service->current_state=STATE_OK;
	service->state_type=SOFT_STATE;	/* I don't think this is valid combination, but test anyway */
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+53.7+15), "Soft OK state should have higher freshness threshold");

	program_start = (time_t)1234569111;	/* Simulate a restart */
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+53.7+15+111), "Added extra allowance if program_start is greater than last_check to allow slaves more time to send status");

	/* If check_interval is > hour, don't add that extra 111 seconds */
	service->check_interval=61;
	ok( calculate_service_freshness_threshold(service) == (int)((61*60)+53.7+15), "Don't add extra allowance for things that are checked less regularly than an hour");

	free(service);

	/* rerun the checks with a different additional_freshness_latency */
#ifdef DIAG
	diag("Running service checks with modified additional_freshness_latency");
#endif
	program_start = (time_t)1234567890;	
	additional_freshness_latency=30;

	service=create_base_test_service();
	service->freshness_threshold=600;
	ok( calculate_service_freshness_threshold(service) == 600, "Use freshness_threshold value if set");

	service->freshness_threshold=0;
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+0.0+30), "Initial calculated freshness");
	service->has_been_checked=TRUE;
	service->latency=53.7;
	service->last_check=(time_t)1234569000;
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+53.7+30), "Freshness after an OK check");
	service->current_state=STATE_WARNING;
	service->state_type=SOFT_STATE;
	ok( calculate_service_freshness_threshold(service) == (int)((1*60)+53.7+30), "Freshness reduced when service has gone into soft state");
	service->state_type=HARD_STATE;
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+53.7+30), "Now in hard failure state");
	service->current_state=STATE_OK;
	service->state_type=SOFT_STATE;	/* I don't think this is valid combination, but test anyway */
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+53.7+30), "Soft OK state should have higher freshness threshold");

	program_start = (time_t)1234569111;	/* Simulate a restart */
	ok( calculate_service_freshness_threshold(service) == (int)((5*60)+53.7+30+111), "Added extra allowance if program_start is greater than last_check to allow slaves more time to send status");

	/* If check_interval is > hour, don't add that extra 111 seconds */
	service->check_interval=61;
	ok( calculate_service_freshness_threshold(service) == (int)((61*60)+53.7+30), "Don't add extra allowance for things that are checked less regularly than an hour");

	free(service);

#ifdef DIAG
	diag("Running hosts checks");
#endif
	program_start = (time_t)1234567890;
	additional_freshness_latency=15;

	host=create_base_test_host();
	host->freshness_threshold=3600;
	ok( calculate_host_freshness_threshold(host) == 3600, "Use freshness_threshold value if set");

	host->freshness_threshold=0;
	ok( calculate_host_freshness_threshold(host) == (int)((10*60)+0.0+15), "Initial calculated freshness");

	host->has_been_checked=TRUE;
	host->latency=82.9;
	host->last_check=(time_t)1234569000;
	ok( calculate_host_freshness_threshold(host) == (int)((10*60)+82.9+15), "Freshness after a check result");

	program_start = (time_t)1234569111;	/* Simulate a restart */
	ok( calculate_host_freshness_threshold(host) == (int)((10*60)+82.9+15+111), "Added extra allowance if program_start is greater than last_check to allow slaves more time to send status");

	free(host);

#ifdef DIAG
	diag("Running hosts checks with modified additional_freshness_latency");
#endif
	program_start = (time_t)1234567890;
	additional_freshness_latency=30;

	host=create_base_test_host();
	host->freshness_threshold=3600;
	ok( calculate_host_freshness_threshold(host) == 3600, "Use freshness_threshold value if set, with a larger latency");

	host->freshness_threshold=0;
	ok( calculate_host_freshness_threshold(host) == (int)((10*60)+0.0+30), "Initial calculated freshness");

	host->has_been_checked=TRUE;
	host->latency=82.9;
	host->last_check=(time_t)1234569000;
	ok( calculate_host_freshness_threshold(host) == (int)((10*60)+82.9+30), "Freshness after a check result");

	program_start = (time_t)1234569111;	/* Simulate a restart */
	ok( calculate_host_freshness_threshold(host) == (int)((10*60)+82.9+30+111), "Added extra allowance if program_start is greater than last_check to allow slaves more time to send status");

	free(host);

	return exit_status();
}

