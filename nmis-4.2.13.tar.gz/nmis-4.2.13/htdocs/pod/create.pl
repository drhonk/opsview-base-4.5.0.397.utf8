#!/usr/bin/perl

use	File::Find;
use	HTML::Stream;
use	IO::File;
use	Pod::Tree::HTML;
use	Pod::Tree::PerlUtil;
use	Pod::Tree::PerlPod;
use	Pod::Tree::PerlDist;
use	Pod::Tree::PerlMap;

my $pod_dir='./';
my $html_dir='../';

my %options = ( css => 'pod.css' );

my $perl_map = new Pod::Tree::PerlMap;
my $perl_dist = new Pod::Tree::PerlDist $pod_dir, $html_dir, $perl_map, %options;

$perl_dist->scan;
$perl_dist->index;
$perl_dist->translate;

`rm -f ../dist.html`;

  

