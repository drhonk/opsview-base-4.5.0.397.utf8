#
#    slave.pm - NMIS Server API Perl Package - Network Management Information System
#    Copyright (C) 2000,2001 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
package masterslave;

require 5;
use strict;
use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
use Exporter;

$VERSION = 1.00;
@ISA = qw(Exporter);

@EXPORT = qw( 
		tellMaster
		runMaster
	);

@EXPORT_OK = qw( );

$| = 1;

use Net::EasyTCP;
use NMIS;
use csv;


	require Data::Dumper;
	Data::Dumper->import();
	$Data::Dumper::Indent = 1;


# Get command line arguments
# option is what to do - 'RRDDB' etc
# type is rrdname such as 'health' 'metric' etc
# uses Master_Table to get list of master stations.
# tellMaster(\%hash)

sub tellMaster {

	my %master;
	my $hostname;
	my $reply;
	my $client;
	my $name;
	
	my $hashref = shift;
	
	if ( -r $NMIS::config{Master_Table} ) {
		if ( !(%master = &loadCSV("$NMIS::config{Master_Table}","$NMIS::config{Master_Key}","\t")) ) {
			if ($NMIS::debug) { print "\t tellMaster: could not find or read $NMIS::config{Master_Table} - master update aborted\n"; }
			return;
		}
	}
	else {
		if ($NMIS::debug) { print "\t tellMaster: could not find or read $NMIS::config{Master_Table} - master update aborted\n"; }
		return;
	}
	if ($NMIS::debug) { print "\t tellMaster: read $NMIS::config{Master_Table}\n"; }
	
	# could have multiple masters !!
	foreach $name ( keys %master ) {	

		if ( $client = new Net::EasyTCP(
			mode => 'client',
			host => $master{$name}{Host},
			port => 2345,
			donotencrypt	=>		1,
			donotcompress	=>		1,
			timeout			=>		30
		  ) ) {
			# Send and receive complex objects/strings/arrays/hashes by reference
			$client->send($hashref) || logMessage("tellMaster, error sending to client: $@");
			$client->close();
			my $size = keys(%{$hashref}) -1;
			# always at least 1 hostname record plus a varying amount of node records
			if ($NMIS::debug) { print "\t tellMaster: wrote $size records of reachability info to $master{$name}{Host}\n"; }

		}
		else {
			logMessage("tellMaster, error creating client: $@");
		}
	}
}

### 29Apr2004 runMaster will copy Slave config and /var directory from slave(s) to this Master host.
# uses Slave_Table to get list of slaves to pull static information.
# infomration pulled...
# slave nodes.csv
# all from /var directory - excluding event.dat

sub runMaster {

	my %slave;
	my $dump;
	my $name;
	
	if ( -r $NMIS::config{Slave_Table} ) {
		if ( !(%slave = &loadCSV("$NMIS::config{Slave_Table}","$NMIS::config{Slave_Key}","\t")) ) {
			if ($NMIS::debug) { print "\t runMaster: could not find or read $NMIS::config{Slave_Table} - slave update aborted\n"; }
			return;
		}
	}
	else {
		if ($NMIS::debug) { print "\t runMaster: could not find or read $NMIS::config{Slave_Table} - slave update aborted\n"; }
		return;
	}
	if ($NMIS::debug) { print "\t runMaster: read $NMIS::config{Slave_Table}\n"; }

	# user rsync and anonymous access to get rsync module_name/var from each remote node
	# when configuring /etc/rsyncd.conf, suggest use allow-host option for basic security
	foreach $name ( keys %slave ) {

		# /var directory
		if ( $NMIS::debug ) {
			print "\n\t Pulling $name \var directory to master\n";
			$dump = `rsync -Wvvaz --exclude=event.dat --include=*.dat --exclude=* $slave{$name}{Host}::$slave{$name}{Var}/ $NMIS::config{'<nmis_var>'}`;
			print "\t runMaster: asked for rsync -Wvvaz --exclude=event.dat --include=*.dat --exclude=* $slave{$name}{Host}::$slave{$name}{Var}/ $NMIS::config{'<nmis_var>'}\n";
			$dump =~ s/\n/\n\t\t/g;
			print "\t\t$dump\n";
		}
		else {
			system("rsync -Wqaz --exclude=event.dat --include=*.dat --exclude=* $slave{$name}{Host}::$slave{$name}{Var}/ $NMIS::config{'<nmis_var>'}") == 0 or
				logMessage( "runMaster","Could not rsync $slave{$name}{Host}::$slave{$name}{Var}");
		}

		# node file
		if ( $NMIS::debug ) {
			print "\n\t Pulling $name nodes.csv to master\n";
			$dump = `rsync -Wvvz $slave{$name}{Host}::$slave{$name}{NodeFile} $NMIS::config{'<nmis_conf>'}/$slave{$name}{Name}_nodes.csv`;
			print "\t runMaster: asked for rsync -Wvvz $slave{$name}{Host}::$slave{$name}{NodeFile} $NMIS::config{'<nmis_conf>'}/$slave{$name}{Name}_nodes.csv\n";
			$dump =~ s/\n/\n\t\t/g;
			print "\t\t$dump\n";
		}
		else {
			system( "rsync -Wqz $slave{$name}{Host}::$slave{$name}{NodeFile} $NMIS::config{'<nmis_conf>'}/$slave{$name}{Name}_nodes.csv") == 0 or
				logMessage( "runMaster","Could not rsync $slave{$name}{Host}::$slave{$name}{NodeFile}");
		}
	}
}


1;
