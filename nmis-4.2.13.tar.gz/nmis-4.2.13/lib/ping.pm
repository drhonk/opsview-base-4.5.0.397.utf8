# $Id: ping.pm,v 1.13 2006/02/09 17:03:09 ibrunello Exp $
#
#    ping.pm - NMIS ping Perl Package - Network Management Information System
#    Copyright (C) 2000,2001 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
package ping;

require 5;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);

use Exporter;

$VERSION = 1.00;

@ISA = qw(Exporter);

@EXPORT = qw( 
		ext_ping
	);

@EXPORT_OK = qw( );

use NMIS;
use func;
use POSIX ':signal_h';

# Find the kernel name
#my $kernel;
#if (defined $NMIS::config{kernelname} and $NMIS::config{kernelname} ne "") {
#	$kernel = $NMIS::config{kernelname};
#} elsif ( $^O !~ /linux/i) {
#	$kernel = $^O;
#} else {
#	chomp($kernel = lc `uname -s`);
#}

# ping host retrieve and return min, avg, max round trip time
# relying on finding a standard ping in PATH.
# Try to not be platform specific if at all possible.
#
sub ext_ping {
	my($host, $length, $count, $timeout) = @_;
	my(%ping, $ping_output, $redirect_stderr, $pid, %pt);
	my($alarm_exists);

    $timeout ||= 3;
    $count ||= 3;
    $length ||= 56;

	# List of known ping programs
	%ping = (
	    ### KS 2 Jan 03 - Windows supports timeout.
		'MSWin32' =>	"ping -l $length -n $count -w $timeout $host",
		'aix'	=>	"/etc/ping $host $length $count",
		'bsdos'	=>	"/bin/ping -s $length -c $count $host",
		'freebsd' =>	"/sbin/ping -s $length -c $count $host",
		'hpux'	=>	"/etc/ping $host $length $count",
		'irix'	=>	"/usr/etc/ping -c $count -s $length $host",
		'linux'	=>	"/bin/ping -c $count -s $length $host",
		'suse'	=>	"/bin/ping -c $count -s $length -w $timeout $host",
		'netbsd' =>	"/sbin/ping -s $length -c $count $host",
		'openbsd' =>	"/sbin/ping -s $length -c $count $host",
		'os2' =>	"ping $host $length $count",
		'OS/2' =>	"ping $host $length $count",
		'dec_osf'=>	"/sbin/ping -s $length -c $count $host",
		'solaris' =>	"/usr/sbin/ping -s $host $length $count",
		'sunos'	=>	"/usr/etc/ping -s $host $length $count",
		);

	# set kernel name
	my $kernel = defined $NMIS::kernel ? $NMIS::kernel : $^O ;

	unless (defined($ping{$kernel})) {
		print STDERR "\t ext_ping: FATAL: Not yet configured for >$kernel<\n";
		exit(1);
		}

	# windows 95/98 does not support stderr redirection...
	# also OS/2 users reported problems with stderr redirection...
	$redirect_stderr = $kernel =~ /^(MSWin32|os2|OS\/2)$/i ? "" : "2>&1";

	# initialize return values
	$pt{loss} = 100;
	$pt{min} = $pt{avg} = $pt{max} = undef;
	if ($NMIS::debug>4) { print STDERR "\t ext_ping: $ping{$^O}\n"; }


	unless ($pid = open(PING, "$ping{$kernel} $redirect_stderr |")) {
		print STDERR "\t ext_ping: FATAL: Can't open $ping{$kernel}: $!";
		exit(1);
		}

	$alarm_exists =  eval { alarm(0); 1 };
	### KS 2 Jan 03 - fixed timout to timeout.
	print STDERR "\t ext_ping: WARN: builtin alarm() does not exist, can't timeout ping command\n"
		if $NMIS::debug && $timeout && !$alarm_exists;

	# if your system has trouble with alarms cutting pings off midstream, then just uncomment this line to disable the alarm.
	#$alarm_exists = 0;

	if ($alarm_exists) {
		# read and timeout ping() if it takes too long...
		eval {
			sigaction SIGALRM, new POSIX::SigAction sub { die "alarm\n" } or die "Error setting SIGALRM handler: $!\n"; 
			alarm $timeout*$count;		# make sure alarm timer is ping count * ping timeout - assuming default ping wait is 1 sec.!
			while (<PING>) {
				$ping_output .= $_;
				}
			alarm 0;
			};
		alarm 0;	# race condition protection

		if ($@) {
			die unless $@ eq "alarm\n";	# propagate unexpected errors
			# timed out, kill child, get remaining output, ...
			kill $pid;
			while (<PING>) {
				$ping_output .= $_;
				}
			close(PING);

			# ... and set return values to dead values
			if ($NMIS::debug>1) {
				$_ = $ping_output;
				s/\n/\n\t\t/g;
				print STDERR "\t ext_ping: ERROR: external ping hit timeout $timeout, assuming target $host is unreachable\n";
				if ($NMIS::debug>2) {
					print STDERR "\t ext_ping: INFO: The output of the ping command $ping{$^O} was:\n";
					print STDERR "\t\t$_\n";
					}
				}
			return($pt{min}, $pt{avg}, $pt{max}, $pt{loss});
			}
		}
	else {
		# read and hope that ping() will return in time...
		while (<PING>) {
			$ping_output .= $_;
			}

		}

	# didn't time out, analyse ping output.
	close(PING);

	if ($NMIS::debug>1) {
		$_ = $ping_output;
		s/\n/\n\t\t/g;
		print "\t\t$_\n";
		}

	# try to find round trip times
	if ($ping_output =~ m@(?:round-trip|rtt)(?:\s+\(ms\))?\s+min/avg/max(?:/(?:m|std)-?dev)?\s+=\s+(\d+(?:\.\d+)?)/(\d+(?:\.\d+)?)/(\d+(?:\.\d+)?)@m) {
		$pt{min} = $1; $pt{avg} = $2; $pt{max} = $3;
		}
	elsif ($ping_output =~ m@^\s+\w+\s+=\s+(\d+(?:\.\d+)?)ms,\s+\w+\s+=\s+(\d+(?:\.\d+)?)ms,\s+\w+\s+=\s+(\d+(?:\.\d+)?)ms\s+$@m) {
		# this should catch most windows locales
		$pt{min} = $1; $pt{avg} = $3; $pt{max} = $2;
		}
	else {
		if ($NMIS::debug>2) {
			$_ = $ping_output;
			s/\n/\n\t\t/g;
			print STDERR "\t ext_ping: ERROR: Could not find ping summary for $host\n";
			print STDERR "\t ext_ping: INFO: The output of the ping command $ping{$^O} was:\n";
			print STDERR "\t\t$_\n";
			}
		}

	# try to find packet loss
	if ($ping_output =~ m@(\d+)% packet loss$@m) {
		# Unix
		$pt{loss} = $1;
		}
		elsif ($ping_output =~ m@(\d+)% (?:packet )?loss,@m) {
		# RH9 and RH9 ES - ugh !
		$pt{loss} = $1;
		}
	elsif ($ping_output =~ m@\(perte\s+(\d+)%\),\s+$@m) {
		# Windows french locale
		$pt{loss} = $1;
		}
	elsif ($ping_output =~ m@\((\d+)%\s+(?:loss|perdidos)\),\s+$@m) {
		# Windows portugesee, spanish locale
		$pt{loss} = $1;
		}
	else {
		if ($NMIS::debug>2) {
			$_ = $ping_output;
			s/\n/\n\t\t/g;
			print STDERR "\t ext_ping: ERROR: Could not find packet loss summary for $host\n";
			print STDERR "\t ext_ping: INFO: The output of the ping command $ping{$^O} was:\n";
			print STDERR "\t\t$_\n";
			}
		}

	if ($NMIS::debug>2) {
		print STDERR "\t ext_ping: returning min=$pt{min}, avg=$pt{avg}, max=$pt{max}, loss=$pt{loss}\n";
		}
	return($pt{min}, $pt{avg}, $pt{max}, $pt{loss});
}

1;

