# $Id: System.pm,v 1.2 2006/01/23 15:26:34 ibrunello Exp $

package Authen::System;
use Carp;
use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
use Exporter;
$VERSION = "0.1";
@ISA = qw(Exporter);

@EXPORT = qw(
    Initialize
    RandomKey
    NewCipher
    EncryptMessage
    DecryptMessage
    SendChallenge
    SendResponse
    SendSockMsg
    ParseAttributes
);

use POSIX;
use Config;

use Data::Random qw(:all);
use Authen::PAM;

#my $secretfile = "/var/nmis/conf/nmis.key";
my $secretfile = "./nmis.key";

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {
		secret=>undef,
		challenge=>undef,
		encrypt=>undef,
		auth=>undef,
		key=>undef,
		cryptkey=>undef,
		passwdkey=>undef,
		sessionid=>undef,
		checksum=>undef,
		username=>undef,
		password=>undef,
		socket=>undef,
		error=>undef
	};
	bless $self, $class;
}

sub AUTOLOAD {
	my $self = shift;
	my $type = ref($self) || croak "$self is not an object\n";
	my $name = $AUTOLOAD;
	$name =~ s/.*://;
	unless (exists $self->{$name} ) {
		croak "cant access $name field in object $type\n";
	}
	if (@_) {
		return $self->{$name} = shift;
	} else {
		return $self->{$name};
	}
}

sub Initialize {
	my $self = shift;
	$self->{secret} = _secret->new;
	$self->{challenge} = _challenge->new;
	$self->{encrypt} = _encrypt->new;
	$self->secret->Initialize($secretfile);
	$self->challenge->Initialize($self->secret->{secret});
	$self->RandomKey(32);
	$self->encrypt->Initialize($self->{key});
	$self->{sessionid} = "";
	$self->{checksum} = "";
}

sub RandomKey {
	my ($self, $kl) = @_;
	my $rk = "";
	$kl = 8 unless $kl;
	while ( $kl-- ) {
        	$rk .= (rand_chars( set => 'alphanumeric', size => 1))[0];
	}
	return $self->{key} = $rk;
}

sub DecryptMessage {
	my $self = shift;
	my $message = shift;
	return _encrypt::DecryptMessage($self->{encrypt}, $message);
}

sub EncryptMessage {
	my $self = shift;
	my $message = shift;
	return _encrypt::EncryptMessage($self->{encrypt}, $message);
}

sub SendResponse {
	my $self = shift;
	my $socket = $self->{socket};
	print $socket $self->challenge->{response};
}

sub SendChallenge {
	my $self = shift;
	my $socket = $self->{socket};
	print $socket $self->challenge->{challenge};
}

sub NewCipher {
	my $self = shift;
	if ( @_ == 0 ) {
		_encrypt::CreateCipher($self->{encrypt}, $self->{key});
#		$self->encrypt->CreateCipher($self, $self->{key});
#		$self->{cryptkey} = $self->{key};
	} elsif ( @_ == 1 ) {
		_encrypt::CreateCipher($self->{encrypt}, (@_)[0]);
#		$self->encrypt->CreateCipher($self, (@_)[0]);
#		$self->{cryptkey} = (@_)[0];
	} elsif ( @_ == 2 ) {
		_encrypt::CreateCipher($self->{encrypt}, (@_));
#		$self->encrypt->CreateCipher($self, (@_));
#		$self->{cryptkey} = (@_)[0];
	} else {
		return undef;
	}
}

sub ParseAttributes {
	my $self = shift;
	my $attributes = shift;

	foreach $line (split "\n", $attributes) {
		chomp $line;
		($tag, $value) = split /=/, $line;

		if ( $tag =~ /start/ ) {
			$begin = 1 if ( $value =~ /Authenticate/ ); 
			next;
		}
		if ( $begin and $tag =~ /sessionid/ ) {
			my ($sid, $chk) = split /:/, $value;
			if ($chk eq unpack('%32C*', $sid)) {
				$self->{sessionid} = $sid;
				$self->{checksum} = $chk;
				next;
			}
			$self->{sessionid} = "";
			next;
		}
		if ( $self->sessionid and $tag =~ /cryptmethod/ ) {
			$self->encrypt->cryptmethod($value);
			next;
		}
		if ( $self->sessionid and $tag =~ /cryptkey/ ) {
			$self->cryptkey($value);
			next;
		}
		if ( $self->sessionid and $tag =~ /passwdkey/ ) {
			$self->passwdkey($value);
			next;
		}
		if ( $self->sessionid and $tag =~ /username/ ) {
			$self->username($value);
			next;
		}
		if ( $self->sessionid and $tag =~ /password/ ) {
			$self->password($value);
			next;
		}
		if ( $tag =~ /end/ ) {
			last;
		}
	}
}
 
sub Authenticate {
	my $self = shift;

	$self->NewCipher($self->passwdkey);
	$self->password($self->DecryptMessage($self->password));

#	$service = "system-auth";
	$service = "login";
	$tty_name = ttyname(fileno(STDIN));

	sub my_conv_func {
    	my @res;
    	while ( @_ ) {
        	my $code = shift;
        	my $msg = shift;
        	my $ans = "";

        	$ans = $self->username if ($code == PAM_PROMPT_ECHO_ON() );
        	$ans = $self->password if ($code == PAM_PROMPT_ECHO_OFF() );

        	push @res, (PAM_SUCCESS(),$ans);
    	}
    	push @res, PAM_SUCCESS();
    	return @res;
	}

	ref($pamh = new Authen::PAM($service, $self->username, \&my_conv_func)) ||
         die "Error code $pamh during PAM init!";

	$res = $pamh->pam_set_item(PAM_TTY(), $tty_name);
	$res = $pamh->pam_authenticate;
	return $res == PAM_SUCCESS() ? 1 : 0;
}

sub SendSockMsg {
	my $self = shift;
	my $msg = shift;
	my $socket = $self->{socket};
	print $socket $msg;
}

sub SockRead {
        my ($sock,$len,$timeo) = @_;
        my %state = ();
        my $buf;

        sub timeout { die "SOCKET_TIMEOUT"; }

READ_SOCKET:
        $SIG{ALRM} = \&timeout;
        eval {
                alarm($timeo);
                $len = sysread ($sock, $buf, $len);
                alarm(0);
                die "SOCKET_CLOSE" unless ( defined $buf );
        };
        if ( $@ =~ /SOCKET_TIMEOUT/ ) {
                print $conn "abort\n";
                goto END;
        }
        if ( $@ =~ /SOCKET_CLOSE/ ) {
                goto END;
        }
}

sub SockReadLine {

}

package _challenge;
use Carp;
use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
use Exporter;
$VERSION = "0.1";
@ISA = qw(Exporter);

@EXPORT = qw(
	Initialize
	NewChallenge
	Challenge
	Response
	SendChallenge
	SendResponse
	Validate
);

use Authen::Challenge::Basic qw(:all);
use Authen::PAM;

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {
		_obj=>undef,
		challenge=>undef,
		response=>undef,
		peer_challenge=>undef,
		peer_response=>undef,
		_timeout=>undef,
		_sync=>undef
	};
	bless $self, $class;
}

sub Initialize {
	my $self = shift;
	my $secret = shift;
	$self->{_timeout} = 30;
	$self->{_sync} = 10;
	$self->{_obj} = Authen::Challenge::Basic->new ('Secret' => $secret,
		'Timeout' => $self->{_timeout}, 'Sync' => $self->{_sync});
	$self->{challenge} = $self->_obj->Challenge;
}

sub Challenge {
	my $self = shift;
	return $self->{challenge};
}

sub NewChallenge {
	my $self = shift;
	my $secret = shift;
	$self->_obj = Authen::Challenge::Basic->new ('Secret' => $secret,
		'Timeout' => $self->_timeout, 'Sync' => $self->_sync);
	$self->challenge = $self->_obj->Challenge;
}

sub SendChallenge {
	my $self = shift;
	my $socket = shift;
	print $socket $self->challenge;
}

sub Response {
	my $self = shift;
	$self->{peer_challenge} = shift;
	$self->{response} = $self->_obj->Response($self->{peer_challenge});
}

sub SendResponse {
	my $self = shift;
	my $socket = shift;
	print $socket $self->{response};
}

sub Validate {
	my $self = shift;
	$self->{peer_response} = shift;
	return $self->_obj->Validate($self->{challenge}, $self->{peer_response});
}

sub AUTOLOAD {
	my $self = shift;
	my $type = ref($self) || croak "$self is not an object\n";
	my $name = $AUTOLOAD;
	$name =~ s/.*://;
	unless (exists $self->{$name} ) {
		croak "cant access $name field in object $type\n";
	}
	if (@_) {
		return $self->{$name} = shift;
	} else {
		return $self->{$name};
	}
}

package _secret;
use Carp;
use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
use Exporter;
$VERSION = "0.1";
@ISA = qw(Exporter);

@EXPORT = qw(
	_read_secret
);

#my $secretfile = "/var/nmis/conf/nmis.key";
my $secretfile = "./nmis.key";

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {
		secretfile=>undef,
		secret=>undef
	};
	bless $self, $class;
}

sub Initialize {
	my $self = shift;
	$self->{secretfile} = $secretfile;
	$self->{secretfile} = shift unless @_ == 0;
	$self->{secret} = _read_secret($self->{secretfile}) unless undef;
}

sub _read_secret {
	my $sf = shift;
	my $secret;
	eval {
		open KEY, "<$sf" or die "Error opening file";
		read KEY, $secret, 64;
		close KEY;
	};
	return undef if ( $@ =~ /Error/ );
	return $secret;
}

sub AUTOLOAD {
	my $self = shift;
	my $type = ref($self) || croak "$self is not an object\n";
	my $name = $AUTOLOAD;
	$name =~ s/.*://;
	unless (exists $self->{$name} ) {
		croak "cant access $name field in object $type\n";
	}
	if (@_) {
		return $self->{$name} = shift;
	} else {
		return $self->{$name};
	}
}

package _encrypt;
use Carp;
use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);
use Exporter;
$VERSION = "0.1";
@ISA = qw(Exporter);

@EXPORT = qw(
   Initialize
   CreateCipher
   SetCryptKey
);

use MIME::Base64;
use Crypt::Twofish_PP;

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {
		cryptmethod => undef,
		cipher => undef
	};
	bless $self, $class;
}

sub Initialize {
	my $self = shift;
	my $key = shift;
	$self->{cryptmethod} = "Twofish_PP";
	CreateCipher($self, $key);
}

sub CreateCipher {
	my $self = shift;
	my $key = shift;
	my $len;
	my $cipher = ();
	if ( @_ == 0 ) {
		$key = substr($key, 0, 32) if length($key) > 32;
		$key = substr($key, 0, 24) if length($key) < 32;
		$key = substr($key, 0, 16) if length($key) < 24;
		return undef if ( length($key) < 16 );
	} elsif ( @_ == 1 ) {
		$len = shift;
		return undef unless ( $len != 32 or $len != 24 or $len != 16 );
		$key = substr($key, 0, $len);
		return undef if ( length($key) != $len );
	}
	$cipher = Crypt::Twofish_PP->new ($key);
	return undef unless defined $cipher and $cipher;
	$self->{cipher} = $cipher;
}

sub DecryptMessage {
	my $self = shift;
	my $base64 = shift;
	my $ciphertext = MIME::Base64::decode_base64($base64);
	my $plaintext = "";
	for ($ii=0; $ii < length($ciphertext); $ii=$ii+16) {
       		$block = pack "a16", substr($ciphertext, $ii, 16);
       		$plaintext .= $self->cipher->decrypt ($block);
	}
	return $plaintext;
}

sub EncryptMessage {
	my $self = shift;
	my $plaintext = shift;
	$ciphertext = "";
	for ($ii=0; $ii < length($plaintext); $ii=$ii+16) {
       		$block = pack "a16", substr($plaintext, $ii, 16);
       		$ciphertext .= $self->cipher->encrypt ($block);
	}
	return MIME::Base64::encode_base64($ciphertext,"");
}

sub SetCryptKey {
	$self = shift;
	my $key = shift;
	return $self->{cipher} = Crypt::Twofish_PP->new ($key);
}

sub AUTOLOAD {
	my $self = shift;
	my $type = ref($self) || croak "AUTOLOAD: $self is not an object\n";
	my $name = $AUTOLOAD;
	$name =~ s/.*://;
	unless (exists $self->{$name} ) {
		croak "cant access $name field in object $type\n";
	}
	if (@_) {
		return $self->{$name} = shift;
	} else {
		return $self->{$name};
	}
}

1;
