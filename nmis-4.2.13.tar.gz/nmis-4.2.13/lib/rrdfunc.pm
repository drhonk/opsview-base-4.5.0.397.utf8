#
#    rrdfunc.pm - func NMIS Perl Package - Network Management Information System
#    Copyright (C) 2000,2001 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
package rrdfunc;

require 5;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);

use Exporter;

use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 

use RRDs;
use Statistics::Lite qw(min max range sum count mean median mode variance stddev statshash statsinfo);
use NMIS;
use func;

$VERSION = 1.00;

@ISA = qw(Exporter);

@EXPORT = qw(
		getRRDasHash
		getRRDStats
		addDStoRRD
	);

@EXPORT_OK = qw(	
	);

sub getRRDasHash {
	my %arg = @_;
	my ($begin,$step,$name,$data) = RRDs::fetch($arg{rrd},$arg{type},"--start",$arg{start},"--end",$arg{end});
	my %s;
	my @h;
	my $f = 1;
	my $date;
	my $d;
	my $time = $begin;
	for(my $a = 0; $a <= $#{$data}; ++$a) {
		$d = 0;
		for(my $b = 0; $b <= $#{$data->[$a]}; ++$b) {
			if ($f) { push(@h,$name->[$b]) }
			$s{$time}{$name->[$b]} = $data->[$a][$b];
			if ( defined $data->[$a][$b] ) { $d = 1; }
		}
		if ($d) {
			$date = returnDateStamp($time);
			$s{$time}{time} = $time;
			$s{$time}{date} = $date;
		}
		if ($f) { 
			push(@h,"time");
			push(@h,"date");
		}
		$f = 0;
		$time = $time + $step;
	}
	return (\%s,\@h);
}

sub getRRDStats {
	my %arg = @_;
	if ( ! defined $arg{type} ) { $arg{type} = "AVERAGE"; }
	if ( -r $arg{rrd} ) {
		my ($begin,$step,$name,$data) = RRDs::fetch($arg{rrd},$arg{type},"--start",$arg{start},"--end",$arg{end});
		my %s;
		my $time = $begin;
		for(my $a = 0; $a <= $#{$data}; ++$a) {
			my $date = returnDateStamp($time);
			my $hour = $date;
			my $f = 1;
			$hour =~ s/\d+-[a-zA-Z]+-\d+ (\d+):\d+:\d+/$1/;		
			for(my $b = 0; $b <= $#{$data->[$a]}; ++$b) {
				if ( (	defined $data->[$a][$b] 
						and ! defined $arg{hour_from}
						and ! defined $arg{hour_to}
					) or ( 
						defined $data->[$a][$b] 
						and defined $arg{hour_from} 
						and defined $arg{hour_to} 
						and $hour > $arg{hour_from} 
						and $hour < $arg{hour_to} 
					)
				) {
					if ($f) { 
						#print "$date hour=$hour\n";
						$f = 0;
					}
					push(@{$s{$name->[$b]}{values}},$data->[$a][$b]);
				}
			}
			$time = $time + $step;
		}

		foreach my $m (sort keys %s) {
			$s{$m}{stddev} = sprintf("%.3f",stddev(@{$s{$m}{values}}));
			$s{$m}{mean} = sprintf("%.3f",mean(@{$s{$m}{values}}));
			$s{$m}{median} = sprintf("%.3f",median(@{$s{$m}{values}}));
			$s{$m}{min} = sprintf("%.3f",min(@{$s{$m}{values}}));
			$s{$m}{max} = sprintf("%.3f",max(@{$s{$m}{values}}));
			$s{$m}{range} = sprintf("%.3f",range(@{$s{$m}{values}}));
			$s{$m}{sum} = sprintf("%.3f",sum(@{$s{$m}{values}}));
			$s{$m}{count} = sprintf("%.3f",count(@{$s{$m}{values}}));
			$s{$m}{variance} = sprintf("%.3f",variance(@{$s{$m}{values}}));
		}
		return \%s;
	} else {
		logMessage("getRRDStats,,RRD is not readable rrd=$arg{rrd}");
		return undef;
	}
}

#
# add a DataSource to an existing RRD
# Cologne, dec 2004
# $rrd = filename of RRD, @ds = list of DS:name:type:hearthbeat:min:max
#
sub addDStoRRD {
	my ($rrd, @ds) = @_ ;

	my $debug = $NMIS::debug;

	print returnTime." addDS: update $rrd with @ds\n" if $debug;

	my $rrdtool = "rrdtool";
	if ($NMIS::kernel =~ /win32/i) {
		$rrdtool = "rrdtool.exe";
	}
	my $info = `$rrdtool`;
	if ($info eq "") {
		$rrdtool = "/usr/local/rrdtool/bin/rrdtool"; # maybe this
		$info = `$rrdtool`;
		if ($info eq "") {
			print returnTime." addDS: ERROR, rrdtool not found\n" if $debug;
			return;
		}
	}

	# version of rrdtool
	my $version = "10";
	if ($info =~ /.*RRDtool\s+(\d+)\.(\d+)\.(\d+).*/) {
		print returnTime." addDS: RRDtool version is $1.$2.$3\n" if $debug;
		$version = "$1$2";
	}

	my $DSname;
	my $DSvalue;
	my $DSprep;

	# Get XML Output
	my $xml = `$rrdtool dump $rrd`;

	#prepare inserts
	foreach my $ds (@ds) {
		if ( $ds =~ /^DS:([a-zA-Z0-9_]{1,19}):(\w+):(\d+):([\dU]+):([\dU]+)/) {
				# Variables
				my $dsName      = $1;
				my $dsType      = $2;
				my $dsHeartBeat = $3;
				my $dsMin       = $4;
				my $dsMax       = $5;

	 		if ( $dsType ne "GAUGE" and $dsType ne "COUNTER" and $dsType ne "DERIVE" and $dsType ne "ABSOLUTE" ) {
				print returnTime." addDS: ERROR, unknown DS type in $ds\n" ;
				return undef;
			}
			if ($xml =~ /<name> $dsName </) {
				print returnTime." addDS: ERROR, DS $ds already in database $ds\n";
			} else {

				$DSname .= "	<ds>
			<name> $dsName </name>
			<type> $dsType </type>
			<minimal_heartbeat> $dsHeartBeat </minimal_heartbeat>
			<min> $dsMin </min>
			<max> $dsMax </max>
		
			<!-- PDP Status -->
			<last_ds> UNKN </last_ds>
			<value> 0.0000000000e+00 </value>
			<unknown_sec> 0 </unknown_sec>
		</ds>\n";

				$DSvalue = $DSvalue eq "" ? "<v> NaN " : "$DSvalue </v><v> NaN ";

				if ($version > 11) {
					$DSprep .= "
				 <ds>
				<primary_value> 0.0000000000e+00 </primary_value>
				<secondary_value> 0.0000000000e+00 </secondary_value>
				<value> NaN </value>  <unknown_datapoints> 0 </unknown_datapoints></ds>\n";
				} else {
					$DSprep .= "<ds><value> NaN </value>  <unknown_datapoints> 0 </unknown_datapoints></ds>\n";
				}			
			}
		}
	}

	if ($DSname ne "" ) {
		if ( $xml =~ /Round Robin Archives/ ) {
			# check priv.
			if ( -w $rrd ) {
		 		# Move the old source
	   			if (rename($rrd,$rrd.".bak")) {
					print returnTime." addDS: $rrd moved to $rrd.bak\n" if $debug;
					if ( -e "$rrd.xml" ) {
						# from previous action
						unlink $rrd.".xml";
						print returnTime." addDS: $rrd.xml deleted (previous action)\n" if $debug;
					}
					# update xml and rite output
					if (open(OUTF, ">$rrd.xml")) {
						foreach my $line (split(/\n/,$xml)) {
							if ( $line=~ /Round Robin Archives/ ) {
								print OUTF $DSname.$line;
							} elsif ($line =~ /^(.+?<row>)(.+?)(<\/row>.*)$/) {
								my @datasources_in_entry = split(/<\/v>/, $2);
								splice(@datasources_in_entry, 999, 0, "$DSvalue");
								my $new_line = join("</v>", @datasources_in_entry);
								print OUTF "$1$new_line</v>$3\n";
							} elsif ($line =~ /<\/cdp_prep>/) {
								print OUTF $DSprep.$line ;
							} else {
								print OUTF $line;
							}
						}
						close (OUTF);
						print returnTime." addDS: xml written to $rrd.xml\n" if $debug;
						# Re-import
						RRDs::restore($rrd.".xml",$rrd);
						if (my $ERROR = RRDs::error) {
							logMessage("addDS, update ERROR database=$rrd: $ERROR");
							print returnTime." addDS: update ERROR database=$rrd: $ERROR\n" ;
						} else {
							print returnTime." addDS: $rrd created\n" if $debug;
							setFileProt($rrd); # set file owner/permission, default: nmis, 0775
							#`chown nmis:nmis $rrd` ; # set owner
							# Delete
							unlink $rrd.".xml";
							print returnTime." addDS: $rrd.xml deleted\n" if $debug;
							unlink $rrd.".bak";
							print returnTime." addDS: $rrd.bak deleted\n" if $debug;
							logMessage("addDS, DataSource @ds added to $rrd");
							return 1;
						}
					} else {
						print returnTime." addDS: ERROR, could not open $rrd.xml for writing, $!\n";
						rename($rrd.".bak",$rrd); # backup
					}
				} else {
					print returnTime." addDS: ERROR, cannot rename $rrd, $!\n" ;
				}
			} else {
				print returnTime." addDS: ERROR, no write permission for $rrd, $!\n" ;
			}
		} else {
   			print returnTime." addDS: ERROR, could not dump (maybe rrdtool missing): $!\n";
		}
	} 

}


1;
