#
#    web.pm - NMIS Perl Package - Network Mangement Information System
#    Copyright (C) 2000,2001 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
package web;

require 5;

use strict;

use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);

use Exporter;

$VERSION = 1.00;

@ISA = qw(Exporter);

@EXPORT = qw(
		pageStart
		pageStartCSS
		pageStartFile
		pageEnd
		headerBar
		paragraph
		preStart
		preEnd
		tableStart
		tableEnd
		rowStart
		rowEnd
		cellStart
		cellEnd
		printCell
		printCellNoWrap
		printHeadCell
		printCellRight
		printRow
		printHeadRow
		errorMessage
		cssPrintCell 
		cssTableStart 
		cssCellStart
		cssHeaderBar
		cssPrintHeadRow
		cssPrintRow
	);

use NMIS;
use func;

use CGI qw(:standard);

sub printIndent {
	my $i;
	for ($i = 1; $i <= $refer::indent; ++$i) {
		print "\t";
	}
}

sub pageStart {
  	my $string = shift;
  	my $refresh = shift;
	my $opts = shift ;
	my $refreshstring;
	my $dateStamp = NMIS::returnDateStamp;
	my @dateTime = split " ", $dateStamp;
	$dateTime[0] =~ s/-/ /g;
	if ( $refresh eq "" or $refresh eq "true" or $refresh > 1) {
		my $refreshtime = ($refresh > 1) ? $refresh : 300;
		$refreshstring = "<META HTTP-EQUIV=Refresh CONTENT=$refreshtime>"; 
	}
	else { $refreshstring = ""; }
#	print <<EOHTML;
#Content-type: text/html\n
#<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
	print header({-type=>"text/html",%$opts}) . "\n";
print <<EOHTML;
<html>
<head>
    <link href="$NMIS::config{styles}" rel="stylesheet" type="text/css">
    <title>$string</title>
    $refreshstring
    <meta HTTP-EQUIV=expires CONTENT="$dateTime[0]">
<script language="JavaScript" type="text/javascript">
	function viewdoc(url,width,height)
	{
		var attrib = "scrollbars=yes,resizable=yes,width=" + width + ",height=" + height;
		ViewWindow = window.open(url,"ViewWindow",attrib);
		ViewWindow.focus();
	}
	function viewmsg(url,width,height)
	{
		var attrib = "scrollbars=yes,resizable=yes,width=" + width + ",height=" + height;
		ViewWindow = window.open(url,"msgWindow",attrib);
		ViewWindow.focus();
	}
</script>
</head>
<body>
EOHTML

 	my $ck;
	        foreach $ck (@{$$opts{-cookie}}) {
	                print comment("cookie: ".$ck) . "\n";
	        }
}

sub pageStartCSS {
        my $string = shift;
        my $style = shift;
        my $target = shift;
        my $opts = shift;
	my $dateStamp = returnDateStamp;
        my @dateTime = split " ", $dateStamp;
        $dateTime[0] =~ s/-/ /g;
        if ($target ne "") { $target = "<base target=\"$target\">"; }
#        print <<EOHTML;
#Content-type: text/html\n
#<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
	print header({type=>"text/html", %$opts});
	print <<EOHTML;
<html>
<head>
    <title>$string</title>
    <meta HTTP-EQUIV=expires CONTENT="$dateTime[0]" />
    <link href="$style" rel="stylesheet" type="text/css">
    $target
</head>
<body>
EOHTML
}         

sub pageEnd { print "  </body>\n</html>"; }

sub headerBar {
  	my $string = shift;
 	my $span = shift;
	my $spanString = "colspan=6";
	if ( $span ne "" ) { $spanString="colspan=$span "; }
  	print<<EOHTML;
    <tr>
      <td $spanString bgcolor="#AAAAAA"><BIG><FONT face="Arial" color="#000000">$string</FONT></BIG></td>
    </tr>
EOHTML
}

sub cssHeaderBar {
  	my $string = shift;
  	my $class = shift;
 	my $span = shift;
	if ($span) {
		$span = "colspan=\"$span\"";
	}
	&printIndent;
  	print<<EOHTML;
    <tr>
      <td class="$class" $span>$string</td>
    </tr>
EOHTML
}

sub cssPrintHeadRow {
  	my $string = shift;
 	my $style = shift;
 	my $span = shift;
	$string =~ s/\n|\t//g ;
	$string =~ s/,/<\/STRONG><\/BIG><\/TD><td class=$style><BIG><STRONG>/g ;
	&printIndent;
	print "<tr><td class=$style colspan=$span><BIG><STRONG>$string</STRONG></BIG></td></tr>\n";
}

sub paragraph { print "<p>\n"; }

sub preStart { print "\t<pre>\n"; }

sub preEnd { print "\t</pre>\n"; }

sub tableStart {
  	my $string = shift;
	if ($string eq "white") {
	  	print "<table summary=\"Display\" width=\"100%\" BORDER=\"1\" bgcolor=\"#FFFFFF\" bordercolor=\"#000000\" bordercolorlight=\"#000000\" bordercolordark=\"#AAAAAA\">\n";
	}
	elsif ($string ne "" ) {
	  	print "<table summary=\"Display\" border=\"0\" bgcolor=\"$string\" bordercolor=\"#000000\" bordercolorlight=\"#000000\" bordercolordark=\"#AAAAAA\">\n";
	}
	else {
	  	print "<table summary=\"Display\" border=\"0\" cellpadding=\"5\" cellspacing=\"5\" bgcolor=\"#190032\" bordercolor=\"#190032\" bordercolorlight=\"#190032\" bordercolordark=\"#190032\">\n";
	}
}

sub tableEnd {
  print "</table>\n";
}


sub rowStart {
  print "<tr>\n";
}

sub rowEnd {
  print "</tr>\n";
}

sub cellStart {
  	my $color = shift;
 	my $span = shift;
	if ( $span eq "" ) { $span="1"; }
	if ($color eq "") { $color = "#FFFFFF"; }
	print "\t<td width=100% bgcolor=$color colspan=$span>\n"; 
}

sub cellEnd {
  print "\t</td>\n";
}

sub printCell {
  	my $string = shift;
 	my $color = shift;
 	my $colspan = shift;
 	my $align = shift;
	if ( $color eq "" ) { $color="#FFFFFF"; }
	if ( $colspan ne "" ) { $colspan=" colspan=\"$colspan\""; }
	if ( $align ne "" ) { $align=" ALIGN=\"$align\""; }
	print "\t<td bgcolor=\"$color\"$colspan$align>$string</td>\n";
}

sub printCellNoWrap {
  	my $string = shift;
 	my $color = shift;
 	my $colspan = shift;
 	my $align = shift;
	if ( $color eq "" ) { $color="#FFFFFF"; }
	if ( $colspan ne "" ) { $colspan=" colspan=\"$colspan\""; }
	if ( $align ne "" ) { $align=" ALIGN=\"$align\""; }
	print "\t<td nowrap bgcolor=\"$color\"$colspan$align>&nbsp;$string</td>\n";
}

sub printHeadCell {
  	my $string = shift;
 	my $color = shift;
 	my $span = shift;
	my $spanString = "";
	if ( $span ne "" ) { $spanString=" colspan=\"$span\" "; }
	if ( $color eq "" ) { $color="#FFFFFF"; }
	print "\t<th bgcolor=\"$color\"$spanString>$string</th>\n";
}

sub printCellRight {
  	my $string = shift;
 	my $color = shift;
 	my $span = shift;
	my $spanString = "";
	if ( $span ne "" ) { $spanString="colspan=$span "; }
	if ( $color eq "" ) { $color="#FFFFFF"; }
	print "\t<td bgcolor=\"$color\" ALIGN=right $spanString>$string</td>\n";
}

sub printRow {
  	my $string = shift;
 	my $color = shift;
 	my $span = shift;
	my $spanString = "";
	if ( $color eq "" ) { $color="#FFFFFF"; }
	if ( $span ne "" ) { $spanString="colspan=$span "; }
	$string =~ s/\n|\t//g ;
	$string =~ s/,/<\/TD><td bgcolor=$color>/g ;
	print "<tr><td bgcolor=\"$color\" $spanString>$string</td></tr>\n";
}

sub printHeadRow {
  	my $string = shift;
 	my $color = shift;
 	my $span = shift;
	my $spanString = "";
	if ( $color eq "" ) { $color="#FFFFFF"; }
	if ( $span ne "" ) { $spanString="colspan=$span"; }
	$string =~ s/\n|\t//g ;
	$string =~ s/,/<\/TH><th bgcolor=\"$color\">/g ;
	print "<tr><th bgcolor=\"$color\" $spanString>$string</th></tr>\n";
}

sub cssPrintRow {
  	my $string = shift;
 	my $style = shift;
 	my $span = shift;
	$string =~ s/\n|\t//g ;
	$string =~ s/,/<\/TD><td class=\"$style\">/g ;
	&printIndent;
	print "<tr><td class=\"$style\" colspan=\"$span\">$string</td></tr>";
	print "\n";
}

sub errorMessage {
	my $string = shift;
	my $color = shift;
	my $colspan = shift;
	&cellStart($color,$colspan);
	&tableStart("white");
	&printHeadRow("$string",$color);
	&tableEnd;
	&cellEnd;
}

sub cssTableStart {
  	my $style = shift;
  	if ( $style ne "" ) { $style = " class=\"$style\""; }
	print "\n";
	&printIndent;
	++$refer::indent;
	print "<table summary=\"Display\"$style>\n";
}

sub cssCellStart {
 	my $style = shift;
 	my $span = shift;
 	my $width = shift;
  	if ( $style ne "" ) { $style = " class=\"$style\""; }
	if ( $span ne "" ) { $span = " colspan=\"$span\""; }
  	if ( $width ne "" ) { $width = " width=\"$width%\""; }
	&printIndent;
	++$refer::indent;
	print "<td$style$span$width>"; 
}

sub cssPrintCell {
 	my $style = shift;
  	my $string = shift;
 	my $span = shift;
 	my $width = shift;
  	if ( $style ne "" ) { $style = " class=\"$style\""; }
	if ( $span ne "" ) { $span = " colspan=\"$span\""; }
  	if ( $width ne "" ) { $width = " width=\"$width%\""; }
	&printIndent;
	print "<td$style$span$width>$string</td>";
}


1;
