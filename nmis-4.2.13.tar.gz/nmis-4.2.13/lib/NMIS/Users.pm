# $Id: Users.pm,v 1.3 2007/08/20 12:46:42 decologne Exp $
#
#    Users.pm - User privilege and group authorization methods
#
#    Copyright (C) 2005 Robert W. Smith
#        <rwsmith (at) bislink.net> http://www.bislink.net
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    Enough of the legal stuff.
#
##############################################################################
#
#   Users.pm
#   Users.pm is a OO Perl module implementing a class module with methods
#   to read and parse the conf/users.csv file. The file and this class 
#   serves three purposes:
#     1. to set user and read in the conf/users.csv file for user privilege
#        and groups that they can access
#     2. check the user authorization via the Toolbar.pm class
#     3. to check if a user is authorized to access or view a group or a
#        node belonging to a group
#
#   I originally wrote this modules for a client that needed user-level
#   authentication and authorization with the NMIS package to segregate the
#   server groups (engineers) from the router groups and then some.
#
#   This module is used in the first two instances to check a users
#   authorization.
#
#   use NMIS::Auth;
#   use NMIS::User;
#
#   my $auth = NMIS::Auth->new();
#   my $user = NMIS::User->new();
#
#   # verify access to this command/tool bar/button
#   #
#   if ( $auth->Require ) {
#      # CheckAccess will throw up a web page and stop if access is not allowed
#      $auth->CheckAccess($user, "nmisconf") or die "Attempted unauthorized access";
#   }
#
#   So where's $user->CheckAccess? Well, $auth->CheckAccess will call
#   $user->CheckAccess eventually. Also, Auth.pm understands the concept
#   of web pages and has ready access to the login routines if access is
#   denied. This kept Users.pm free of this clutter and duplication.
#
#   The third instance is used to check if a user can access or read
#   a group as assigned to them in the conf/users.csv file. For example,
#   when looping through the nodeTables, after &loadNodeDetails is called:
#
#   foreach $node (keys %NMIS::nodeTable) {
#      next unless $user->InGroup($NMIS::nodeTable{$node}{group});
#   }
#

#
package NMIS::Users;

use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);

use Exporter;

$VERSION = "0.1.1";

@ISA = qw(Exporter NMIS::Toolbar);

@EXPORT = qw(
	SetUser
	InGroup
	CheckAccess
	user
	privlevel
);

use strict;
use lib "../../lib";

# Import from standard CPAN modules
use Carp;

# Import external NMIS 
use csv;
use NMIS;
use NMIS::Toolbar;

#
# nauth constructor to create object to hold security and authentication
# attributes and methods
#

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {
		_require => 0,
		user => undef,
		priv => undef,
		privlevel => 0, # default all
		groups => undef,
		tb => undef
	};
	bless $self, $class;
	return $self;
}

# Set the user and read in the user privilege and groups
#
sub SetUser {
	my $self = shift;
	$self->{_require} = 1;
	$self->{user} = shift;
	$self->_GetPrivs($self->{user});
}

sub user {
	my $self = shift;
	return $self->{user};
}

sub privlevel {
	my $self =shift;
	return $self->{privlevel};
}

# check if the group is in the user's group list
#
sub InGroup {
	my $self = shift;
	my $group = shift;
	my $C = \%NMIS::config;
	return 1 unless $self->{_require};
	return 1 unless defined $group or $group;
	foreach my $g (@{$self->{groups}}) {
		return 1 if ( lc($g) eq lc($group) );
	}
	logMessage("Users, user=$self->{user}, no access for group=$group") if $C->{auth_debug};
	return 0;
}

# check as user's authorization to access a command by instantiating
# the Toolbar.pm class and reading the conf/toolset.csv file.
# This file is typically always called from the Auth.pm class method,
# Auth::CheckAccess to handle the failures.
#
sub CheckAccess {
	my $self = shift;
	my $command = shift;
	my $tb = ();

	return 1 unless $self->{_require};

	if ( not defined $self->{tb} ) {
		$tb = NMIS::Toolbar->new();
		$tb->SetLevel($self->{privlevel});
		$tb->LoadButtons($NMIS::config{'<nmis_conf>'}."/toolset.csv");
		$self->{tb} = $tb;
	}
	return $self->{tb}->CheckAccess($command);
}

# Private routines go here
#
# _GetPrivs -- load and parse the conf/users.csv file
# also loads conf/privmap.csv to map the privilege to a
# numeric privilege level.
#
sub _GetPrivs {
	my $self = shift;
	my $user = shift;
	my $C = \%NMIS::config;
	my $users_tab = $C->{'<nmis_conf>'} . "/users.csv";
	my %users = ();
	
	# set default privileges to lowest level
	$self->{priv} = "anonymous";
	$self->{privlevel} = 5;

	%users = loadCSV($users_tab, "user", "\t") or warn "Privilege level cannot be set--GetPrivs failed";

	if ( ! defined $users{$user} ) {
		logMessage("Users, user=$user not found in $users_tab file") if $C->{auth_debug};
		return 0;
	};

	my $priv_tab = $C->{'<nmis_conf>'} . "/privmap.csv";
	my %privs  = ();
	%privs = loadCSV($priv_tab, "privilege", "\t") or warn "Load Privilege map failed--GetPrivs failed";
	
	if ( ! defined $privs{$users{$user}{privilege}} ) {
		logMessage("Users, privilege '$users{$user}{privilege}' not found for user=$user") if $C->{auth_debug};
		return 0;
	}

	$self->{priv} = $users{$user}{privilege};
	$self->{privlevel} = $privs{$self->{priv}}{level};

	if ( $users{$user}{groups} eq "all" ) {
		@{$self->{groups}} = split /,/, $C->{group_list};
		push @{$self->{groups}}, "network"; # all implies the virtual network group
	} elsif ( $users{$user}{groups} eq "none" or $users{$user}{groups} eq "" ) {
		@{$self->{groups}} = [];
	} else {
	# note: the main health status graphs uses the implied virtual group network,
        # this group must be explicitly stated if you want to see this graph
		@{$self->{groups}} = split /,/, $users{$user}{groups};
	}
	logMessage("Users, user=$user, priv=$self->{privlevel}, group=@{$self->{groups}}") if $C->{auth_debug};
	return 1;
}



1;

