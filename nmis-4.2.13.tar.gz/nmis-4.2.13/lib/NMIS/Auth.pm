# $Id: Auth.pm,v 1.5 2007/08/20 12:46:42 decologne Exp $
#
#    Auth.pm - Web authorization libraries and routines
#
#    Copyright (C) 2005 Robert W. Smith
#        <rwsmith (at) bislink.net> http://www.bislink.net
#
#    Portions Copyrighted by the following entities
#    
#       Copyright (C) 2000,2001,2002 Steve Shipway
#
#       Copyright (C) 2000,2001 Sinclair InterNetworking Services Pty Ltd
#          <nmis@sins.com.au> http://www.sins.com.au
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    Enough of the legal stuff.
#
##############################################################################
#
#   Auth.pm
#   Auth.pm is a OO Perl module implementing a class module with methods
#   to enforce and perform user authentication and to a lesser degree, through
#   cooperation with another class module, provide some authorization.
#
#   I originally wrote this modules for a client that needed user-level
#   authentication and authorization with the NMIS package to segregate the
#   server groups from the router groups and then some.
#
#   The authentication routines originally came from Steve Shipway's very well 
#   written and designed (and coded) Routers2.cgi program. I took ("lifted") several
#   of his routines, verify_id, user_verfity, file_verify, ldap_verify, and
#   generate_cookie, and provided a wrapper so that they would be more easily
#   incorporated in NMIS and more generally into other web programs needing
#   user authentication.
#
#   This module is used in the following manner to enforce authentication:
#
#   use NMIS::Auth;
#   use NMIS::User;
#
#   my $auth = NMIS::Auth->new();
#   my $user = NMIS::User->new();
#
#   if ( $auth->Required ) {
#        $user->SetUser( $auth->verify_id );
#        # $user should be set at this point, if not then redirect
#        unless ( $user->user ) {
#                $auth->do_force_login("Authentication is required. Please login.");
#                exit 0;  # extraneous as do_force_login with terminate
#        }
#   }
#

#   
package NMIS::Auth;

use vars qw(@ISA @EXPORT @EXPORT_OK %EXPORT_TAGS $VERSION);

use Exporter;

$VERSION = "0.1.1";

@ISA = qw(Exporter);

@EXPORT = qw(
    Require
    verify_id
    user_verify
    do_login
    do_logout
    do_force_login
    generate_cookie
);

use strict;
use lib "../../lib";

# import external symbols from NMIS module
use NMIS ;

# import NMIS security modules
use NMIS::Users qw();

# import additional modules
use Time::ParseDate;
use File::Basename;

# declare any forward subroutines
sub do_login_banner;
sub do_login_footer;

#use CGI qw(:all start_table end_table start_Tr end_Tr start_td end_td);
# I prefer the use of the library when debugging the resulting HTML script
# either one will work
use CGI::Pretty qw(:standard form *table *Tr *td center b h1 h2);
$CGI::Pretty::INDENT = "  ";
$CGI::Pretty::LINEBREAK = "\n";
push @CGI::Pretty::AS_IS, qw(p h1 h2 center b comment);

# You should change this to be unique for your site
#
my $CHOCOLATE_CHIP = '8fhmgBC4YSVcZMnBsWtY32KQvTE9JBeuIp1y';

sub new {
	my $this = shift;
	my $class = ref($this) || $this;
	my $self = {
		_require => 0
	};
	bless $self, $class;
	$self->_auth_init;
	return $self;
}

sub Require {
	my $self = shift;
	return $self->{_require};
}

sub CheckAccess {
	my $self = shift;
	my $user = shift;
	my $cmd = shift;
	my $type = shift;
	my $C = \%NMIS::config;
	
	my @cookies = ();

	# check if authentication is required
	return 1 if not $C->{auth_require};
	return 1 unless $self->{_require};

	if ( ! $user->user ) { 
		&do_force_login("Authentication is required. Please login");
		exit 0;
	}

	return 1 if $user->CheckAccess($cmd);
	return 0 if $type eq "check"; # return the result of the check

	# Authorization failed--put access denied page and stop
	push @cookies, generate_cookie($user->user);
        print header(-target=>"_top", -type=>"text/html", -expires=>'now', -cookie=>"@cookies") . "\n";
        print start_html(-title=>"Authorized Access",
                -base=>'false',
		-xbase=>&url(-base=>1)."$C->{'<url_base>'}",
                -target=>'_top',
                -meta=>{'keywords'=>'network management NMIS'},
                -style=>{'src'=>$C->{styles}},
                -BGCOLOR=>'white'
        );
        print NMIS::Auth->do_login_banner();
        print h2(p({style=>"color:red;"}, "Access denied."));
        print p("Authorization required to access this function.\n");
        print p("You must either ",
                 a({href=>$NMIS::config{'<cgi_url_base>'}."/nmiscgi.pl?type=login"}, "login"),
                " or return to the ",
                a({href=>$NMIS::config{'<cgi_url_base>'}."/nmiscgi.pl"}, "main Dashboard."));
        print NMIS::Auth->do_login_footer();
	print end_html;
        exit 0;
}

sub _auth_init {
	my $self = shift;
	$self->{_require} = $NMIS::config{auth_require};
}

##########################################################################
#
# The following routines in whole and in part are from Routers2.cgi and
# are copyrighted by Steve Shipway and included and used herein with
# permission. 
#
# Copyright (C) 2000, 2001, 2002 Steve Shipway
#
# The following routines are covered by this copyright and the GNU GPL.
#    verify_id
#    user_verify
#    _file_verify
#    _ldap_verify
#    generate_cookie
#
# All Java code include herein is also courtesy of Steve Shipway.
#
###########################################################################
# for security - create login page, verify username/password/cookie
# routers.conf:
#
# verify_id -- reads cookies and params, returns verified username
sub verify_id {
	my $self = shift;
	my($uname,$cookie,$checksum, $token);

	$uname = user_name(); # set by web server
	return $uname if($uname);

	# now taste cookie 
	$cookie = cookie('auth');
	if(!$cookie) {
		logMessage("Auth, cookie empty, maybe cookies not enabled");
		return '' ;
	}
	if($cookie !~ /^\s*([^:]+):(.*)$/) {
		logMessage("Auth, bad format cookie");  # bad format
		return '' ; 
	}
	($uname, $checksum) = ($1,$2);
	$token = $uname . remote_host();
	$token .= $CHOCOLATE_CHIP;       # secret information
#   Can't do this because we havent read in the config file yet
#	$token .= $config{'web-auth-key'} if(defined $config{'web-auth-key'});
	$token = unpack('%32C*',$token); # checksum
#	if( $config{'web-auth-debug'} ) {
#		$debugmessage .= "\ncookie[given[$uname:$checksum],test[$token]]\n";
#	}
	return $uname if( $token eq $checksum ); # yummy
	
	# bleah, nasty taste
	return '';
}

# call appropriate verification routine
sub user_verify {
	my $self = shift;
	my($rv) = 0; # default: refuse
	my($u,$p) = @_;
	my $C = \%NMIS::config;

	if ( ! defined($C->{auth_method}) ) {
		$C->{auth_method} = "htpasswd";
	}
	if( $C->{auth_method} eq "htpasswd" ) {
		$rv = _file_verify($C->{AuthUserFile},$u,$p,$C->{auth_encrypt});
		return $rv if($rv);
	}

	if( $C->{auth_method} eq "radius" ) {
		$rv = _radius_verify($u,$p);
		return $rv if($rv);
	}

	if( $C->{auth_method} eq "system" ) {
		$rv = _system_verify($u,$p);
		return $rv if($rv);
	}

#	if( $NMIS::config{auth_method} eq "ldaps") ) {
#		$rv = _ldap_verify($u,$p,1);
#		return $rv if($rv);
#	}
#	if( !$rv $config{auth_method} eq "ldap" ) {
#		$rv = _ldap_verify($u,$p,0);
#		return $rv if($rv);
#	}
#	if( defined( $config{'web-htpasswd-file'} ) ) {
#		$rv = _file_verify($config{'web-htpasswd-file'},$u,$p,1);
#		return $rv if($rv);
#	}
#	if( defined( $config{'web-md5-password-file'} ) ) {
#		$rv = _file_verify($config{'web-md5-password-file'},$u,$p,2);
#		return $rv if($rv);
#	}
#	if( defined( $config{'web-unix-password-file'} ) ) {
#		$rv = file_verify($config{'web-unix-password-file'},$u,$p,3);
#		return $rv if($rv);
#	}
	logMessage("Auth, user=$u auth failed, method=$C->{auth_method}") if $C->{auth_debug};
	return 0;
}
# verify against a password file:   username:password
sub _file_verify {
	my($pwfile,$u,$p,$encmode) = @_;
	my($fp,$salt,$cp);
	my $debugmessage = "";
	my $C = \%NMIS::config;

	$encmode = 0 if $encmode eq "plaintext";
	$encmode = 1 if $encmode eq "crypt";
	$encmode = 2 if $encmode eq "md5";

	open PW, "<$pwfile" or return 0;
	while( <PW> ) {
		if( /([^\s:]+):([^:]+)/ ) {
			if($1 eq $u) {
				$fp = $2;
				chomp $fp;
				close PW; # we are returning whatever
				if($encmode == 0) { # unencrypted. eek!
					return 1 if($p eq $fp); 
				} elsif ($encmode == 1) { # htpasswd (unix crypt)
					if($C->{crypthack}) {
					 require Crypt::UnixCrypt;
					 $Crypt::UnixCrypt::OVERRIDE_BUILTIN = 1;
					}
					$salt = substr($fp,0,2);
					$cp = crypt($p,$salt); 
					return 1 if($fp eq $cp); 
				} elsif ($encmode == 2) { # md5 digest
					require Digest::MD5;
					return 1 if($fp eq Digest::MD5::md5($p));
				} elsif ($encmode == 3) { # unix crypt
					if($C->{crypthack}) {
					 require Crypt::UnixCrypt;
					 $Crypt::UnixCrypt::OVERRIDE_BUILTIN = 1;
					}
					$salt = substr($fp,0,2);
					$cp = crypt($p,$salt); 
					return 1 if($fp eq $cp); 
				} # add new ones here...
				logMessage("Auth, mismatch password [$u][$p]:[$fp]!=[$cp], method=htpasswd") if $C->{auth_debug};
				return 0;
			} else {
				$debugmessage .= "Mismatch user [$1][$u]";
			}
		} else {
			$debugmessage .= "Bad format line $_";
		}
	}
	close PW;
	logMessage("Auth, $debugmessage by method=htpasswd") if $C->{auth_debug};
	return 0; # not found
}
# LDAP verify a username
sub _ldap_verify {
	my($u, $p, $sec) = @_;
	my($dn,$context,$msg);
	my($ldap);
	my($attr,@attrlist);
	my $C = \%NMIS::config;

	if($sec) {
		# load the LDAPS module
		eval { require IO::Socket::SSL; require Net::LDAPS; };
		if($@) { return 0; } # no Net::LDAPS installed
	} else {
		# load the LDAP module
		eval { require Net::LDAP; };
		if($@) { return 0; } # no Net::LDAP installed
	}

	# Connect to LDAP and verify username and password
	if($sec) {
		$ldap = new Net::LDAPS($C->{'web-ldaps-server'});
	} else {
		$ldap = new Net::LDAP($C->{'web-ldap-server'});
	}
	if(!$ldap) { return 0; }
	@attrlist = ( 'uid','cn' );
	@attrlist = split( " ", $C->{'web-ldap-attr'} )
		if( $C->{'web-ldap-attr'} );
	
	foreach $context ( split ":", $C->{'web-ldap-context'}  ) {
		foreach $attr ( @attrlist ) {
			$dn = "$attr=$u,".$context;
			$msg = $ldap->bind($dn, password=>$p) ;
			if(!$msg->is_error) {
				$ldap->unbind();
				return 1;
			}
		}
	}

	return 0; # not found
}


# generate_cookie -- returns a cookie with current usrname, expiry
sub generate_cookie {
	my $self = shift;
	my $authuser = shift;
	my($cookie);
	my($exp) = "+1min"; # note this stops wk/mon/yrly autoupdate from working
	my($token);
	my $C = \%NMIS::config;

	
	return "" if ( ! $authuser );

	$exp = $C->{auth_expire} if ( defined $C->{auth_expire} );
	$exp = "+10min" if ( ! $exp ); # some checking for format

	$token = $authuser . remote_host(); # should really have time here also
	$token .= $CHOCOLATE_CHIP;          # secret information
#	$token .= $config{'web-auth-key'} if(defined $config{'web-auth-key'});
	$token = $authuser . ':' . unpack('%32C*',$token); # checksum

	$cookie = cookie({name=>'auth', value=>$token, path=>$C->{'<cgi_url_base>'}, expires=>$exp} ) ;
	logMessage("Auth, cookie=$cookie generated for user=$authuser") if $C->{auth_debug};
	return $cookie;
}

##########################################################################
#
# The following routines were inspired as part of Routers2.cgi but
# but where completely gutted to suit my purposes. As they are no
# longer recognizable by Steve I take full responsibility of these
# modules and the maintenance.
#
# Copyright (C) 2005 Robert W. Smith
#
# The following routines are covered by this copyright and the GNU GPL.
# do_login -- output HTML login form that submits to top level
#
sub do_login {
	my $self = shift;
	my $msg = shift;
	my $C = \%NMIS::config;

	# this is sent if auth = y and page = top (or blank),
	# or if page = login
        print header(-target=>"_top", -type=>"text/html", -expires=>'now') . "\n";
        print start_html(-title=>$C->{login_title},
                -author=>'rwsmith@bislink.net',
                -base=>'false',
		-xbase=>&url(-base=>1)."$C->{'<url_base>'}",
                -target=>'_blank',
                -meta=>{'keywords'=>'network management NMIS'},
                -style=>{'src'=>$C->{styles}},
                -BGCOLOR=>'black'
        );
        print comment("type login requested");
        print comment("start page table");
	print start_table, start_Tr, start_td({class=>"white"});

	print &do_login_banner;

	print end_td, end_Tr;
	print comment("start form table");
	print start_Tr, start_td({style=>"border: 0; margin: 0; padding: 0"}),
		start_table({width=>"640", align=>"center", class=>"login"}),
		start_Tr,
		start_td,
		start_table({width=>"100%", class=>"login1"});
	print Tr(td(div({align=>"center", style=>"font: 16pt bold serif; font-color: black;"},"Authentication required")));

	print Tr(td(
		p("\nPlease log in with your appropriate username and password in order to gain access to this system.")));
	
	print start_Tr,
		start_td;
	print start_form({method=>"POST", action=>url(-absolute=>1), target=>"_top"}),
		table({align=>"center", width=>"50%", class=>"login2"},
		  Tr(td(b("Username")) . td(textfield({name=>'username'}) )) .
		  Tr(td(b("Password")) . td(password_field({name=>'password'}) )) .
		  Tr(td("") . td(submit({name=>'login',value=>'Login'}) ))
		),
		end_form;
	print end_td,
		end_Tr;

	print Tr(td(p({style=>"color: red"}, "&nbsp;$msg&nbsp;")));

	print end_table,
		end_td,
		end_Tr,
		end_table,
		end_td, end_Tr;
	print comment("end form table");

	print start_Tr, start_td({class=>"white"}),
		&do_login_footer,
		end_td, end_Tr;
	
	print end_table;
	print comment("end page table");

	print end_html . "\n";
}

##############################################################################
#
# The java script herein is courtesy of the Steve Shipway and is copyrighted
# by him.
# 
# do_force_login -- output HTML that sends top level to login page
#
sub do_force_login {
	my $self = shift;
	my($javascript);
	my($err) = shift;
	my $C = \%NMIS::config;
	# Javascript that sets window.location to login URL
	# This is created if auth = y and page != login and !authuser

	$javascript = "function redir() { ";
	$javascript .= "alert('$err'); " if($err);
	$javascript .= " window.location = '" . url(-base=>1) . $C->{'<cgi_url_base>'} . "/nmiscgi.pl?type=login'; }";

	$javascript = "function redir() {} " if($C->{'web-auth_debug'});

	print header({ target=>'_top', expires=>"now" })."\n";
	print start_html({ title =>"Login Required",
	expires => "now",  script => $javascript,
	onload => "redir()", text=>"#000000", bgcolor=>"#ffffff" }),"\n";
##	onload => "redir()", text=>$deffgcolour, bgcolor=>$defbgcolour }),"\n";
	print h1("Authentication required")."\n";
	print "Please ".a({href=>"&url(-base=>1)?type=login"},"login")
		." before continuing.\n";

	print start_Tr, start_td;
	print &do_login_footer;
	print end_td, end_Tr;

	print "<!-- $err -->\n";
	print end_html;
}

# do_logout -- set auth cookie to blank, expire now, and redirect to top
#
sub do_logout {
	my $self = shift;
	my($cookie,$javascript);
	my $C = \%NMIS::config;
	# Javascript that sets window.location to login URL

	$javascript = "function redir() { window.location = '" . url(-full=>1) . "?type=login'; }";
	$cookie = cookie({ -name=>'auth', -value=>'', 
		-path=>$C->{'<cgi_url_base>'}, -expires=>"now"} ) ;

	print header({ -target=>'_top', -expires=>"5s",
		-cookie=>[$cookie] })."\n";
	print start_html({ -title =>"Logout complete",
	-expires => "5s",  -script => $javascript, -onload => "redir()",
	-text=>"#000000", -bgcolor=>"#ffffff" }),"\n";

        print comment("start page table");
	print start_table({width=>"100%"}),
		start_Tr, start_td;
	print &do_login_banner;
	print end_td, end_Tr;
	print Tr(td({class=>"white"}, p(h1("Logged out of system") .
	p("Please " . a({href=>url(-full=>1) . "?type=login"},"go back to the login page") ." to continue."))));

	print start_Tr, start_td,
		&do_login_footer,
		end_td, end_Tr;

	print end_table, end_html;
}

#####################################################################
#
# The following routines are courtesy of Robert W. Smith, copyrighted
# and covered under the GNU GPL.
#
sub do_login_banner {
	my $self = shift;
	my @banner = ();
	my $C = \%NMIS::config;

	my $time = &NMIS::get_localtime;

	push @banner,  comment("login banner start");
        push @banner, table({width=>"100%", cellpadding=>"5", class=>"dash"},
		Tr(
		  td({width=>"15%", align=>"left", class=>"menugrey"},
			img({src=>$C->{'banner_image'}, alt=>$C->{banner_img_alt}, border=>"0"}))
		  . td({align=>"center", class=>"dash"},
			font({style=>"font: 20pt bolder; font-color: white"}, $C->{banner_title}))
		  . td({width=>"15%", align=>"right", class=>"menugrey"},
			div({align=>"center", style=>"font: 10pt bold; font-color: black"},
				"$time"))
		));
	push @banner,  comment("login banner end");

	return @banner;
}

sub do_login_footer {
	my $self = shift;
	my @banner = ();
	my $C = \%NMIS::config;

	push @banner, comment("Footer start");
	push @banner, table({width=>"100%", class=>"dash"},
		  Tr(td({align=>"center", class=>"menugrey"},
			font({style=>"font: 10pt normal; font-color: black"}, $C->{'footer_text'}))));
	push @banner, comment("Footer end");

	return @banner;
}

#####################################################################
#
# The following routines are courtesy of the NMIS source and copyrighted
# by Sinclair Internetworking Ltd Pty and covered under the GNU GPL.
#
sub get_time {
        # pull the system timezone and then the local time
        if ($^O =~ /win32/i) { # could add timezone code here
                return scalar localtime;
        }
        else { # assume UNIX box - look up the timezone as well.
		my $lt = scalar localtime;
		$lt =~ s/  / /;
                return uc((split " ", `date`)[4]) . " " . $lt;
        }
}

#####################################################################
#
# 25 May 2005, rwsmith:
# I'm not ready to release this yet until I consult with more experienced 
# encryption experts. 
#
# System authentication routine
#
sub _system_verify {

}

#####################################################################
#
# 5-10-06, Cologne
#

sub _radius_verify {
	my($user, $pswd) = @_;
	my $C = \%NMIS::config;

	require Authen::Simple::RADIUS; # installed from CPAN

	my ($host,$port) = split(/:/,$C->{auth_radius_server});
	if ($host eq "") {
		logMessage("Auth, no radius server address specified in nmis.conf");
	} elsif ($C->{auth_radius_secret} eq "") {
		logMessage("Auth, no radius secret specified in nmis.conf");
	} else {
		$port = 1645 if $port eq "";
		my $radius = Authen::Simple::RADIUS->new(
			host   => $host,
			secret => $C->{auth_radius_secret},
			port => $port
		); 
		if ( $radius->authenticate( $user, $pswd ) ) {
	        return 1;
		}
	}
	return 0;
}

1;
