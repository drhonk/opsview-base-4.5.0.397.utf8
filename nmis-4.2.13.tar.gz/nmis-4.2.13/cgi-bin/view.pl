#!/usr/bin/perl
#
# $Id: view.pl,v 1.32 2006/10/04 09:23:51 decologne Exp $
#
#
#    view.pl - NMIS View Tables Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#	ehg 26 sep 02 added KS patch for mutiple conf file add and delete functionality
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 

# 
#****** Shouldn't be anything else to customise below here *******************

use strict;
use web;
use NMIS;
use func;
use csv;

# Prefer to use CGI for html processing
use CGI qw(:standard);

# declare holder for CGI objects
use vars qw($q);
$q = new CGI; # This processes all parameters passed via GET and POST

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

my $scriptname = $ENV{SCRIPT_NAME};

# Break the query up for the names
my $type = $q->param('type');
my $node = $q->param('row');
my $conf = $q->param('file');
my $table = $q->param('table');
my $edit = $q->param('edit');
my $name = $q->param('name');
my $column = $q->param('column');
my $value = $q->param('value');
my $change = $q->param('change');
my $node = $q->param('node');
my $runupdate = $q->param('runupdate');
my $add = $q->param('add');
my $row = $q->param('row');
my $debug = $q->param('debug');

my @services = $q->param('services');
my @msgroup = $q->param('groups');
my @depend = $q->param('depend');

# Allow program to use other configuration files
$conf = "nmis.conf" if $conf eq "";
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

# Before going any further, check to see if we must handle
# an authentication login or logout request

$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

eval {
	require NMIS::Auth or die "NO_NAUTH module";
};
if ( $@ =~ /NO/ ) {
	$auth = \{ Require => 0 };
} else {
	$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
	$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth
}

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# logout ?
	if ( $type eq 'logout' ) {
       	$auth->do_logout;
		exit 0;
	}

	# verify access to this action
	# check access for table
	$auth->CheckAccess($user, lc $table) or die "Attempted unauthorized access";

	# generate the cookie if $user->user is set
	if ( $user->user ) {
        push @cookies, $auth->generate_cookie($user->user);
        $headeropts{-cookie} = [@cookies];
	}
}

# load node table to filter on group access list
&loadNodeDetails;
my @groups = ();
my @nodes = ();
my %privmap = ();
my @privs = ();
foreach (sort split(",",$NMIS::config{group_list})) { push @groups, $_ if $user->InGroup($_); }
foreach (sort keys %NMIS::nodeTable) { push @nodes, $_ if $user->InGroup($NMIS::nodeTable{$_}{group}); }

%privmap = loadCSV($NMIS::config{'<nmis_conf>'}."/privmap.csv", 'privilege');
# I assume a natural order: administrator = 0 (highest priv) and guest = 6 (lowest priv)
foreach (keys %privmap) { @privs[$privmap{$_}{level}] = $_ unless /_notused/i; } 
%privmap = ();

# set some defaults for commonly used tables
# could add your own defaults here
# single value boxes can be typed over for the desired value on the web interface for edit/add
# multi-value are presented as a pre-defined selection box

my %defaults = ( Nodes => { snmpport => ["161"],
							community => ["$NMIS::config{communityRO}"],
							active => ["true", "false"],
							calls => ["true", "false"],
							collect => ["true", "false" ],
							cbqos => ["false", "input", "output", "both" ],
							devicetype => ["router", "switch", "server", "generic"],
							group => [ split "," , $NMIS::config{group_list} ],
							net => ["wan", "lan"],
							role => ["core", "distribution", "access"],
							node => ["node.$NMIS::config{domain_name}"],
							runupdate => ["true", "false"],
							rancid => ["true", "false"],
							depend => [ "N/A", sort keys %{{loadCSV($NMIS::config{Nodes_Table},$NMIS::config{Nodes_Key},"\t")}} ],
							services => ["N/A", sort keys %{{loadCSV($NMIS::config{Services_Table},$NMIS::config{Services_Key},"\t")}} ]
						},
				Events => { Event => ["Generic Down", "Generic Up", "Interface Down", "Interface Up",
									"Node Down", "Node Reset", "Node Up", "Node Failover", "Proactive", "Proactive Closed",
									"RPS Fail", "TRAP", "SNMP Down", "SNMP Up",
									"Service Down", "Service Up",],
							Role => ["core", "distribution", "access"],
							Type => ["router", "switch", "server", "generic"],
							Level => ["Normal", "Warning", "Major", "Critical", "Fatal"],
							Log =>  ["true", "false"],
							Mail => ["true", "false" ],
							Notify => ["true", "false" ],
							Pager => ["true", "false" ]
						},
				Escalation => { Group => ["default", split "," , $NMIS::config{group_list}], 
							Role => ["default", "core", "distribution", "access"],
							Type => ["default", "router", "switch", "server", "generic"],
							Event => ["default", "Generic Down", "Generic Up", "Interface Down", "Interface Up",
									"Node Down", "Node Reset", "Node Failover", "Node Up",
									"RPS Fail", "TRAP", "SNMP Down", "SNMP Up",
									"Service Down", "Service Up",
									"Proactive Response Time Threshold",
									"Proactive Reachability Threshold",
									"Proactive CPU Threshold",
									"Proactive Memory Threshold",
									"Proactive Interface Availability Threshold",
									"Proactive Interface Input Utilisation",
									"Proactive Interface Output Utilisation",
									"Proactive Availability Threshold Interface",
									"Proactive Interface Input NonUnicast",
									"Proactive Interface Output NonUnicast"],
							Event_Details => ["."],
							Event_Node => ["."],
							Level0 => ["netsend:WKS1:WKS2,email:Contact1"],
							Level1 => ["pager:sysContact,email:Contact2"],
							Level3 => ["email:Contact3:Contact4"],
							UpNotify => ["false", "true" ]
						},
				Thresholds => { threshold => ["available", "cpu", "int_avail", "mem", "nonucast",
									"reachable", "response", "util", "modem", "modem_util", "calls_util",
									"hrdisk", "hrcpu", "hrmem", "hrsmpcpu"],
							role => ["default", "core", "distribution", "access"],
							type => ["default", "router", "switch", "server", "generic"],
							node => ["default"],
							interface => ["default"],
							fatal => ["80"],
							critical => ["70"],
							major => ["60"],
							minor => ["50"],
							warning => ["40"]
						},
				Locations => { Location => ["AKL-1"],
							Address1 => ["1 Any Street"],
							Address2 => ["PO Box 10"],
							Altitude => ["10m"],
							City => ["Auckland"],
							Country => ["New Zealand"],
							Floor => ["Level 1"],
							Latitude => ["36 51 S"],
							Longitude => ["174 46 E"],
							Postcode => ["2003"],
							'Room Number' => ["Room 1"],
							State => ["NA"],
							Suburb => ["Auckland"]
						},
				Contacts => { Contact => ["Contact1"],
							DutyTime => ["00:24:MonTueWedThuFriSatSun"],
							Email => ["contact1\@$NMIS::config{domain_name}"],
							Location => ["default"],
							Mobile => ["+64 xxx-xxxx"],
							Pager => ["+64 xxx-xxxx"],
							Phone => ["+64 xxx-xxxx"],
							TimeZone  => ["0"]
						},
				SysNode => { Node => [ sort keys %{{loadCSV($NMIS::config{Nodes_Table},$NMIS::config{Nodes_Key},"\t")}} ]
						},
				SysInt => { Node => [ sort keys %{{loadCSV($NMIS::config{Nodes_Table},$NMIS::config{Nodes_Key},"\t")}} ],
							ifIndex => ["1"]
						},
				Services => { Service_Type => [ 'service', "port", "dns", 'script', 'wmi' ],
							Poll_Interval => [ "5m", "1h", "1d" ]
						},
				Users => {
							user => [ "default" ],
							privilege => [ (@privs) ],
							groups => ["none", "all", "network", (@groups) ]
						},
				Toolset => {
							button => [""],
							bgroup => ["action","plugin","table","tool","access"],
							order => [scalar keys %{{loadCSV($NMIS::config{Toolset_Table},$NMIS::config{Toolset_Key},"\t")}}],
							display => [""],
							level0 => ["1","0"],
							level1 => ["0","1"],
							level2 => ["0","1"],
							level3 => ["0","1"],
							level4 => ["0","1"],
							level5 => ["0","1"],
							urlbase => [""],
							urlscript => [""],
							useconfig => [""],
							needconfig => ["no","yes"],
							urlquery => [""],
							usetarget => [""]
						}

);


my $counter;
my $group;

my $colspan = 7;

my %types;
my %categories;
my @fields;
my $nmis_url = "<a href=\"$NMIS::config{nmis}?file=$conf\"><img alt=\"NMIS Dash\" src=\"$NMIS::config{nmis_icon}\" border=\"0\"></a>";
my $back_url = "<a href=\"$ENV{HTTP_REFERER}\"><img alt=\"Back\" src=\"$NMIS::config{back_icon}\" border=\"0\"></a>";
my $help_url = lc("<a href=\"$NMIS::config{'<url_base>'}/$table.pod.html\"><img alt=\"Help\" src=\"$NMIS::config{help_icon}\" border=\"0\"></a>");

# if modifying a node record, trash all events associated with that node

if ( $table eq "Nodes" and $edit ne "" and $change eq "true") {
	cleanEvent($node);
}

# if runupdate set, run an update, and toggle runupdate back to false
# note that this will force nmis.pl to skip the pingtest as we are a non-root user !!
if ( $table eq "Nodes" and $runupdate eq "true" and $edit ne "" and $change eq "true") {

	# could test for valid node here, resolve hostname etc ?? display a status box ??
	# for now - just pipe the output of a debug run, so the user can see what is going on !

	# first, save the record just edited !
	$runupdate = "false";		# toggle back to false !
	&editRow(table => $table, row => $row, edit => $edit );	# save it.
	my $tmp = &table."_Title";
	my $header = "NMIS $NMIS::config{$tmp}";


	# now run the update and display 
	pageStart($header,$NMIS::config{style}, \%headeropts);

	print "<pre>\n";
	print "Running update on node $node - Please wait.....\n\n\n";

	open(PIPE, "$NMIS::config{'<nmis_bin>'}/nmis.pl type=update node=$node debug=true 2>&1 |"); 
	select((select(PIPE), $| = 1)[0]);			# unbuffer pipe
	select((select(STDOUT), $| = 1)[0]);			# unbuffer pipe

	while ( <PIPE> ) {
		print ;
	}
	close(PIPE);
	print "\n\nCompleted web user initiated update of $node</pre>\n\n";
	
	&displayTable(table => $table, name => $name, column => $column, value => $value);


}

elsif ( ( $edit eq "delete" or $edit ne "" or $add eq "true" ) and $change ne "true" ) {
        &editRowMenu(table => $table, row => $row, edit => $edit);
}
elsif ( $edit ne "" and $change eq "true" ) {
        if( &editRow(table => $table, row => $row, edit => $edit) == 0) {exit;};
        &displayTable(table => $table, name => $name, column => $column, value => $value);
}
elsif ( $table ne "" ) {
        &displayTable(table => $table, name => $name, column => $column, value => $value);
}
else { };
exit;

sub editRow {
	my %args = @_;
	my $table = $args{table};
	my $row = $args{row};
	my $edit = $args{edit};
	my $name = $args{name};
	my $column = $args{column};
	my $value = $args{value};

	my $field;
	my @headers;
	my $head;
	my $i;
	my $tmp;
	my $table_file = $table."_Table";
	my $key = $table."_Key";
	my %table_data = loadCSV($NMIS::config{$table_file},$NMIS::config{$key});
	# if empty, just get the headers, so we can add a new row to an empty table.
	if ( ! %table_data ) {
		my @headrow = loadCSVHeaders($NMIS::config{$table_file});
		while ( scalar @headrow ) {
			$table_data{$row}{pop(@headrow)} = "";
		}
	}

	if ( $edit ne "delete" ) {
		if ( $row eq "add" and $edit eq "true" ) {
			# check on duplicated key
			my $kk;
			if ($NMIS::config{$key} ne "") {
				for my $n (split(/:/,$NMIS::config{$key})){
					$kk .= "_" if $kk ne "";
					$kk .= $q->param($n);
				}
				if ( exists $table_data{$kk}) {
					pageStart("VIEW","true",\%headeropts);
					cssHeaderBar("Key $kk already exists in table $table ","grey");
					pageEnd;
					return 0;
				}
			}
			# AS 09.05.02 Ambrose Li's sort patch
			foreach $key (sort alphanumerically (keys %table_data)) {
				if ( not defined $tmp ) { $tmp = $table_data{$key}; }
			}
		}
		elsif ( $row ne "" and $edit ne "add" ) {
			$tmp = $table_data{$row};
		}
		# need to get a row to build the menu.
		# AS 09.05.02 Ambrose Li's sort patch
		foreach $field (sort alphanumerically (keys %$tmp)) {
			$table_data{$row}{$field} = $q->param($field);
			# we have a list of dependancies in *_Table
			if ( $table eq "Nodes" and $field eq 'depend' ) { $table_data{$row}{$field} = join ',', @depend; }
			if ( $table eq "Users" and $field eq 'groups' ) { $table_data{$row}{$field} = join ',', @msgroup; }
			if ( $table eq "Nodes" and $field eq 'services' ) { $table_data{$row}{$field} = join ',', @services; }
			#print STDERR returnTime." editRow, field=$field row=$row table=$table_data{$row}{$field}\n";
		}
	}
	else {
		# better keep a copy of the headers, in case we are deleting the last row !
		undef @headers;
		foreach ( keys %{$table_data{$row}} ) {
			push @headers, $_;
		}
		delete $table_data{$row};
	}
	if ( %table_data) {
		&writeCSV(%table_data,$NMIS::config{$table_file},"\t");
	}
	# if an empty table, we deleted the last row, so just write the headers out, and we can add a new row later
	else {
		&writeCSVHeaders(@headers,$NMIS::config{$table_file},"\t");
	}
	return 1;
}

sub editRowMenu {
	my %args = @_;
	my $table = $args{table};
	my $row = $args{row};
	my $edit = $args{edit};
	my $name = $args{name};
	my $column = $args{column};
	my $value = $args{value};
	
	my $short_table = $table;
	my $field;
	my $tmp_key;
	my $header;
	my $header2;
	my $wide = 2;
	my $counter = 1;
	my $pass = 1;
	my @headers;
	my $i;
	my $head;
	my $tmp;
	my $colspan;
	my $button;
	
	my $table_file = $table."_Table";
	my $key = $table."_Key";
	$tmp = $table."_Title";
	$header = "NMIS $NMIS::config{$tmp}";
	$header2 = "$back_url$nmis_url$help_url NMIS $NMIS::config{$tmp}";

	my %table_data = loadCSV($NMIS::config{$table_file},$NMIS::config{$key});
	# if empty, populate with the headers, so we can add a new row to an empty table.
	if ( ! %table_data ) {
		my @headrow = loadCSVHeaders($NMIS::config{$table_file});
		while ( scalar @headrow ) {
			$table_data{$NMIS::config{$key}}{pop(@headrow)} = "";
		}
	}

	if ( $debug eq "true") { ++$colspan; }
	$short_table =~ s/s$//g;
	pageStart($header,$NMIS::config{style}, \%headeropts);
	print Tr(td({width=>"100%"}, &do_dash_banner($auth->Require, $user->user) ));
	tableEnd;
	cssTableStart("plain");

	print "<tr><td class=\"view_header\" colspan=\"2\">$header2</td></tr>\n";

	# make the header the row.
	if ( $row ne "" ) {
		$button = "EDIT";
		$tmp_key = $table_data{$row};
	}
	# need to get a row to build the menu.
	else {
		$button = "ADD";
		$row = "add";
		foreach $key  ( keys %table_data ) {
			if ( not defined $tmp_key ) { $tmp_key = $table_data{$key}; }
		}
	}
	# put the header in order with $key at front.
	my @key_head = split(/:/,$NMIS::config{$key});
	my $c = 0;
	for $i (0..$#key_head) {
		$headers[$i] = $key_head[$i];
		++$c;
	}
	$i = $c;
	foreach $head (sort alphanumerically (keys %$tmp_key)) {
		if ( $NMIS::config{$key} !~ /$head/ ) {
			$headers[$i] = $head;
			++$i;
		}
	}

	print "<form action=\"$ENV{SCRIPT_NAME}\" method=\"get\">\n";
	foreach $field (@headers) {

		# use defaults for new and edited fields
		if ( $button eq "ADD" and exists $defaults{$table}{$field} ) {

			# if 1 default only, just print it, so it can be edited.
			if ( $#{$defaults{$table}{$field}} == 0 ) {
				print "<tr><td width=\"150\" class=\"head\">$field</td>\n";
				print "<td class=\"view\" width=\"200\"><input type=\"text\" size=\"40\" name=\"$field\" value=\"$defaults{$table}{$field}[0]\"></td></tr>\n";
			}
			else {
				# print multiple and select the first, user cannot edit - only select
				print "<tr><td width=\"150\" class=\"head\">$field</td>\n";
				# if field 'depend' or 'services' then multiple select
				if ( $field =~ /depend|services/ ) {
					my $size=10;
					if (  $#{$defaults{$table}{$field}} < 10 ) { $size=$#{$defaults{$table}{$field}} + 1 }
					print "<td class=\"view\" width=\"200\"><select multiple style=\"width:100%\" size=\"$size\" name=\"$field\">\n";
					foreach my $option  ( @{$defaults{$table}{$field}} ) {
		 				print "<option value=\"$option\">$option</option>\n";
		 			}
					print "</select></td>\n";
 				} elsif ( $table eq 'Users' and $field eq 'groups' ) {
					my $size = 6;
					if (  $#{$defaults{$table}{$field}} < 6 ) { $size=$#{$defaults{$table}{$field}} + 1 }
					print "<td class=\"view\" width=\"200\">" .
						"<select multiple style=\"width:100%\" size=\"$size\" name=\"$field\">\n";
					foreach my $option  ( @{$defaults{$table}{$field}} ) {
						# remember selection and only use valid nodes from prefilled list
		 				if ( $table_data{$row}{$field} =~ /$option/ ) {
							print "<option selected value=\"$option\">$option</option>\n"
						} else { print "<option value=\"$option\">$option</option>\n" }
		 			}
					print "</select></td>\n";
				} else {
					print "<td class=\"view\" width=\"200\"><select style=\"width:100%\" size=\"1\" name=\"$field\">\n";
					foreach my $option  ( @{$defaults{$table}{$field}} ) {
		 				print "<option value=\"$option\">$option</option>\n";
		 			}
					print "</select></td>\n";
				}
			}
		}
		elsif ( $button eq "EDIT" and exists $defaults{$table}{$field} ) {

			# if 1 default only, just print existing value so it can be edited
			if ( $#{$defaults{$table}{$field}} == 0 ) {
				print "<tr><td width=\"150\" class=\"head\">$field</td>\n";
				print "<td class=\"view\" width=\"200\"><input type=\"text\" size=\"40\" name=\"$field\" value=\"$table_data{$row}{$field}\"></td></tr>\n";
			}
			else {
				# print select the existing value, append the defaults, user cannot edit, only select
				print "<tr><td width=\"150\" class=\"head\">$field</td>\n";
				# if field 'depend' or 'services' then multiple select
				if ( $field =~ /depend|services/ ) {
					my $size = 10;
					if (  $#{$defaults{$table}{$field}} < 10 ) { $size=$#{$defaults{$table}{$field}} + 1 }
					print "<td class=\"view\" width=\"200\"><select multiple style=\"width:100%\" size=\"$size\" name=\"$field\">\n";
					foreach my $option  ( @{$defaults{$table}{$field}} ) {
						# remember selection and only use valid nodes from prefilled list
		 				if ( $table_data{$row}{$field} =~ /$option/ ) { print "<option selected value=\"$option\">$option</option>\n" }
						else { print "<option value=\"$option\">$option</option>\n" }
		 			}
					print "</select></td>\n";
				} elsif ( $table eq 'Users' and $field eq 'groups' ) {
					my $size = 6;
					if (  $#{$defaults{$table}{$field}} < 6 ) { $size=$#{$defaults{$table}{$field}} + 1 }
					print "<td class=\"view\" width=\"200\">" .
						"<select multiple style=\"width:100%\" size=\"$size\" name=\"$field\">\n";
					foreach my $option  ( @{$defaults{$table}{$field}} ) {
						# remember selection and only use valid nodes from prefilled list
		 				if ( $table_data{$row}{$field} =~ /$option/ ) {
							print "<option selected value=\"$option\">$option</option>\n"
						} else { print "<option value=\"$option\">$option</option>\n" }
		 			}
					print "</select></td>\n";
				} else {
					print "<td class=\"view\" width=\"200\"><select style=\"width:100%\" size=\"1\" name=\"$field\">\n";
					# always select the current record value
					print "<option selected value=\"$table_data{$row}{$field}\">$table_data{$row}{$field}</option>\n";
					# now append the balance of the defaults
					foreach my $option  ( @{$defaults{$table}{$field}} ) {
		 				if ( $option ne $table_data{$row}{$field} ) { print "<option value=\"$option\">$option</option>\n" }
		 			}
					print "</select></td>\n";
				}
			}
		}
		else {
			# no defaults - just print it.
			print "<tr><td width=\"150\" class=\"head\">$field</td>\n";
			print "<td class=\"view\" width=\"200\"><input type=\"text\" size=\"40\" name=\"$field\" value=\"$table_data{$row}{$field}\"></td></tr>\n";
		}
	}
	print "<input type=\"hidden\" name=\"table\" value=\"$table\">\n";
	print "<input type=\"hidden\" name=\"row\" value=\"$row\">\n";
	print "<input type=\"hidden\" name=\"edit\" value=\"true\">\n";
	print "<input type=\"hidden\" name=\"change\" value=\"true\">\n";
	print "<input type=\"hidden\" name=\"file\" value=\"$conf\">\n";
	print "<tr><td class=\"menugrey\" colspan=\"2\"><input type=\"submit\" value=\"$button\"></td></tr>\n";
	print "</form>\n";
	if ( $edit eq "delete" ) {
		print "<form action=\"$ENV{SCRIPT_NAME}\" method=\"get\">\n";
		print "<input type=\"hidden\" name=\"table\" value=\"$table\">\n";
		print "<input type=\"hidden\" name=\"row\" value=\"$row\">\n";
		print "<input type=\"hidden\" name=\"edit\" value=\"delete\">\n";
		print "<input type=\"hidden\" name=\"change\" value=\"true\">\n";
		print "<input type=\"hidden\" name=\"file\" value=\"$conf\">\n";
		print "<tr><td class=\"menugrey\" colspan=\"2\"><input type=\"submit\" value=\"DELETE\"></td></tr>\n";
		print "</form>\n";
	}
	tableEnd;
	pageEnd;
}

sub displayTable {
	my %args = @_;
	my $table = $args{table};
	my $name = $args{name};
	my $column = $args{column};
	my $value = $args{value};
	my $short_table = $table;
	my $field;
	my $header;
	my $header2;
	my $wide = 2;
	my $counter = 1;
	my $pass = 1;
	my @headers;
	my $i;
	my $c;
	my $tmp;
	my $head;
	my $key;
	my $got_header = 0;
	my $tmp;
	my $colspan;
	my @key_head;
	my $table_file = $table."_Table";
	my $table_key = $table."_Key";
	$tmp = $table."_Title";
	$header = "NMIS $NMIS::config{$tmp}";
	$header2 = "$back_url$nmis_url$help_url NMIS $NMIS::config{$tmp}";

	pageStart($header,$NMIS::config{style}, \%headeropts);
	cssTableStart("white");
	print Tr(td({width=>"100%"}, &do_dash_banner($auth->Require, $user->user) ));
	tableEnd;
	cssTableStart("white");
	print "<tr><td class=\"view_header\" colspan=\"100%\">$header2</td></tr>\n";


	my %table_data = loadCSV($NMIS::config{$table_file},$NMIS::config{$table_key});
	# if empty, just get and print the headers, so we can add a new row to an empty table.
	if ( ! %table_data ) {

		#put the header in order with $key at front.
		@key_head = split(/:/,$NMIS::config{$table_key});
		$c = 0;
		for $i (0..$#key_head) {
			$headers[$i] = $key_head[$i];
			++$c;
		}

		$i = $c;
		foreach $head (sort alphanumerically loadCSVHeaders($NMIS::config{$table_file}) ) {
			if ( $NMIS::config{$table_key} !~ /$head/ ) {
				$headers[$i] = $head;
				++$i;
			}
		}

		rowStart;
		foreach $field ( @headers) {
			cssPrintCell("head","$field",1);
		}
		my $add="<a href=\"$scriptname?file=$conf&table=$table&add=true\">Add</a>";
		if ($ENV{REMOTE_USER} eq "view") {
			$add="View Only" ;
		}
		cssPrintCell("head",$add,1);
		rowEnd;
	}

	if ( $debug eq "true") {	
       		++$colspan;
       	}
       	if ( $name ne "" ) {
		$short_table =~ s/s$//g;
       		$header = "$short_table $name";
       	}
       	if ( $value ne "" ) {
       		$header = $header." - Records for $column=$value";
	} # end ifempty       

	# Display each data Row
	# AS 09.05.02 Ambrose Li's sort patch
	# this will skip if an empty table, headers+add already printed if table was empty.
	foreach $key ( sort alphanumerically (keys %table_data) ) {
		print "\n";
		++$counter;
		++$pass;
		#Get the headers populated quick!
		if ( not $got_header ) {
			$got_header = 1;
			
			#put the header in order with $key at front.
			@key_head = split(/:/,$NMIS::config{$table_key});
			$c = 0;
			for $i (0..$#key_head) {
				$headers[$i] = $key_head[$i];
				++$c;
			}
	
			$i = $c;
			foreach $head (sort alphanumerically (keys %{$table_data{$key}})) {
				if ( $NMIS::config{$table_key} !~ /$head/ ) {
					$headers[$i] = $head;
					++$i;
				}
			}
			
			# Page Start Stuff!
			$colspan = $#headers + 2;
			if ( $debug eq "true" ) {
				print "<tr><td class=\"view\" colspan=\"$colspan\">table=$table_file $NMIS::config{$table_file} key=$key $NMIS::config{$key}</td></tr>\n";	
			}

			#Display Header Row
			## AS 8 June 2002 - Implemented changes for view control.
			rowStart;
			if ( $debug eq "true" ) {
				cssPrintCell("head","key",1);
			}
			foreach $field (@headers) {
				cssPrintCell("head","$field",1);
			}
 			my $add="<a href=\"$scriptname?file=$conf&table=$table&add=true\">Add</a>";
 			if ($ENV{REMOTE_USER} eq "view") {
 				$add="View Only" ;
 			}
 			cssPrintCell("head",$add,1);
 			rowEnd;
		} # if ( not $got_header )		

		if ( 	($name eq "" and $value eq "") 
			or ( lc($name) eq lc($key) ) 
			or ( $value ne "" and $value eq $table_data{$key}{$column}) 
		) {
			rowStart;
		}
		if ( $debug eq "true") {	
			cssPrintCell("view","$key",1);
		}
		for $i (0..$#headers) {
			$field = $headers[$i];
			$table_data{$key}{$field} =~ s/</&lt;/; # replace < for &lt; to display
			$table_data{$key}{$field} =~ s/>/&gt;/;
			if ( $name eq "" and $value eq $table_data{$key}{$column} ) {
				cssPrintCell("view","$table_data{$key}{$field}",1);
			}
			elsif ( $name eq "" and $value eq "" ) {
				cssPrintCell("view","$table_data{$key}{$field}",1);
			}
			elsif ( $name ne "" and lc($name) eq lc($key) ) {
				cssPrintCell("view","$table_data{$key}{$field}",1);
			}
		}
		if ( 	($name eq "" and $value eq "") 
			or (lc($name) eq lc($key)) 
			or ( $value ne "" and $value eq $table_data{$key}{$column}) 
		) {
			my $editdelete="<a href=\"$scriptname?file=$conf&table=$table&row=$key&edit=true\">Edit &nbsp;</a>"
			."<a href=\"$scriptname?file=$conf&table=$table&row=$key&edit=delete\">Delete</a>";

			if ($ENV{REMOTE_USER} eq "view") {
			     $editdelete="View Only" ;
			}
			cssPrintCell("button",$editdelete,1);
			rowEnd;
		}
	}
	tableEnd;
	pageEnd;
}

# AS 14.05.02 Adding Ambrose Li's sort patch
sub alphanumerically {
	#my $a = shift;
	#my $b = shift;
	local($&, $`, $', $1, $2, $3, $4);
	# Sort numbers numerically
	return $a <=> $b if $a !~ /\D/ && $b !~ /\D/;
	# Sort IP addresses numerically within each dotted quad
	if ($a =~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/) {
		my($a1, $a2, $a3, $a4) = ($1, $2, $3, $4);
		if ($b =~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/) {
			my($b1, $b2, $b3, $b4) = ($1, $2, $3, $4);
			return ($a1 <=> $b1) && ($a2 <=> $b2)
			&& ($a3 <=> $b3) && ($a4 <=> $b4);
		}
	}
	# Handle things like Level1, ..., Level10
	if ($a =~ /^(.*\D)(\d+)$/) {
	    my($a1, $a2) = ($1, $2);
	    if ($b =~ /^(.*\D)(\d+)$/) {
			my($b1, $b2) = ($1, $2);
			return $a2 <=> $b2 if $a1 eq $b1;
	    }
	}
	# Default is to sort alphabetically
	return $a cmp $b;
}
