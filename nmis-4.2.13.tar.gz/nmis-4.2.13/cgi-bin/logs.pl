#!/usr/bin/perl
#
# $Id: logs.pl,v 1.12 2006/10/20 14:23:55 decologne Exp $
#
#    logs.pl - NMIS CGI Program - Network Mangement Information System
#    Copyright (C) 2000 Sinclair InterNetworking Services Pty Ltd
#    Keith Sinclair <keith@sinclair.org.au>
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
# 
#    
#
#*****************************************************************************
#
# egreenwood@users.sourceforge.net
#
# updated to provide summaries for cisco.log and event.log - last 48 hrs only, for  a quick status overview
# added DNS lookup for ip address's embedded in log message
# joined syslog records that have been split with ^I - Cisco VPN stuff.
# changed display logic so that lines is actually lines sent to browser, all log is searched
# added logs file logic so that rotated logfile file.log.01 is concatenated to file.log so that we dont lose data over the logrotate
# added display option for unknown logs - pick up debug messages and other miscellaneous stuff
# added fatal log level - same colour as critical
# add 'or' function within search (but dont combine and with or )
# fix up subscript errors on short or zero length files
#
# NMIS colorised eventlevels map as follows to RFC syslog
# 0 fatal 		RFC emergencies 0
# 1 critical	RFC alerts		1
# 2 major		RFC critical	2
# 3 minor		RFC errors		3
# 4 warnings	RFC warnings	4
# 5 error		RFC notifications 5
# 6 normal		RFC informational 6
# 7 unknown		RFC debugging	7
#
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 
use Socket;

$SIG{PIPE} = sub { };  # Supress broken pipe error messages.

# 
#****** Shouldn't be anything else to customise below here *******************

use strict;
use web;
use func;
use csv;
use NMIS qw(loadConfiguration loadNodeDetails %config %nodeTable userMenuDisplay logMessage do_dash_banner do_footer);
use Time::Local;
use Fcntl qw(:DEFAULT :flock);

# Prefer to use CGI for html processing
use CGI qw(:standard);

# declare holder for CGI objects
use vars qw($q);
$q = new CGI; # Processes all parameters passed via GET 

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

my %logList;
my %logSum;

my @table;

my $firstdate;
my $lastdate;
my $title;
my $span = 1;

# This reads in the information sent when the user pressed Submit
my %FORM = getCGIForm($ENV{'QUERY_STRING'});

# Break the queary up for the names
my $logShort = $FORM{log};
my $search = $FORM{search};
my $sort = $FORM{sort};
my $lines = $FORM{lines};
my $legend = $FORM{legend};
my $level = $FORM{level};
my $summary = $FORM{summary};
my $group = $FORM{group};

$level ||= "Normal";
$legend ||= "false";
$sort ||= "Descending";
$lines ||= 250;
$group ||= "NONE";

# Allow program to use other configuration files
my $conf;
if ( $FORM{file} ne "" ) { $conf = $FORM{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

# Before going any further, check to see if we must handle
# an authentication login or logout request
$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#

if ( $auth->Require ) {
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# verify access to this action
	$auth->CheckAccess($user, "logs") or die "Attempted unauthorized access";

	# logout ?
	if ( $q->param('type') eq 'logout' ) {
       	$auth->do_logout;
		exit 0;
	}
	# generate the cookie if $user->user is set
	if ( $user->user ) {
        push @cookies, $auth->generate_cookie($user->user);
        $headeropts{-cookie} = [@cookies];
	}
}


# Find the kernel name
my $kernel;
if (defined $NMIS::config{kernelname} and $NMIS::config{kernelname} ne "") {
	$kernel = $NMIS::config{kernelname};
} elsif ( $^O !~ /linux/i) {
	$kernel = $^O;
} else {
	chomp($kernel = lc `uname -s`);
}

my $nmis_url = "<a href=\"$NMIS::config{nmis}?file=$conf\"><img alt=\"NMIS Dash\" src=\"$NMIS::config{nmis_icon}\" border=\"0\"></a>";
my $back_url = "<a href=\"$ENV{HTTP_REFERER}\"><img alt=\"Back\" src=\"$NMIS::config{back_icon}\" border=\"0\"></a>";
my $logs_url = "<a href=\"$ENV{SCRIPT_NAME}\"><img alt=\"Logs\" src=\"$NMIS::config{logs_icon}?file=$conf\" border=\"0\"></a>";
$logs_url = "" if ( $auth->Require and  not $auth->CheckAccess($user, "logfile","check")) ;
my $summary_url = "<a href=\"$ENV{SCRIPT_NAME}?log=$logShort&summary=summary\"><img alt=\"Summary\" src=\"$NMIS::config{summary_icon}?file=$conf\" border=\"0\"></a>";

my %logList;
my %logSum;

my @table;

my $firstdate;
my $lastdate;
my $title;
my $span = 1;

$search =~ s/ and /\+/gi;				# make sure searches are +, move if necessary
$search =~ s/ /\+/gi;

%logList = loadCSV($NMIS::config{Logs_Table},$NMIS::config{Logs_Key},"\t");

$logShort =~ s/\+/ /gi;
my $logLC = lc($logShort);
my $log = $logList{$logLC}{file};

# Select function to be performed
if ($summary ne "") {
	# verify access to this command/tool bar/button
	#
	if ( $auth->Require and $logShort =~ /cisco_syslog/i ) {
		# CheckAccess will throw up a web page and stop if access is not allowed
		$auth->CheckAccess($user, "syslogsumm") ;
	} elsif ( $auth->Require and $logShort =~ /event_log/i ) {
		# CheckAccess will throw up a web page and stop if access is not allowed
		$auth->CheckAccess($user, "eventsumm") ;
	} else {
		$log = ""; # nothing
	}

	$span = 9;
	$title = "$logShort - Summary - LAST 48 Hrs ONLY";
	pageStartCSS($title,$NMIS::config{styles},"", \%headeropts);
	print Tr(td( &NMIS::do_dash_banner($auth->Require, $user->user) ));
 	&cssTableStart("grey");
	&logMenuSmall;
 	&displayLogSummary($log);
	&tableEnd;
	&pageEnd;
}
elsif ($logShort ne "") {
	# verify access to this command/tool bar/button
        #
    if ( $auth->Require and $logShort =~ /cisco_syslog/i ) {
         # CheckAccess will throw up a web page and stop if access is not allowed
         $auth->CheckAccess($user, "syslog") ;
    } elsif ( $auth->Require and $logShort =~ /event_log/i ) {
          # CheckAccess will throw up a web page and stop if access is not allowed
          $auth->CheckAccess($user, "eventlog") ;
    } elsif ( $auth->Require and $logShort =~ /nmis_log/i ) {
          # CheckAccess will throw up a web page and stop if access is not allowed
          $auth->CheckAccess($user, "nmislog");
	} else {
		$auth->CheckAccess($user, "otherlog") ;
	}

	$span = 2;
	$title = "logs: $logShort - Search \"$search\"";
	pageStartCSS($title,$NMIS::config{styles},"", \%headeropts);
	&loadLogFile($log);
	print Tr(td( &NMIS::do_dash_banner($auth->Require, $user->user) ));
	&cssTableStart("");
	&logMenuSmall;
	if ($legend eq "true" ) { &displayLegend; }
	&displayLogFile;
	&tableEnd;
	&pageEnd;
}
else {
	# verify access to this command/tool bar/button
	#
	if ( $auth->Require ) {
	        # CheckAccess will throw up a web page and stop if access is not allowed
	        $auth->CheckAccess($user, "logfile") or die "Attempted unauthorized access";
	}
	# No options so give 'em a menu of sorts
	$span = 1;
	$title = "Log List";
	$logShort = "Cisco_Syslog";
	pageStartCSS($title,$NMIS::config{styles},"", \%headeropts);
	print Tr(td( &NMIS::do_dash_banner($auth->Require, $user->user) ));
	&cssTableStart("");
	&logMenuSmall;
	if ($legend eq "true" ) { &displayLegend; }
	&headerBar("Log List",1);
	&logMenuLarge;
	&tableEnd;
	&pageEnd;
}

exit(0);

sub logMenuSmall {

	my $time;

	&loadNodeDetails;		# populate nodeTable and groupTable
	
	# filter out groups not in users group access list
	foreach (keys %NMIS::groupTable) {
	        delete $NMIS::groupTable{$_} unless $user->InGroup($_);
	}

	# get the local time 
	$time = &NMIS::get_localtime;

	print <<EOF;
<tr>
<td class="grey" colspan="$span">
<table class="menu1" align="left" >
<tr>
<FORM ACTION="$ENV{SCRIPT_NAME}">
	<td class="grey">$time</td>
	<th class="menugrey">$back_url$nmis_url$logs_url $summary_url</th>
	<th class="menugrey"><INPUT TYPE=submit value="GO"></th>
	<td class="menugrey">
		Log Name 
		<select NAME=log SIZE=1>
EOF
		printf "<option %s value=\"$logList{$_}{log}\">$logList{$_}{log}</option>\n", $_ =~ /^$logShort/i ? "selected " : "" foreach sort keys %logList;
	print <<EOF;
		</select>
	</td>
	<td class="menugrey">Search String 
		<INPUT NAME=search value="$search">
	</td>
	<td class="menugrey">
		Lines 
		<select NAME=lines SIZE=1>
EOF
		printf "<option %s value=\"$_\">$_</option>\n", $_ == $lines ? "selected " : "" foreach qw( 50 100 250 500 1000);
		print <<EOF;
		</select>
	</td>
	<td class="menugrey">
		Level 
		<select NAME=level SIZE=1>
EOF
		printf "<option %s value=\"$_\">$_</option>\n", $_ =~ /^$level/i ? "selected " : "" foreach qw( Normal Error Warning Minor Major Critical Fatal Unknown);
		print <<EOF;
		</select>
	</td>
	<td class="menugrey">
		Sorting 
		<select NAME=sort SIZE=1>
EOF
		printf "<option %s value=\"$_\">$_</option>\n", $_ =~ /^$sort/i ? "selected " : "" foreach qw( Descending Ascending);
		print <<EOF;
		</select>
	</td>
	<td class="menugrey">
		Group
		<select NAME=group SIZE=1>
EOF
		printf "<option %s value=\"$_\">$_</option>\n", $_ =~ /^$group/i ? "selected " : "" foreach ( "NONE", sort keys %NMIS::groupTable);
		print <<EOF;
		</select>
	</td>
</form> 
</tr>
</table>
</td>
</tr>

EOF
}

sub logMenuLarge {
	my $logName;
	my @filestat;
	my $date;
	my $options = "&sort=descending&lines=250&level=normal";

	print "<td class=\"white\">\n";
	print "<table class=\"white\">\n";
	print "<tr><th class=\"grey\">Description</th><th class=\"grey\">File</th><th class=\"grey\">Size</th><th class=\"grey\">Date</th></tr>\n";
        foreach $logName (sort ( keys (%logList) ) )  {
        	if ( $logList{$logName}{file} ne "" ) {
	        	@filestat = stat $logList{$logName}{file};
	        	$date = func::returnDateStamp(@filestat[9]);
	      		print <<EO_HTML;
			<tr>
			<td><a href="$ENV{SCRIPT_NAME}?file=$conf&log=$logList{$logName}{log}$options">$logList{$logName}{log}</a></td>
			<td>$logList{$logName}{file}</td>
			<td align="right">$filestat[7] bytes</td>
			<td>$date</td>
			</TR>
EO_HTML
		}
        }
	print "</td>\n</table>\n";
}

sub headerBar {
  	my $string = shift;
  	my $colspan = shift;

	if ( $colspan eq "" ) { $colspan = "COLSPAN=1"; }
	else { $colspan = "COLSPAN=$colspan"; }

	print "<tr>\n";
	print "<td class=\"grey\" $colspan>$string</td>\n";
	print "</tr>\n";
}

# note - this will slurp todays file and yesterdays !
sub loadLogFile {
	my $file = shift;
	my $boolean;
	my $dosearch;
	my $search1;
	my $search2;
	my $search3;
	my $search4;
	my $search5;
	my @tmpsearch;
	my $index;
	my @newline;
	my @line;
	my $switch;

 	# Open the table and and store in array
	$index=0;

	if ( $search eq "" ) { 
		$dosearch = "false"; 
		$boolean = "false";
	}
	elsif ( $search =~ /\+/ ) {
		$boolean = "true";
		$switch = "and";
		($search1,$search2,$search3,$search4,$search5) = split(/\+/,$search);
	}
	elsif ( $search =~ /\|/ ) {
		$boolean = "true";
		$switch = "or";
		($search1,$search2,$search3,$search4,$search5) = split(/\|/,$search);
	}

	#print "DEBUG: logShort=$logShort log=$log search=$search boolean=$boolean search1=$search1 search2=$search2 search3=$search3\n";

	# tac the last and the last rotated log file to make sure we always have a full logfile to scan
	# if no search or summary, only get the number of line asked for

	if ( -f "$file.01" and $^O !=~ /win32/i ) {
			$file = "$file $file.01";
	}
	elsif ( -f "$file.1" and $^O !=~ /win32/i ) {
			$file = "$file $file.1";
	}
	my $tac = "tac";
	if ($kernel =~ /freebsd|tru64|solaris/i) { $tac = "tail -r"; }
	# use tac to read file in reverse
	open (DATA, "$tac $file |") or warn returnTime." logs.pl, Cannot open $file. $!\n";

	# find the line with the entry in and store in the array
	while (<DATA>) {
		chomp;
		$_ =~ s/  / /g;
		
		if ( $boolean eq "true" && $switch eq "and" ) {
			if ( 	$_ =~ /$search1/i and 
				$_ =~ /$search2/i and 
				$_ =~ /$search3/i and 
				$_ =~ /$search4/i and 
				$_ =~ /$search5/i 
			) {
				$table[$index] = $_;
				++$index;
				last if $index >= $lines;		# as we are reading in reverse ( newest line first) can stop after #lines matched.
			}
		}
		if ( $boolean eq "true" && $switch eq "or" ) {
			if ( 	$_ =~ /$search1/i or 
				$_ =~ /$search2/i or 
				$_ =~ /$search3/i or 
				$_ =~ /$search4/i or 
				$_ =~ /$search5/i 
			) {
				$table[$index] = $_;
				++$index;
				last if $index >= $lines;
			}
		}
		elsif ( $dosearch eq "false" ) {
			$table[$index] = $_;
			++$index;
			last if $index >= $lines;					# only get the # lines we want .
		}
		elsif ( $_ =~ /$search/i ) {
			$table[$index] = $_;
			++$index;
			last if $index >= $lines;
		}
	}
	close(DATA);
}

sub displayLogFile {

	my $stop;
	my $numlines;
	my $index;

	my $linelink50;
	my $linelink100;
	my $linelink250;
	my $linelink500;
	my $linelink1000;
	my $levellinkFatal;
	my $levellinkCritical;
	my $levellinkMajor;
	my $levellinkMinor;
	my $levellinkWarning;
	my $levellinkError;
	my $levellinkNormal;
	my $levellinkUnknown;
	my $fatal = NMIS::eventColor("fatal");	
	my $critical = NMIS::eventColor("critical");
	my $major = NMIS::eventColor("major");
	my $minor = NMIS::eventColor("minor");
	my $warning = NMIS::eventColor("warning");
	my $error = NMIS::eventColor("error");
	my $normal = NMIS::eventColor("normal");
	my $unknown = NMIS::eventColor("unknown");

	$linelink50 = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\">50</a>";
	$linelink50 =~ s/lines=$lines/lines=50/g ;
	$linelink100 = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\">100</a>";
	$linelink100 =~ s/lines=$lines/lines=100/g ;
	$linelink250 = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\">250</a>";
	$linelink250 =~ s/lines=$lines/lines=250/g ;
	$linelink500 = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\">500</a>";
	$linelink500 =~ s/lines=$lines/lines=500/g ;
	$linelink1000 = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\">1000</a>";
	$linelink1000 =~ s/lines=$lines/lines=1000/g ;
	$levellinkFatal = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\"><FONT COLOR=$fatal>Fatal</FONT></a>";
	$levellinkFatal =~ s/level=$level/level=fatal/g ;
	$levellinkCritical = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\"><FONT COLOR=$critical>Critical</FONT></a>";
	$levellinkCritical =~ s/level=$level/level=critical/g ;
	$levellinkMajor = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\"><FONT COLOR=$major>Major</FONT></a>";
	$levellinkMajor =~ s/level=$level/level=major/g ;
	$levellinkMinor = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\"><FONT COLOR=$minor>Minor</FONT></a>";
	$levellinkMinor =~ s/level=$level/level=minor/g ;
	$levellinkWarning = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\"><FONT COLOR=$warning>Warning</FONT></a>";
	$levellinkWarning =~ s/level=$level/level=warning/g ;
	$levellinkError = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\"><FONT COLOR=$error>Error</FONT></a>";
	$levellinkError =~ s/level=$level/level=error/g ;
	$levellinkNormal = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\"><FONT COLOR=$normal>Normal</FONT></a>";
	$levellinkNormal =~ s/level=$level/level=normal/g ;
	$levellinkUnknown = "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&$ENV{'QUERY_STRING'}\"><FONT COLOR=$unknown>Unknown</FONT></a>";
	$levellinkUnknown =~ s/level=$level/level=unknown/g ;



	&headerBar("$title - Lines \n$linelink50 \n$linelink100 \n$linelink250 \n$linelink500 \n$linelink1000 \n$levellinkNormal \n$levellinkError \n$levellinkWarning \n$levellinkMinor \n$levellinkMajor \n$levellinkCritical \n$levellinkFatal \n$levellinkUnknown",$span);

	return if $#table < 0;				# handle the zero length file

	$numlines = $lines;				# save the number of lines we are supposed to print
	if ( $sort =~ /Ascending/i) {
		$index = $#table + 1;			# start at the last row ( +1 as we pre-decrement)
		while ( $numlines > 0 ) {
			$index--;			# pre-decrement and get the row
			if (&outputLine($table[$index]) eq "true" ) {	# only count printed lines.
				--$numlines;
			}
                last if $index == 0;			# exit if we have parsed the zero'th row
		}
	}
	# Must be descending or default
	else {
		$index = -1;			# start at the first row (-1 as we pre-increment)
		while ( $numlines > 0 ) {
			$index++;		# pre-increment and get the row
			if (&outputLine($table[$index]) eq "true" ) {	# only count printed lines.
				--$numlines;
			}
		last if $index == $#table;		# exit if we have parsed the last row
		}
	}
}

sub outputLine
{
  	my $line = shift;

	my @logline;
	my $colspan;
	my $eventlink;
	my $nodelink;
	my $buttons;
	my $llasttime;
	my $lstarttime;
	my $ldetails;
	my $levent_level;
	my $eventClass;
	my $eventlevellink;
	my $levent;
	my $lnode;
	my $lsub;
	my $shortnode;
	my $ltime;
	my $sizetag;
	my $eventColor;
	my $datestamp;
	my $datestamp_current;
	my $datestamp_start;
	my $outage;
	my $tics;
	my @x;
	my $event;
	my $desc;
	my $i;
###	my @eventlist;
	my @otherline;
	my $count_space;
	my $count_colon;
	my $claimed_hostname;
	my $ipaddr;
	my $pos;
	my $print = "false";


	# If its the event log and there are comma's insert a link to the node and customer specific alerts.
	# evaluate each line to determine what it is, ie cisco syslog, or something else.

	# it is a syslog of some description.
	### cisco log
	if ( $line =~ /%/ and $line =~ /:/ ) {
		$line =~ s/  / /g;	
		@otherline = split("%",$line);
		$event = "%".$otherline[1];
		@otherline = split(":",$event);
		$event = $otherline[0];
		shift @otherline;
		$desc = join(":", @otherline);
		# now we have the event and the description.
		#print STDERR "event=$event desc=$desc\n";
		
		@logline = split(" ",$line);

		# Get the shortnode name out.
		$shortnode = $logline[3];
		#Dispose of the domainname!
		if ( $shortnode !~ /^\[/ ) {
			@x = split(/\./,$logline[3]);
			#Check if it is an IP address or not.
			if ( $x[0] !~ /\d+/ ) {	$shortnode = $x[0]; }
			$lnode = $logline[3];
			#if ( $lnode eq $shortnode ) { # must be a log with no fqdn, in our local mgmt domain
			#	$lnode .= "." . $NMIS::config{domain_name}	# add back the fqdn - but what if nodes.csv does not use the fqdn ??
			#}
		}
		else {
			# Could do DNS reverse lookup to resolve to name! 
			# Probably better not to, slower if no entries exist.
			$logline[3] =~ s/\[|\]//g;
			@x = split(/\./,$logline[3]);
			$shortnode = "$x[0].$x[1].$x[2].$x[3]";
			$lnode = $shortnode;
		}
		@x = split("--",$shortnode);
		$shortnode = $x[0];
		
		if ( $event =~ /^%/ ) {
			if ( $firstdate eq "" ) { $firstdate = "$logline[0] $logline[1] $logline[2]"; }
			else { $lastdate = "$logline[0] $logline[1] $logline[2]"; }
###			@eventlist = split("-",$event);
			$levent_level = $1 # set the levels to match the device levels
				if $event =~ /-(\d+)-/;
###			$levent_level = $eventlist[1];			# set the levels to match the device levels.
		}
	
		if ( $event ne "" and $lnode ne "" ) {
			# Do some quick stats
		
			# drop the % char from event as it breaks the search
			substr($event, 0, 1, '');  # replace the first character with nothing
			$eventlink="<a href=\"$ENV{SCRIPT_NAME}?file=$conf&log=$logShort&sort=descending&search=$event&lines=$lines&level=$level&group=$group\">$event</a>";
	
			$buttons=
				"<a href=\"$NMIS::config{admin}?tool=ping&node=$lnode\"><img alt=\"ping $lnode\" src=\"$NMIS::config{ping_icon}\" border=\"0\"></a>".
				"<a href=\"$NMIS::config{admin}?tool=trace&node=$lnode\"><img alt=\"traceroute $lnode\" src=\"$NMIS::config{trace_icon}\" border=\"0\"></a>".
				"<a href=\"telnet://$lnode\"><img alt=\"telnet to $lnode\" src=\"$NMIS::config{telnet_icon}\" border=0 align=top></a>".
				"<a href=\"$NMIS::config{nmis}?node=$lnode\"><img alt=\"NMIS\" src=\"$NMIS::config{nmis_icon}\" border=\"0\"></a>".
			"";
			if ( $lnode !~ /\[(.*)\]/ ) {
				$nodelink="<a href=\"$ENV{SCRIPT_NAME}?file=$conf&log=$logShort&sort=descending&search=$shortnode&lines=$lines&level=$level&group=$group\">$shortnode</a>";
				$line =~ s/$logline[3]/$nodelink/g;
			}
			$line = "$line";
			$line =~ s/$event/$eventlink/g;
		}

		$colspan = 1;
		$eventColor = eventColor($levent_level);
	} # elsif cisco.log

	## event log
	elsif ( ( $log =~ /event(.*)log/ ) and ( $line =~ /,/ ) ) {
		$line =~ s/, /,/g;
		($ltime,$lnode,$levent,$levent_level,$ldetails) = split(/,/,$line);
		#Check the date format and if it doesn't have a - then it is UNIX format
		if ( $ltime !~ /-/ ) { 
			$ltime = NMIS::returnDateStamp("$ltime");
		}

		$buttons=
			"<a href=\"$NMIS::config{admin}?tool=ping&node=$lnode\"><img alt=\"ping\" src=\"$NMIS::config{ping_icon}\" border=\"0\"></a>".
			"<a href=\"$NMIS::config{admin}?tool=trace&node=$lnode\"><img alt=\"traceroute\" src=\"$NMIS::config{trace_icon}\" border=\"0\"></a>".
			"<a href=\"telnet://$lnode\"><img alt=\"telnet\" src=\"$NMIS::config{telnet_icon}\" border=\"0\"></a>".
			"<a href=\"$NMIS::config{nmis}?node=$lnode\"><img alt=\"NMIS\" src=\"$NMIS::config{nmis_icon}\" border=\"0\"></a>"
		;
		$nodelink="<a href=\"$ENV{SCRIPT_NAME}?file=$conf&log=$logShort&sort=descending&search=$lnode&level=$level&group=$group\">$lnode</a>";
		$eventlink="<a href=\"$ENV{SCRIPT_NAME}?file=$conf&log=$logShort&sort=descending&search=$levent&level=$level&group=$group\">$levent</a>";
		$eventlevellink="<a href=\"$ENV{SCRIPT_NAME}?file=$conf&log=$logShort&sort=descending&search=$search&level=$levent_level&group=$group\">$levent_level</a>";

		# If the variable has Time= in it process away
		if ( $ldetails =~ /Time=/ ) {
			# Get the details in a munging variable
			$outage = $ldetails;
			
			# Get rid of the "Time=" bit
			$ldetails =~ s/Time=.*secs//g;

			# extract the time in seconds from the line.
			$outage =~ s/.*Time=(.*) secs/$1/;
			$outage = "Event Time=$outage";
		}
		else {
		 	$outage = "";
		}
		# If the variable has Time= in it process away

		if ( $ldetails =~ /tics=/ ) {
			# Get the details in a munging variable
			$tics = $ldetails;
			
			# Get rid of the "Time=" bit
			$ldetails =~ s/tics=.*$//g;

			# extract the time in seconds from the line.
			$tics =~ s/.*tics=(.*)/$1/;
			$tics = "Planned Outage TICS=$tics";
		}
		else {
		 	$tics = "";
		}

		$colspan = 1;
		$eventColor= eventColor("$levent_level");
		$line="$ltime $nodelink $eventlink $eventlevellink $ldetails $tics $outage";
	} # if event.log

	## nmis log
	elsif ( (  $log =~ /nmis(.*)log/ ) and ( $line =~ / / ) ) {
		#$line =~ s/  / /g;
		$line =~ s/, /,/g;	
		@logline = split(",",$line);
		$datestamp = $logline[0];
		$lsub = $logline[1];
		$lnode = $logline[2];
		if ( $#logline > 2 ) {
			my @x;
			for $i (3..$#logline) { push(@x,$logline[$i]); }
			$levent = join(",",@x);
		}
		else {
			$levent = $logline[3];
    
		}
		$buttons=
			"<a href=\"$NMIS::config{admin}?tool=ping&node=$lnode\"><img alt=\"ping $lnode\" src=\"$NMIS::config{ping_icon}\" border=\"0\" align=\"top\"></a>".
			"<a href=\"$NMIS::config{admin}?tool=trace&node=$lnode\"><img alt=\"traceroute $lnode\" src=\"$NMIS::config{trace_icon}\" border=\"0\" align=\"top\"></a>".
			"<a href=\"telnet://$lnode\"><img alt=\"telnet to $lnode\" src=\"$NMIS::config{telnet_icon}\" border=\"0\" align=\"top\"></a>".
			"<a href=\"$NMIS::config{nmis}?node=$lnode\"><img alt=\"NMIS Dash\" src=\"$NMIS::config{nmis_icon}\" border=\"0\"></a> "
		;
		if ( $lnode !~ /\[(.*)\]/ ) {
			$nodelink="<a href=\"$ENV{SCRIPT_NAME}?file=$conf&log=$logShort&sort=descending&search=$lnode&lines=$lines\">$lnode</a>";
			$line =~ s/$lnode/$nodelink/g;
		}
		$line = "$datestamp $lsub $nodelink $levent";
		$colspan = 1;
		$eventColor = "#00FF00";
	} # elsif nmis.log 
	else {
		$eventColor = "#00FF00";
		$colspan = 1;
	}

	# Remove the comma's from the line
	$line =~ s/,/ /g;	

	$level ||= "normal";
	$levent_level ||= 7;

	$eventClass = eventLevelSet($levent_level);

	# define which events should be displayed.
	if ( ( $level =~ /fatal/i ) and ( $eventClass =~ /fatal/i ) ) {
		$print = "true";
	}
	elsif ( ( $level =~ /critical/i ) and ( $eventClass =~ /critical|fatal/i ) ) {
		$print = "true";
	}
	elsif ( $level =~ /major/i and ( $eventClass =~ /major|critical|fatal/i ) ) {
		$print = "true";
	}
	elsif ( $level =~ /minor/i and ( $eventClass =~ /minor|major|critical|fatal/i ) ) {
		$print = "true";
	}
	elsif ( $level =~ /warning/i and ( $eventClass =~ /warning|minor|major|critical|fatal/i ) ) {
		$print = "true";
	}
	elsif ( $level =~ /error/i and ( $eventClass =~ /error|warning|minor|major|critical|fatal/i ) ) {
		$print = "true";
	}
	elsif ( $level =~ /normal/i and ( $eventClass =~ /normal|error|warning|minor|major|critical|fatal/i ) ) {
		$print = "true";
	}

	# intersect with the group
	if ( $print eq "true" 
		and ( $group eq "NONE" or $NMIS::nodeTable{$lnode}{group} eq $group )
		and $user->InGroup($NMIS::nodeTable{$lnode}{group}) 
		) {
		if ( $NMIS::config{syslogDNSptr} eq "true" and $logShort eq "Cisco_Syslog" ) {
			# have a go at finding out the hostname for any ip address that may have been referenced in the log.
			# assumes we have populated our DNS with lots of PTR records !
			$i = 3;				# put a failsafe loop counter in here !
			while ( $line =~ /(\d+\.\d+\.\d+\.\d+)/g && $i-- != 0 ) {
				$pos = pos($line);				# need to save where we are, so we start the next match from here.
				$ipaddr = inet_aton($1);			# matched string of x.x.x.x
				if ($claimed_hostname = gethostbyaddr($ipaddr, AF_INET)) {
					($claimed_hostname) = split /\./ , $claimed_hostname;	# get the hostname portion
					substr( $line, $pos, 0 ) = " [".$claimed_hostname."] ";	# this will mess the /g match position
					pos($line)=$pos;				# so reset it to make sure we move to the next match
				}
			}
		} # end of name lookup

		# now print it
		print "<tr><td class=\"none\" width=\"156\">$buttons</td><td class=\"$eventClass\">$line</td></tr>\n";

	}
	return $print;				# return print status so we can count the actual printed lines
} # end outputLine

sub displayLegend {
  		print<<EOF;
<tr>
 <td class="grey">
  <table class="grey">
   <tr>
    <td class="critical">Critical</td>
    <td class="major">Major</td>
    <td class="minor">Minor</td>
    <td class="warning">Warning</td>
    <td class="error">Error</td>
    <td class="normal">Normal</td>
   </tr>
  </table>
 </td>
</tr>
EOF
}


## Eric Greenwood and Daniel Parsons June 2002: Added Log summary
sub displayLogSummary {
	my $file = shift;
	my $numlines;
	my $index = 0;
	my $time;
	my $event;

	&headerBar("$title",20);
	&logSummary($file);	# read file
	
	#print what we got - header table first
        print "<tr>\n";
        print "<td  class=\"white\" align=\"center\">\n";
        print "<table class=\"white\">\n";
        print "<tr>\n";
        print "<td class=\"menubar\" width=\"300\">Nodename</td>\n";

        for $event ( sort keys %{ $logSum{"Header"} } ) {
		$event =~ s/_/-/g;			# subst all underscrore for hyphen, so browser will wrap text in header columns
                print "<td class=\"menubar\" width=\"60\">$event</td>\n";
                }
        print "</tr>\n";


	for $index ( sort keys %logSum ) { 
		next if $index eq "Header"; # kill the header
		next unless $user->InGroup($NMIS::nodeTable{$index}{group});
		print "<tr>\n";
    	print "<td width=\"300\"><a href=\"$ENV{SCRIPT_NAME}?file=$conf&log=$logShort&sort=descending&search=$index&lines=$lines\">$index</a></td>\n";
    	for $event ( sort keys %{ $logSum{"Header"} } ) {
			if ( $logSum{$index}{$event} ) { print "<td width=\"60\"><a href=\"$ENV{SCRIPT_NAME}?file=$conf&log=$logShort&sort=descending&search=$index+$event&lines=$lines\">$logSum{$index}{$event}</a></td>\n";}
			else { print "<td width=\"60\">&nbsp;</td>\n";} 
		}
		print "</tr>\n";
	}
	print "</tr>\n";
	print "</table>\n";
	print "</td>\n";
	print "</tr>\n";
}

sub logSummary {
	my $file = shift;
   	my @otherline;
 	my @event;
 	my $desc;
 	my $shortnode;
  	my $lnode;
###	my @eventlist;
	my @logline;
	my $index;
	my $ltime;
	my $event;
	my $eventClass;
	my $levent;
	my $levent_level;
	my $ldetails;
	my $timelog;
	my $sec;
    my $min;
    my $hour;
    my $mday;
    my $mon;
    my $year;
    my $wday;
    my $yday;
    my $isdst;
	my $i;

	# load the node table for group filtering
	&loadNodeDetails;

	# only get 48 hrs worth of logs summary
	# init the variable
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime;
	$timelog = time() - (48*60*60);            # get the epoch time for 48hrs ago

	# tac the last and the last rotated log file to make sure we always have a full logfile to scan
	if ( -f "$file.01" and $^O !=~ /win32/i ) {
		$file = "$file $file.01";
	}
	elsif ( -f "$file.1" and $^O !=~ /win32/i ) {
		$file = "$file $file.1";
	}
	open (DATA, "tac $file |") or warn returnTime." logs.pl, Cannot open $file. $!\n";

	while (<DATA>) {
		chomp;
		if ( $_ =~ /%/ and $_ =~ /:/ ) {		# cisco logline
			$_ =~ s/  / /g;	
			@logline = split / / ,$_;

			# log time format is May 26 06:00:06
			$mon = $logline[0];
			$mday = $logline[1];
			# have to convert month to number
			SWITCH: {
				if ($mon =~ /Jan/) { $mon = 0; last SWITCH; }
				if ($mon =~ /Feb/) { $mon = 1; last SWITCH; }
				if ($mon =~ /Mar/) { $mon = 2; last SWITCH; }
				if ($mon =~ /Apr/) { $mon = 3; last SWITCH; }
				if ($mon =~ /May/) { $mon = 4; last SWITCH; }
				if ($mon =~ /Jun/) { $mon = 5; last SWITCH; }
				if ($mon =~ /Jul/) { $mon = 6; last SWITCH; }
				if ($mon =~ /Aug/) { $mon = 7; last SWITCH; }
				if ($mon =~ /Sep/) { $mon = 8; last SWITCH; }
				if ($mon =~ /Oct/) { $mon = 9; last SWITCH; }
				if ($mon =~ /Nov/) { $mon = 10; last SWITCH; }
				if ($mon =~ /Dec/) { $mon = 11; last SWITCH; }
				$sec = 0;		#do_nothing line
			}
		
			($hour, $min, $sec) = split /:/ ,$logline[2];
			$ltime = timelocal($sec,$min,$hour,$mday,$mon,$year,,,$isdst); # get the epoch time for this log message
	 		if ($ltime < $timelog) {last;}		# exit unless logtime is less than 48 hrs ago.

			# Get the shortnode name out.
			$shortnode = $logline[3];
			($shortnode) = split /--/ ,$shortnode;	# first split is the one we want
#				next unless $user->InGroup($NMIS::nodeTable{$shortnode}{group});	
			@event = split /%/ ,$_;				# we want to the right of the %
			$event = "%".$event[1];					# add back the %
			($event) = split /:/ ,$event;			# only need the first list element to the left of the ":"

			# to square off the hash, capture all possible events
			$logSum{"Header"}{$event} = 1;
			$logSum{$shortnode}{$event} += 1;
		}
		# event log summary
		elsif ( ( $file =~ /event(.*)log/ ) and ( $_ =~ /,/ ) ) {
			$_ =~ s/, /,/g;
			($ltime, $lnode, $levent, $levent_level, $ldetails) = split /,/, $_;
			# event log time is already in epoch time
	        # only get 48 hrs worth of logs summary
	        if ($ltime < $timelog ) {last;}           # nothing to do unless logtime is less than 48 hrs ago.

			# trim the event down to the first 4 keywords or less.
			# only join if we got the split, so the subsequent search link works
			$event = "";
			$i =0;
			foreach $index ( split /( )/ , $levent ) {		# the () will pull the spaces as well into the list, handy !
				$event .= $index;
				last if $i++ == 6;				# up to 4 splits only please, with no trailing space.
			}
				# to square off the hash, capture all possible events
			$logSum{"Header"}{$event} = 1;
			$logSum{$lnode}{$event} += 1;
		} # end eventlogsummary
	} # end while
	close(DATA);

}
