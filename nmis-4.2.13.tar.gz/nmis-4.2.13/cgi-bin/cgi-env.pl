#!/usr/bin/perl
#
#    cgi-env.pl - CGI Environment Program 
#    Copyright (C) 2000,2001 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************



&pageStart;
&printCGIENV;
&pageEnd;


sub printCGIENV {
	my $name;
	&tableStart("white");

	&rowStart;
	print "<TH>CGI Parameter</TH><TH>ENV Value</TH>";
	&rowEnd;

	foreach $name (sort ( keys (%ENV) ) )  {
		&rowStart;
		print "<TD>$name</TD><TD>$ENV{$name}</TD>";
		&rowEnd;
	}
	&tableEnd;
}

sub tableStart {
  	my $string = shift;

	if ($string eq "white") {
	  	print "<TABLE WIDTH=100% BORDER=1 BGCOLOR=#FFFFFF BORDERCOLOR=#000000 BORDERCOLORLIGHT=#000000 BORDERCOLORDARK=#AAAAAA>\n";
	}
	elsif ($string ne "" ) {
	  	print "<TABLE BORDER=0 BGCOLOR=\"$string\" BORDERCOLOR=#000000 BORDERCOLORLIGHT=#000000 BORDERCOLORDARK=#AAAAAA>\n";
	}
	else {
	  	print "<TABLE BORDER=0 cellpadding=5 cellspacing=5 bgcolor=#190032 bordercolor=#190032 bordercolorlight=#190032 bordercolordark=#190032>\n";
	}
}

sub printRow {
  	my $string = shift;
 	my $color = shift;
 	my $span = shift;
	my $spanString = "";
	if ( $color eq "" ) { $color="#FFFFFF"; }
	if ( $span ne "" ) { $spanString="COLSPAN=$span "; }
	$string =~ s/\n|\t//g ;
	$string =~ s/,/<\/TD><TD BGCOLOR=$color>/g ;
	print "<TR><TD BGCOLOR=$color $spanString>$string</TD></TR>\n";
}

sub pageStart {
  	my $string = shift;
  	my $refresh = shift;
	my $refreshstring;
	my $dateStamp = STATS::returnDateStamp;
	my @dateTime = split " ", $dateStamp;
	$dateTime[0] =~ s/-/ /g;
	if ( $refresh eq "" or $refresh eq "true" ) { $refreshstring = "<META HTTP-EQUIV=Refresh CONTENT=300>"; }
	else { $refreshstring = ""; }
	print <<ENDHTML;
Content-type: text/html\n
<HTML>
<HEAD>
<link href="/styles.css" rel="stylesheet" type="text/css">
<TITLE>$string</TITLE>
$refreshstring
<META HTTP-EQUIV=expires CONTENT="$dateTime[0]">
</HEAD>
<BODY>

ENDHTML
}

sub pageEnd { print "</BODY>\n</HTML>"; }

sub tableEnd {
  print "</TABLE>\n";
}


sub rowStart {
  print "<TR>\n";
}

sub rowEnd {
  print "</TR>\n";
}
