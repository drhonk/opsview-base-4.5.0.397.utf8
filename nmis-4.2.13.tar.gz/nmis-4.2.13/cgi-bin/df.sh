#!/bin/ksh
#    A simple NMIS Plugin by Sinclair InterNetworking Services (c) 2002
#    Release free under the GPL as part of NMIS
#    Copyright (C) 2002 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis

PATH=$PATH:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin

DF=`df -k`
DATE=`date`

echo "Content-type: text/html"
echo
echo
echo "<html><head><title>Disk Usage</title></head><body><center><h2>Disk Usage at $DATE</h2></center><pre>$DF</pre></body></html>"
exit
