#!/usr/bin/perl
#
# $Id: ip.pl,v 1.4 2006/10/02 18:22:49 decologne Exp $
#
#
#    ip.pl - NMIS IP Subnetting Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
# 
#****** Shouldn't be anything else to customise below here *******************

use strict;
use NMIS;
use func;
use web;
use ip;


# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;
 
# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

# Now Config is loaded set some standard parameters
my %FORM = getCGIForm($ENV{'QUERY_STRING'});

# Break the queary up for the names
my $tool = $FORM{tool};
my $ip = $FORM{ip};
my $mask1 = $FORM{mask1};
my $mask2 = $FORM{mask2};

# Before going any further, check to see if we must handle
# an authentication login or logout request
$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
      # check for username from other sources
      # either set by the web server or via a set cookie
      $user->SetUser( $auth->verify_id );

      # $user should be set at this point, if not then redirect
      unless ( $user->user ) {
              $auth->do_force_login("Authentication is required. Please login.");
              exit 0;
      }
	# verify access to this command/tool bar/button
	#
      # CheckAccess will throw up a web page and stop if access is not allowed
      $auth->CheckAccess($user, "ip") or die "Attempted unauthorized access";

	# generate the cookie if $auth->user is set
	#
	push @cookies, $auth->generate_cookie($user->user);
	$headeropts{-cookie} = [@cookies];
}

my $input = "$ip $mask1 $mask2";

my $i;
my $c;

my $tooloutput;
my @hostlookup;
my $packed_ip;
my $address;
my @addresslist;
my $claimed_host;
my $output;
my ($name, $aliases, $addrtype, $length, @addrs);
my $rootdir;

my $colspan = 1;

# Select function to be performed
if ($ip eq "") {
        pageStartCSS("IP Subnetting Tool","/nmis/nmis.css","", \%headeropts);
        cssTableStart("");
    	cssHeaderBar("IP Subnetting Tool","header");
	&ipMenu; 
	&ipDesc; 
	tableEnd;
	pageEnd;
}
else { 
        pageStartCSS("IP Subnetting Tool - $tool","/nmis/nmis.css","", \%headeropts);
        cssTableStart("");
    	cssHeaderBar("IP Subnetting Tool","grey");
	&ipMenu; 
    	
	if ($mask2 eq "") { &ipMask; }
	else { 
		&ipMask; 
		&ipSubnets; 
	}
	
	tableEnd;
	pageEnd;
}

exit(0);


sub ipMenu {
	if ( $tool eq "" ) { $tool = "ip"; }
	print<<EOHTML;
<FORM ACTION="$ENV{SCRIPT_NAME}">
<tr bgcolor="#FFFFFF">
	<TD COLSPAN="$colspan">
	<TABLE class="white">
	<tr class="grey"><TD>IP Address</td><td><INPUT NAME=ip SIZE=20 VALUE="$ip"></TD><TD>IP address to base scheme on</td></tr>
	<tr class="grey"><TD>Mask</td><td><INPUT NAME=mask1 SIZE=20 VALUE="$mask1"></td><TD>Basic IP Subnet Mask for scheme</td></tr>
	<tr class="grey"><TD>Mask2</td><td><INPUT NAME=mask2 SIZE=20 VALUE="$mask2"></td><TD>Extended subnet mask for full network</td></tr>
	<tr class="grey"><TD colspan="3"><center><INPUT TYPE=submit VALUE="GO"></center></TD></tr>
</FORM> 
</TABLE>
</TD>
</tr>
EOHTML
}

sub ipDesc {
	
	print<<EOHTML;
<tr bgcolor="#FFFFFF">
<TD class="line">
This is the IP Tool, you enter an IP address and a subnet mask and wallah you will be<br>
provided with the IP Subnet Information like IP Subnet Address, Broadcast Address, <br>
Mask Bits for classless routing, Wildcard mask for access lists and OSPF routing <br>
configuration.
<p>
If you want to bigger subnet masking you can put a second mask in which will then<br>
produce a second table and a list of the subnets from the first mask which fit into<br>
the second mask.  This is handy when you are doing VLSM work, and handy for subnet<br>
breakpoints.
</TD>
</tr>
EOHTML
}

sub ipMask {
	my $address;
	my $mask;
	my $subnet;
	my $bits;
	my $assume;
	my $broadcast;
	my $wildcard;
	my $hosts;

	($address,$mask) = split(/\/| /,$input);
	if ( $mask eq "" ) { 
		$mask = "255.255.255.0"; 
		$assume = "true";
	}
	elsif ( $mask !~ /\d+\.\d+\.\d+\.\d+/ ) { 
		# Its a number bits mask
		$mask = ipBitsToMask(bits => $mask);
	}
	
	($subnet,$bits) = ipSubnet(address => $address, mask => $mask);
	$broadcast = ipBroadcast(subnet => $subnet, mask => $mask);
	$wildcard = ipWildcard(mask => $mask);
	$hosts = ipHosts(mask => $mask);
	if ( $assume eq "true" ) {
		$mask = "No mask assuming 255.255.255.0"; 
	} 
	
    	cssHeaderBar("IP Subnet for IP address $address $mask","header");
	print<<EOHTML;
<tr>
<TD class="white">
	<TABLE class="white">
EOHTML
	if ( $mask2 ne "s" ) {
		print "<tr><TD class=\"grey\" COLSPAN=\"2\">First Subnet Mask</TD></TR>";
	}

	print<<EOHTML;
	<tr><TD class="line">IP Address</TD><TD class="line">$address</TD></TR>
	<tr><TD class="line">IP Subnet Mask</TD><TD class="line">$mask</TD></TR>
	<tr><TD class="line">Subnet Address</TD><TD class="line">$subnet</TD></TR>
	<tr><TD class="line">Broadcast Address</TD><TD class="line">$broadcast</TD></TR>
	<tr><TD class="line">Mask Bits</TD><TD class="line">$bits</TD></TR>
	<tr><TD class="line">Wildcard Mask</TD><TD class="line">$wildcard</TD></TR>
	<tr><TD class="line">Number Hosts</TD><TD class="line">$hosts</TD></TR>
	</TABLE>
	</TD>
	</tr>
EOHTML

}

sub ipSubnets {
	my $address;
	my $mask;
	my $submask;

	my $numsmallsubnets;
	my $numbigsubnets;
	my $bits;
	my $wildcard;
	my $broadcast;
	my $hosts;
	
	my $subsubnet;
	my $subbits;
	my $subbroadcast;
	my $subwildcard;
	my $subhosts;
	my $numsubnets;

	my $i;

	($address, $mask, $submask) = split(/\/| /,$input);

	#($subnet,$bits) = ipSubnet(address => $address, mask => $mask);
	#$broadcast = ipBroadcast(subnet => $subnet, mask => $mask);
	$wildcard = ipWildcard(mask => $mask);
	$numsmallsubnets = ipNumSubnets(wildcard => $wildcard);

	# get the mask for the second subnet mask!
	($subsubnet,$subbits) = ipSubnet(address => $address, mask => $submask);
	$subbroadcast = ipBroadcast(subnet => $subsubnet, mask => $submask);
	$subwildcard = ipWildcard(mask => $submask);
	$subhosts = ipHosts(mask => $submask);
	$hosts = ipHosts(mask => $mask);
	$numbigsubnets = ipNumSubnets(wildcard => $subwildcard);

	$numsubnets = ( $numbigsubnets + 1 ) / ( $numsmallsubnets + 1 );
	$numsubnets = ( $subhosts + 2 ) / ( $hosts + 2 ) ;
	
	
	#print "<TR bgcolor=\"#FFFFFF\"><TD>$numsubnets = $numbigsubnets $numsmallsubnets<TD><TR>\n";

	#Display the big subnet!
	print<<EOHTML;
	<tr>
	<TD class="white" COLSPAN="$colspan">
	<TABLE class="white">
	<tr><TD class="grey" COLSPAN=2>Second Subnet Mask</TD></TR>
	<tr><TD class="line">Subnet</TD><TD class="line">$subsubnet</TD></TR>
	<tr><TD class="line">Broadcast Address</TD><TD class="line">$subbroadcast</TD></TR>
	<tr><TD class="line">IP Subnet Mask</TD><TD class="line">$submask</TD></TR>
	<tr><TD class="line">Mask Bits</TD><TD class="line">$subbits</TD></TR>
	<tr><TD class="line">Wildcard Mask</TD><TD class="line">$subwildcard</TD></TR>
	<tr><TD class="line">Number Hosts</TD><TD class="line">$subhosts</TD></TR>
	<tr><TD class="line">Number Subnets for $mask</TD><TD class="line">$numsubnets</TD></TR>
	</TABLE>
	</TD>
	</tr>
EOHTML
	#Display the range of subnet ie mask - submask = 15 subnets
	print<<EOHTML;
	<TR>
	<TD class="white">
	<TABLE class="white">
	<tr><TD class="grey" COLSPAN="3">Subnet Table for $mask into $submask</TD></TR>
	<tr><TD class="line" COLSPAN="3">Starting Subnet $subsubnet</TD></TR>
	<tr><TD class="line" COLSPAN="3">Last Address $subbroadcast</TD></TR>
EOHTML
	#<TR><TD class="line">Subnet</TD><TD class="line">Broadcast</TD><TD class="line">Mask</TD></TR>
	print "<TR><TD class=\"\">\n";
	print "<PRE>\n";
	print "Subnet\tBroadcast\tMask\n";	

	#print "</TD></TR>\n";
	#print "<TR><TD class=\"\"><PRE>\n";

	for ( $i = 1; $i <= $numsubnets; ++$i ) {
		($subsubnet,$subbits) = ipSubnet(address => $subsubnet, mask => $mask);
		$subbroadcast = ipBroadcast(subnet => $subsubnet, mask => $mask);
		print "$subsubnet\t$subbroadcast\t$mask\n";
		$subsubnet = ipNextSubnet(subnet => $subsubnet, mask => $mask);
	}
	print "</PRE></TD></TR>\n";

	print<<EOHTML;
	</TABLE>
	</TD>
	</tr>
EOHTML

}
