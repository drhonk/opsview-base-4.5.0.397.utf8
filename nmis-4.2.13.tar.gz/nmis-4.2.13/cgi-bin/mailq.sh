#!/bin/ksh
#    A simple cgi demo to report mailq on a *nix box
#    Release free under the GPL as part of NMIS
#    Copyright (C) 2002 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis

PATH=$PATH:/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin

MAILQ=`mailq`
DATE=`date`

echo "Content-type: text/html"
echo
echo
echo "<html><head><title>Mail Queue</title></head><body><center><h2>Mail Queue at $DATE</h2></center><pre>$MAILQ</pre></body></html>"
exit
