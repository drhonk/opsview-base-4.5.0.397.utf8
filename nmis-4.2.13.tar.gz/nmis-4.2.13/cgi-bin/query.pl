#!/usr/bin/perl
#
# $Id: query.pl,v 1.6 2006/09/28 09:32:03 decologne Exp $
#
#    query.pl - NMIS CGI Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 

my $configfile = "$FindBin::Bin/nmis.conf";
$configfile =~ s/bin|cgi-bin/conf/;
# 
#****** Shouldn't be anything else to customise below here *******************

use Time::ParseDate; 
use strict;
use NMIS;
use func;


# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

# set default nmis.conf
my $conf = "nmis.conf";

# This reads in the information sent when the user pressed Submit
my %FORM = getCGIForm($ENV{'QUERY_STRING'});
my $scriptname = $ENV{SCRIPT_NAME};

# Break the queary up for the names
my $query = $FORM{query};
my $group = $FORM{group};
my $type = $FORM{type};
my $node = $FORM{node};
# Allow program to use other configuration files
if ( $FORM{file} ne "" ) { $configfile = $FORM{file}; }

loadConfiguration($configfile);

my $version = "1.00";

# Before going any further, check to see if we must handle
# an authentication login or logout request
$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

eval {
	require NMIS::Auth or die "NO_NAUTH module";
};
if ( $@ =~ /NO/ ) {
	$auth = \{ Require => 0 };
} else {
	$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
	$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth
}

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# verify access to this action
	# check access for table
	$auth->CheckAccess($user, "query") or die "Attempted unauthorized access";

	# logout ?
	if ( $type eq 'logout' ) {
       	$auth->do_logout;
		exit 0;
	}
	# generate the cookie if $user->user is set
	if ( $user->user ) {
        push @cookies, $auth->generate_cookie($user->user);
        $headeropts{-cookie} = [@cookies];
	}
}


&startTextPage;

# make the default action to be info
if 	( $query eq "status" and $node ne "" ) 	{ &nodestatus($node); }
elsif 	( $query eq "status" ) 			{ &groupstatus($group); }
elsif 	( $query eq "list" ) 			{ &grouplist($group); }
else 						{ &noquery; }

print "end\n";
exit 0;

sub grouplist {
	my $group = shift;
	my $node;
	my $event_status;
	my $event_color;
	my $groupStatus;

	loadNodeDetails;
	loadEventStateNoLock;

	print "query=list\n";
	print "group=$group\n";
	print "version=$version\n";
	# Insert some nice status info about the devices for the summary menu.
	if ( $group eq "" ) {
	        foreach $group (sort ( keys (%NMIS::groupTable) ) ) {
			next unless $user->InGroup($group);
			$groupStatus = overallNodeStatus($group);
			print "group=$group:$groupStatus\n";
		}
	}
	foreach $node (sort ( keys (%NMIS::nodeTable) ) ) {
		next unless $user->InGroup($group);
		#Only do the group
		if ( $group eq $NMIS::nodeTable{$node}{group} or $group eq "") {
			if ( eventExist($node,"Node Down","Ping failed") eq "true" ) {
				($event_status,$event_color) = eventLevel("Node Down",$NMIS::nodeTable{$node}{role});
			}
			else {
				($event_status,$event_color) = eventLevel("Node Up",$NMIS::nodeTable{$node}{role});
			}
			print "node=$node:$event_status\n";	
		}
	}
}

sub groupstatus {
	my $group = shift;
	my $start_time = shift;
	my $end_time = shift;
	my %summaryHash;
	my $groupStatus;

	if ( $start_time eq "" ) { $start_time = "-8 hours"; }
	if ( $end_time eq "" ) { $end_time = time; }

	%summaryHash = &getGroupSummary("","-16 hours","-8 hours");
	$groupStatus = overallNodeStatus($group);

	print "query=status\n";
	print "group=$group\n";
	print "status=$groupStatus\n";
	print "reachable=$summaryHash{average}{reachable}\n";
	print "available=$summaryHash{average}{available}\n";
	print "health=$summaryHash{average}{health}\n";
	print "response=$summaryHash{average}{response}\n";
	print "metric=$summaryHash{average}{metric}\n";
	print "count=$summaryHash{average}{count}\n";
}

sub nodestatus {
	my $node = shift;
	my $start_time = shift;
	my $end_time = shift;
	
	my @tmparray;
	my @tmpsplit;
	my %summaryHash;
	my $overallStatus;
	my $reportStats;
	my $index;

	if ( $start_time eq "" ) { $start_time = "-8 hours"; }
	if ( $end_time eq "" ) { $end_time = time; }

	loadEventStateNoLock;
	if ( eventExist($node,"Node Down","Ping failed") eq "true" ) {
		($summaryHash{$node}{event_status},$summaryHash{$node}{event_color}) = eventLevel("Node Down",$NMIS::nodeTable{$node}{role});
	}
	else {
		($summaryHash{$node}{event_status},$summaryHash{$node}{event_color}) = eventLevel("Node Up",$NMIS::nodeTable{$node}{role});
	}

	loadSystemFile($node);
## call of summaryStats has been changed, Cologne 2005
##	$reportStats = summaryStats($node,"health",$start_time,$end_time);
	%summaryHash = (%summaryHash,summaryStats(node => $node,type => "health",start => $start_time,end => $end_time, key => $node));
##	if ( $reportStats != 1 and $reportStats ne "" ) {
##		@tmparray = split " ","@$reportStats";
##		for ( $index = 0; $index <= $#tmparray; ++$index ) {
##			@tmpsplit = split "=",@tmparray[$index];
##			$summaryHash{$node}{$tmpsplit[0]} = $tmpsplit[1];
##		}
##	}
	$summaryHash{$node}{metric} = sprintf("%.3f",( ( $summaryHash{$node}{reachable} + $summaryHash{$node}{available} + $summaryHash{$node}{health} ) / 3) );
	#$overallStatus = overallNodeStatus($group);

	print "query=status\n";
	print "node=$node\n";
	print "version=$version\n";
	print "status=$summaryHash{$node}{event_status}\n";
	print "reachable=$summaryHash{$node}{reachable}\n";
	print "available=$summaryHash{$node}{available}\n";
	print "health=$summaryHash{$node}{health}\n";
	print "response=$summaryHash{$node}{response}\n";
	print "metric=$summaryHash{$node}{metric}\n";
}

sub noquery {
	print "ERROR: no query requested\n";	
	print "operations supported:\n";
	print "http://server/$ENV{SCRIPT_NAME}?query=list\n";
	print "http://server/$ENV{SCRIPT_NAME}?query=list&group=<name>\n";
	print "http://server/$ENV{SCRIPT_NAME}?query=status\n";
	print "http://server/$ENV{SCRIPT_NAME}?query=status&group=<name>\n";
	print "http://server/$ENV{SCRIPT_NAME}?query=status&node=<name>\n";
}

sub startTextPage {
	print "Content-type: text/plain\n\n";
}
