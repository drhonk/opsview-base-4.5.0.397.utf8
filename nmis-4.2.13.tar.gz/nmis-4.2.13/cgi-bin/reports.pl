#!/usr/bin/perl
#
#    reports.pl - NMIS Perl Program - Network Mangement Information System
#    Copyright (C) 2000 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# call me like this.
# web interface
# reports.pl?file=nmis.conf&type=reports&report=health&length=week&sort=health
#
# commmand line
# if no outfile file, defaults to stdout
# typically called from /nmis/bin/run-reports.sh - sets outfile names based on report type etc.
# can be tested from cmd line like this..
# reports.pl file=nmis.conf report=health length=week outfile=file
#
# available report type:
# report=health 	length=month|day|week
# report=avail		length=month|day|week
# report=top10 		length=15min|month|day|week
# report=outage		length=month|day|week level=node|interface
# report=port 		# current port count summaries
# report=counts 	# current port count with per device summaries
# report=response	length=month|day|week or defaults to last 6 hrs
# report=nodedetails	# replaces /lib/detail.pm - that file can be removed.
#
# example cron jobs for all stored report types
# edit mypath to suit your installation
# edit path in /bin/run-reports.sh
########################################
# Run the Reports Weekly Monthly Daily
#
# daily
# 0 0 * * * /mypath/run-reports.sh day health
# 0 0 * * * /mypath/run-reports.sh day top10
# 0 0 * * * /mypath/run-reports.sh day outage
# 0 0 * * * /mypath/run-reports.sh day response
# 0 0 * * * /mypath/run-reports.sh day avail
# 0 0 * * * /mypath/run-reports.sh day port
# weekly
# 0 0 * * 0 /mypath/run-reports.sh week health
# 0 0 * * 0 /mypath/run-reports.sh week top10
# 0 0 * * 0 /mypath/run-reports.sh week outage
# 0 0 * * 0 /mypath/run-reports.sh week response
# 0 0 * * 0 /mypath/run-reports.sh week avail
# monthly
# 0 0 1 * * /mypath/run-reports.sh month health
# 0 0 1 * * /mypath/run-reports.sh month top10
# 0 0 1 * * /mypath/run-reports.sh month outage
# 0 0 1 * * /mypath/run-reports.sh month response
# 0 0 1 * * /mypath/run-reports.sh month avail
###########################################
#
# css styles
#
### Style Guide ###
###		cssPrintHeadRow('head text', 'grey', span);		# report header
###		cssPrintCell('grey', "head text", span);		# group section header
###		printHeadRow( 'field header' );				# field header
###		printCell( 'text', 'color' );				# cell text and color
# 
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 
# 
#****** Shouldn't be anything else to customise below here *******************

require 5;
use Fcntl qw(:DEFAULT :flock);

use Time::ParseDate;
use RRDs;
use strict;
use web;
use csv;
use NMIS;
use func;
use rrdfunc;

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

my $my_data;
my $conf;
my $type;
my $report;
my $length;
my $sort;
my $debug = "";
my $fileprint = 0;

my %FORM;
my %summaryHash;
my %nvp;
my $level;
my $csvfile;

# Prefer to use CGI for html processing
use CGI qw(:standard);

# declare holder for CGI objects
use vars qw($q);
$q = new CGI; # This processes all parameters passed via GET and POST

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

my $auth = ();
my $user = ();

my $my_data;
my %FORM;

if($ENV{'REQUEST_METHOD'} eq "GET"){
   $my_data = $ENV{'QUERY_STRING'};
}
else {
   my $bytes_read = read(STDIN, $my_data, $ENV{'CONTENT_LENGTH'});
}


my @pairs = split(/&/, $my_data);
foreach (@pairs) {
	my ($name, $value) = split(/=/, $_);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$FORM{$name} = $value;
}

# Allow program to use other configuration files
my $conf;
if ( $FORM{file} ne "" ) { $conf = $FORM{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }


# if no options, assume called from web interface ....
if ( $#ARGV > 0 ) {
	%nvp = getArguements(@ARGV);

	$conf = $nvp{file} ? $nvp{file} : "nmis.conf";
	$report = $nvp{report} ? $nvp{report} : "health";
	$length = $nvp{length} ? $nvp{length} : "15min";
	$level = $nvp{level} ? $nvp{level} : "node";		# for outage report
	$debug = $nvp{debug};
	$csvfile = $nvp{csvfile};
	if ( $nvp{outfile} ) {
		open (STDOUT,">$nvp{outfile}") or die "Cannot open the file $nvp{outfile}. $!";
		## $print = 1;
	}
	$fileprint = 1;
	$auth = NMIS::Auth->new; 
	$auth = \{ Require => 0} ;
}
elsif ( $ENV{'REQUEST_METHOD'} eq "GET" ) {

	$conf = $FORM{file} ? $FORM{file} : "nmis.conf";
	$type = $FORM{type};
	$report = $FORM{report};
	$length = $FORM{length};
	$sort = $FORM{sort};
	$level = $FORM{level};
	$csvfile = $FORM{csvfile};

	# Before going any further, check to see if we must handle
	# an authentication login or logout request
	$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
	$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
	$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;


	eval {
		require NMIS::Auth or die "NO_NAUTH module";
	};
	if ( $@ =~ /NO/ ) {
		$auth = \{ Require => 0 };
	} else {
		$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
		$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth
	}

	# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
	#
	if ( $auth->Require ) {
		# either set by the web server or via a set cookie
		$user->SetUser( $auth->verify_id );

		# $user should be set at this point, if not then redirect
		unless ( $user->user ) {
			$auth->do_force_login("Authentication is required. Please login.");
			exit 0;
		}
		# verify access to this plugin
		$auth->CheckAccess($user, "reports") or die "Attempted unauthorized access";

		# logout ?
		if ( $FORM{type} eq 'logout' ) {
   	    	$auth->do_logout;
			exit 0;
		}
		# generate the cookie if $user->user is set
		if ( $user->user ) {
   	     push @cookies, $auth->generate_cookie($user->user);
   	     $headeropts{-cookie} = [@cookies];
		}
	}
} else { exit; }		# should not get here!!

if ( $debug ) {
	require Data::Dumper;
	Data::Dumper->import();
	$Data::Dumper::Indent = 1;
	$NMIS::debug = $debug;
}


# slave ?
if ($NMIS::config{master_dash} eq "true"){ &loadSlave; }

# if cvsfile option, send as a csv file to Excel
if ( $csvfile ) {

	if ( $report eq "nodedetails" ) {

		# file
		my $detailvar;
		my $node;
		my $group;
		
		loadNodeDetails;
		
		# this will launch Excel - as it is the default application handler for .csv files
		print "Content-type: application/octet-stream;\n";
		print "Content-disposition: inline; filename=$csvfile.csv\n";
		# seems to be needed for IE
		print "Cache-control: private\n";
        print "Pragma: no-cache\n";
        print "Expires: 0\n\n";

		my @line;
		println( 'Node','Type','Location','System Uptime','Node Vendor','NodeModel', 'SystemName','S/N','Chassis','ProcMem','Version');

		foreach $group (sort ( keys (%NMIS::groupTable) ) ) {
			if (defined $user) {next unless $user->InGroup($group)}; 
			foreach $node (sort ( keys (%NMIS::nodeTable) ) ) {
				if ( $NMIS::nodeTable{$node}{group} eq "$group" ) {

					loadSystemFile($node);
					undef @line;

					# display sysName if $node is a IPV4 address
					if ( $node =~ /\d+\.\d+\.\d+\.\d+/ and $NMIS::systemTable{sysName} ne "" ) {
						push( @line, $NMIS::systemTable{sysName});
					}
					else {
						push( @line, $node);
					}
					push( @line, $NMIS::nodeTable{$node}{devicetype});
					push( @line, $NMIS::systemTable{sysLocation});
					push( @line, $NMIS::systemTable{sysUpTime});
					push( @line, $NMIS::systemTable{nodeVendor});
					push( @line, $NMIS::systemTable{nodeModel});
					push( @line, $NMIS::systemTable{sysObjectName});
					push( @line, $NMIS::systemTable{serialNum});
					push( @line, $NMIS::systemTable{chassisVer});
					push( @line, $NMIS::systemTable{processorRam});
					
					$detailvar = $NMIS::systemTable{sysDescr};
					$detailvar =~ s/^.*WS/WS/g;
					$detailvar =~ s/Cisco Catalyst Operating System Software/CatOS/g;
					$detailvar =~ s/Copyright.*$//g;
					$detailvar =~ s/TAC Support.*$//g;
					$detailvar =~ s/RELEASE.*$//g;
					$detailvar =~ s/Cisco.*tm\) //g;
					# drop any 'built by'
					$detailvar =~ s/built by.*$//;
					# maybe a windows box ?
					$detailvar =~ s/^.*Windows/Windows/;
				
					push( @line, $detailvar);
					println( @line );
				}
			}
		}
		sub println {
		    local $\ = "\n";			# print newline
		    local $, = ',';				# print seperator between arguments
		    # strip embedded commas
		    my @parms = @_;				# must copy or localise @_ for the 'for' loop to work.
		    for (@parms) { s/,/_/g }
		    print @parms;
		}
	}	
}
else {
	&typeReports;
}
exit;


sub typeReports {

	my $net;
	my $role;
	my $header;
	my $start_time;
	my $datestamp_start;
	my $datestamp_end;
	my $time = time;
	my $graphLink;
	my $random = rand 10000;
	my $reportnode;
	my $index;
	my $reportFile;
	my $reportLink;
	my $reportStats;
	my $reportLength;
	my %reportTable;
	my %summaryTable;
	my $summaryhash;
	my @tmparray;
	my @tmpsplit;
	my $cellColor;
	my $stamp = returnDateStamp;
	my $group;

	loadNodeDetails;
	$datestamp_end = returnDateStamp($time);

	my $nmis_url = "<a href=\"$NMIS::config{nmis}?file=$conf\"><img alt=\"NMIS Dash\" src=\"$NMIS::config{nmis_icon}\" border=\"0\"></a>";
	my $back_url = "<a href=\"$ENV{HTTP_REFERER}\"><img alt=\"Back\" src=\"$NMIS::config{back_icon}\" border=\"0\"></a>";

	if ( !$fileprint) {
		my $title = "Reports";
		pageStartCSS($title,$NMIS::config{styles},"", \%headeropts);
		cssTableStart('plain');
		print Tr(td( &NMIS::do_dash_banner($auth->Require, $user->user) ));
		$header .= "$back_url$nmis_url&nbsp;";
	} else {
	 	print <<ENDHTML;
		<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
		<html>
		  <head>
		    <link href="$NMIS::config{styles}" rel="stylesheet" type="text/css">
		    <title>Reports</title>
		  </head>
		  <body>
ENDHTML
	}

	cssTableStart('plain');

	if ( $report eq "nodedetails" ) {

		my $group;

		loadNodeDetails;
		cssPrintHeadRow("$header Node Asset Details Report", 'grey2', 1);

		foreach $group (sort ( keys (%NMIS::groupTable) ) ) {
			if (defined $user) {next unless $user->InGroup($group)}; 
			rowStart;
			cssPrintCell('grey', "$group Nodes", 1);
			rowEnd;

			rowStart;
			cssCellStart('white', 1);
			cssTableStart('plain');
			printHeadRow("Node,Type,Location,System Uptime,Node Vendor,NodeModel,SystemName,S/N,Chassis,ProcMem,Version" );
			&printNodeTypeDetailed($group);
			tableEnd;
			cellEnd;
			rowEnd;
		}
		
		sub printNodeTypeDetailed {
			my $group = shift;
			my $cellcolor = "#aaaaaa";
			my $detailvar;
			my $node;

			foreach $node (sort ( keys (%NMIS::nodeTable) ) ) {
				if ( $NMIS::nodeTable{$node}{group} eq "$group" ) {
					if ( $NMIS::nodeTable{$node}{active} ne "false" ) {
						$cellcolor = "#ffffff";
					}
					else {
						$cellcolor = "#aaaaaa";
					}

					rowStart;
					# Load the system table for the node.
					loadSystemFile($node);

					# display sysName if $node is a IPV4 address
					if ( $node =~ /\d+\.\d+\.\d+\.\d+/      and $NMIS::systemTable{sysName} ne "" ) {
						printCell("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;node=$node&amp;type=summary\">$NMIS::systemTable{sysName}</a>", $cellcolor);
					}
					else {
						printCell("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;node=$node&amp;type=summary\">$node</a>", $cellcolor);
					}
					printCell( "$NMIS::nodeTable{$node}{devicetype}", $cellcolor);
					printCell( "$NMIS::systemTable{sysLocation}", $cellcolor);
					printCell( "$NMIS::systemTable{sysUpTime}", $cellcolor);
					printCell( "$NMIS::systemTable{nodeVendor}", $cellcolor);
					printCell( "$NMIS::systemTable{nodeModel}", $cellcolor);
					printCell( "$NMIS::systemTable{sysObjectName}", $cellcolor);
					printCell( "$NMIS::systemTable{serialNum}", $cellcolor);
					printCell( "$NMIS::systemTable{chassisVer}", $cellcolor);
					printCell( "$NMIS::systemTable{processorRam}", $cellcolor);

					$detailvar = $NMIS::systemTable{sysDescr};
					$detailvar =~ s/^.*WS/WS/g;
					$detailvar =~ s/Cisco Catalyst Operating System Software/CatOS/g;
					$detailvar =~ s/Copyright.*$//g;
					$detailvar =~ s/TAC Support.*$//g;
					$detailvar =~ s/RELEASE.*$//g;
					$detailvar =~ s/Cisco.*tm\) //g;
					# drop any 'built by'
					$detailvar =~ s/built by.*$//;
					# maybe a windows box ?
					$detailvar =~ s/^.*Windows/Windows/;

					printCell( "$detailvar",$cellcolor);
					rowEnd;
				}
			}
		}
	}
	elsif ( $report eq "health" ) {

		if ( $length eq "month" ) {
			$reportLength = "-1 months";
			$datestamp_start = returnDateStamp(convertTime("1","months"));
			$header .= "Monthly Dynamic Summary Health Metrics from $datestamp_start to $datestamp_end";
		}
		elsif ( $length eq "day" ) {
			$reportLength = "-1 days";
			$datestamp_start = returnDateStamp(convertTime("1","days"));
			$header .= "Daily Dynamic Summary Health Metrics from $datestamp_start to $datestamp_end";
		}
		else {
			$reportLength = "-1 weeks";
			$datestamp_start = returnDateStamp(convertTime("1","weeks"));
			$header .= "Weekly Dynamic Summary Health Metrics from $datestamp_start to $datestamp_end";
		}
		cssPrintHeadRow( $header, 'grey','1');

		# slave
		if ( $NMIS::config{master_report} eq "true" ) {
			foreach my $name (keys %NMIS::slaveTable) {
				%reportTable = (%reportTable,slaveConnect(host => $name,type => 'send',func => 'report_reporttable',par1 => $reportLength,par2 => time));
			}
		}
		# Get each of the nodes info in a HASH for playing with
		foreach $reportnode (sort(keys(%NMIS::nodeTable))) {
			if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
			## AS 16 Mar 02, implementing David Gay's requirement for deactiving
			# a node, ie keep a node in nodes.csv but no collection done.
			if ( $NMIS::nodeTable{$reportnode}{active} ne "false" ) {
				loadSystemFile($reportnode);
				# get reachable, available, health, response
				if ( not exists $NMIS::nodeTable{$reportnode}{slave} and not exists $NMIS::nodeTable{$reportnode}{slave2}) {
	    			%reportTable = (%reportTable,summaryStats(node => $reportnode,type => "health",start => $reportLength,end => time, key => $reportnode,slave => $NMIS::config{master_report}));
				}

				$reportTable{$reportnode}{reachable} = 0 if $reportTable{$reportnode}{reachable} eq "NaN";
				$reportTable{$reportnode}{available} = 0 if $reportTable{$reportnode}{available} eq "NaN";
				$reportTable{$reportnode}{health} = 0 if $reportTable{$reportnode}{health} eq "NaN";
				$reportTable{$reportnode}{response} = 0 if $reportTable{$reportnode}{response} eq "NaN";
				$reportTable{$reportnode}{loss} = 0 if $reportTable{$reportnode}{loss} eq "NaN";

				$reportTable{$reportnode}{net} = $NMIS::nodeTable{$reportnode}{net};
				$reportTable{$reportnode}{role} = $NMIS::nodeTable{$reportnode}{role};
				$reportTable{$reportnode}{devicetype} = $NMIS::nodeTable{$reportnode}{devicetype};
				$reportTable{$reportnode}{group} = $NMIS::nodeTable{$reportnode}{group};

				# Calculate the summaries!!!!
				$summaryhash = "$reportTable{$reportnode}{net}-$reportTable{$reportnode}{role}";
				$summaryTable{$summaryhash}{net} = $reportTable{$reportnode}{net};
				$summaryTable{$summaryhash}{role} = $reportTable{$reportnode}{role};
				$summaryTable{$summaryhash}{reachable} = $summaryTable{$summaryhash}{reachable} + $reportTable{$reportnode}{reachable};
				$summaryTable{$summaryhash}{available} = $summaryTable{$summaryhash}{available} + $reportTable{$reportnode}{available};
				$summaryTable{$summaryhash}{health} = $summaryTable{$summaryhash}{health} + $reportTable{$reportnode}{health};
				$summaryTable{$summaryhash}{response} = $summaryTable{$summaryhash}{response} + $reportTable{$reportnode}{response};
				$summaryTable{$summaryhash}{loss} = $summaryTable{$summaryhash}{loss} + $reportTable{$reportnode}{loss};
				++$summaryTable{$summaryhash}{count};

				$summaryhash = $reportTable{$reportnode}{group};
				$summaryTable{$summaryhash}{net} = $reportTable{$reportnode}{group};
				$summaryTable{$summaryhash}{role} = "";
				$summaryTable{$summaryhash}{group} = $reportTable{$reportnode}{group};
				$summaryTable{$summaryhash}{reachable} = $summaryTable{$summaryhash}{reachable} + $reportTable{$reportnode}{reachable};
				$summaryTable{$summaryhash}{available} = $summaryTable{$summaryhash}{available} + $reportTable{$reportnode}{available};
				$summaryTable{$summaryhash}{health} = $summaryTable{$summaryhash}{health} + $reportTable{$reportnode}{health};
				$summaryTable{$summaryhash}{response} = $summaryTable{$summaryhash}{response} + $reportTable{$reportnode}{response};
				$summaryTable{$summaryhash}{loss} = $summaryTable{$summaryhash}{loss} + $reportTable{$reportnode}{loss};
				++$summaryTable{$summaryhash}{count};
			}
		}

		# if debug, print all
		if ( $debug eq "true" ) {
			print Dumper(\%reportTable);
			print Dumper(\%summaryTable);
		}

	 	rowStart;
	 	cellStart("#FFFFFF",20);
	 	cssTableStart("white");
	 	cssPrintCell('grey', "Average Health for Device Groups", 10 );
	 	printHeadRow("Group,Reachability,Interface Avail.,Health,Response Time");

		# print a summary table for the health
		foreach $group ( sort ( keys %summaryTable ) ) {
			if (defined $user) {next unless $user->InGroup($group)}; 
			if ( $summaryTable{$group}{net} =~ /lan|wan/i ) {
				$summaryTable{$group}{net} = uc($summaryTable{$group}{net});
			}
			rowStart;
			printHeadCell("<a href=\"#$group\">$summaryTable{$group}{net} $summaryTable{$group}{role}</a>");
			if ( $summaryTable{$group}{reachable} > 0 ) {
				$summaryTable{$group}{avgreachable} = sprintf("%.3f",$summaryTable{$group}{reachable} / $summaryTable{$group}{count});
				$cellColor = colorHighGood($summaryTable{$group}{avgreachable});
				printHeadCell($summaryTable{$group}{avgreachable},$cellColor);
			}
			if ( $summaryTable{$group}{available} > 0 ) {
				$summaryTable{$group}{avgavailable} = sprintf("%.3f",$summaryTable{$group}{available} / $summaryTable{$group}{count});
				$cellColor = colorHighGood($summaryTable{$group}{avgavailable});
				printHeadCell($summaryTable{$group}{avgavailable},$cellColor);
			}
			if ( $summaryTable{$group}{health} > 0 ) {
				$summaryTable{$group}{avghealth} = sprintf("%.3f",$summaryTable{$group}{health} / $summaryTable{$group}{count});
				$cellColor = colorHighGood($summaryTable{$group}{avghealth});
				printHeadCell($summaryTable{$group}{avghealth},$cellColor);
			}
			if ( $summaryTable{$group}{response} > 0 ) {
				$summaryTable{$group}{avgresponse} = sprintf("%.3f",$summaryTable{$group}{response} / $summaryTable{$group}{count});
				$cellColor = colorResponseTime($summaryTable{$group}{avgresponse});
				printHeadCell($summaryTable{$group}{avgresponse},$cellColor);
			}
			rowEnd;
		}

	 	tableEnd;
	 	paragraph;

		foreach $group ( sort ( keys %NMIS::groupTable ) ) {
			if (defined $user) {next unless $user->InGroup($group)}; 
		 	cssTableStart("white");
			 	cssPrintCell('grey', "<A name=$group><a href=#TOP>$group</a>", 10);
			 	rowStart;
				printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;length=$length&amp;sort=node\">Node</a>","#FFFFFF");
			 	printHeadCell("Device Type","#FFFFFF");
			 	printHeadCell("Role","#FFFFFF");
			 	printHeadCell("Net","#FFFFFF");
			 	printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;length=$length&amp;sort=reachability\">Reachability</a>","#FFFFFF");
			 	printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;length=$length&amp;sort=availability\">Interface Avail.</a>","#FFFFFF");
			 	printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;length=$length&amp;sort=health\">Health</a>","#FFFFFF");
			 	printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;length=$length&amp;sort=response\">Response Time</a>","#FFFFFF");
			 	rowEnd;
				&reportNodeType($group);
		 	tableEnd;
			paragraph;
	 	}
	 	cellEnd;
	 	rowEnd;
	} # report eq health

	# Top10 reports
	elsif ( $report eq "top10" ) {
		## I got fed up with sort breaking on NaN/nan, so I sent them to zero !

		if ( $length eq "15min" ) {
			$reportLength = "-15 minutes";
			$datestamp_start = returnDateStamp(convertTime("15","minutes"));
			$header .= "Current Network Top10 from $datestamp_start to $datestamp_end";
		}
		elsif ( $length eq "day" ) {
			$reportLength = "-1 days";
			$datestamp_start = returnDateStamp(convertTime("1","days"));
			$header .= "Daily Network Top10 from $datestamp_start to $datestamp_end";
		}
		elsif ( $length eq "week" ) {
			$reportLength = "-1 weeks";
			$datestamp_start = returnDateStamp(convertTime("1","weeks"));
			$header .= "Weekly Network Top10 from $datestamp_start to $datestamp_end";
		}
		else {
			$reportLength = "-1 month";
			$datestamp_start = returnDateStamp(convertTime("1","months"));
			$header .= "Monthly Network Top10 from $datestamp_start to $datestamp_end";
		}

		cssPrintHeadRow( $header, 'grey','2');

		# Get each of the nodes info in a HASH for playing with
		my %cpuTable;
		if ( $NMIS::config{master_report} eq "true" ) {
			foreach my $name (keys %NMIS::slaveTable) {
				%reportTable = (%reportTable,slaveConnect(host => $name,type => 'send',func => 'report_reporttable',par1 => $reportLength,par2 => time));
				%cpuTable = (%cpuTable,slaveConnect(host => $name,type => 'send',func => 'report_cputable',par1 => $reportLength,par2 => time));
			}
		}
		foreach $reportnode ( keys %NMIS::nodeTable ) {
			if ((exists $NMIS::nodeTable{$reportnode}{slave} or exists $NMIS::nodeTable{$reportnode}{slave2})
					and $NMIS::config{master_report} ne "true" ) {
				next;
			}
			if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
			## AS 16 Mar 02, implementing David Gay's requirement for deactiving
			# a node, ie keep a node in nodes.csv but no collection done.
			if ( $NMIS::nodeTable{$reportnode}{active} ne "false") {
				if ( not exists $NMIS::nodeTable{$reportnode}{slave} and not exists $NMIS::nodeTable{$reportnode}{slave2}) {
					loadSystemFile($reportnode);
					# reachable, available, health, response
	    			%reportTable = (%reportTable,summaryStats(node => $reportnode,type => "health",start => $reportLength,end => time,key => $reportnode));
					# cpu only for routers, switch cpu and memory in practice not an indicator of performance.
					# avgBusy1min, avgBusy5min, ProcMemUsed, ProcMemFree, IOMemUsed, IOMemFree
	    			%cpuTable = (%cpuTable,summaryStats(node => $reportnode,type => "cpu",start => $reportLength,end => time,key => $reportnode));
					$cpuTable{$reportnode}{avgBusy5min} = 0 if $cpuTable{$reportnode}{avgBusy5min} eq "NaN";
				}
				$reportTable{$reportnode}{devicetype} = $NMIS::nodeTable{$reportnode}{devicetype} ;
			} # end $reportnode loop
		}
		# now the link stats - by linkname

		my %linkTable;
		my %pktsTable;
		my %downTable;
		my %pvcTable;
		my $prev_loadsystemfile;

		loadInterfaceInfo;
		# slave
		if ( $NMIS::config{master_report} eq "true" ) {
			foreach my $name (keys %NMIS::slaveTable) {
				%NMIS::interfaceInfo= (%NMIS::interfaceInfo,slaveConnect(host => $name,type => 'send',func => 'loadInterfaceInfo'));
				%linkTable = (%linkTable,slaveConnect(host => $name,type => 'send',func => 'report_linktable',par1 => $reportLength,par2 => time));
				%pktsTable = (%pktsTable,slaveConnect(host => $name,type => 'send',func => 'report_pktstable',par1 => $reportLength,par2 => time));
				%pvcTable = (%pvcTable,slaveConnect(host => $name,type => 'send',func => 'report_pvctable',par1 => $reportLength,par2 => time));
			}
		}
		foreach my $int ( keys %NMIS::interfaceInfo ) {
			if ( $NMIS::interfaceInfo{$int}{collect} eq "true" ) {
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$NMIS::interfaceInfo{$int}{node}}{group})}; 
				# availability, inputUtil, outputUtil, totalUtil
				my $tmpifDescr = convertIfName($NMIS::interfaceInfo{$int}{ifDescr});
				# we need the nodeType for summary stats to get the right directory
				if ($NMIS::interfaceInfo{$int}{node} ne $prev_loadsystemfile) {
					if (not exists $NMIS::nodeTable{$NMIS::interfaceInfo{$int}{node}}{slave2}) {
						loadSystemFile($NMIS::interfaceInfo{$int}{node});
					} 
					$prev_loadsystemfile = $NMIS::interfaceInfo{$int}{node};
				}
				if ( not exists $NMIS::nodeTable{$NMIS::interfaceInfo{$int}{node}}{slave2} ) {
			    	%linkTable = (%linkTable,summaryStats(node => $NMIS::interfaceInfo{$int}{node},type => "util",start => $reportLength,end => time,ifDescr => $tmpifDescr,speed => $NMIS::interfaceInfo{$int}{ifSpeed},key => $int));
				}
				$linkTable{$int}{node} = $NMIS::interfaceInfo{$int}{node} ;
				$linkTable{$int}{ifDescr} = $NMIS::interfaceInfo{$int}{ifDescr} ;
				$linkTable{$int}{Description} = $NMIS::interfaceInfo{$int}{Description} ;

				# save the interface state for the down report
				if ( $NMIS::systemTable{nodeModel} ne "generic"
					and $NMIS::interfaceInfo{$int}{collect} eq "true"
					and $NMIS::interfaceInfo{$int}{ifAdminStatus} eq "up"
					and $NMIS::interfaceInfo{$int}{ifOperStatus} ne "up"
					and $NMIS::interfaceInfo{$int}{ifOperStatus} ne "ok"			
					and $NMIS::interfaceInfo{$int}{ifOperStatus} ne "dormant"
				) {
					$downTable{$int}{node} = $NMIS::interfaceInfo{$int}{node} ;
					$downTable{$int}{ifDescr} = $NMIS::interfaceInfo{$int}{ifDescr} ;
					$downTable{$int}{Description} = $NMIS::interfaceInfo{$int}{Description} ;
					$downTable{$int}{ifLastChange} = $NMIS::interfaceInfo{$int}{ifLastChange};
					# for sorting make a number out of this [xx days xx:xx:xx]
					$NMIS::interfaceInfo{$int}{ifLastChange} =~ s/(\d+) days//;
					@tmpsplit = split /:/ , $NMIS::interfaceInfo{$int}{ifLastChange};
					$downTable{$int}{ifLastChangeTime} = $1*60*60*24 + $tmpsplit[0]*60*60 + $tmpsplit[1]*60*60 + $tmpsplit[2];
				}
				# Availability, inputBits, outputBits
				if ( not exists $NMIS::nodeTable{$NMIS::interfaceInfo{$int}{node}}{slave2}) {
					my %hash = summaryStats(node => $NMIS::interfaceInfo{$int}{node},type => "bits",start => $reportLength,end => time,ifDescr => $tmpifDescr,speed => $NMIS::interfaceInfo{$int}{ifSpeed},key => $int);
					foreach my $k (keys %{$hash{$int}}) {
						$linkTable{$int}{$k} = $hash{$int}{$k};
					}
				}
				foreach my $k (keys %{$linkTable{$int}}) {
					$linkTable{$int}{$k} =~ s/NaN/0/ ;
				}

				$linkTable{$int}{totalBits} = ($linkTable{$int}{inputBits} + $linkTable{$int}{outputBits} ) / 2 ;
				# only report these if pkts rrd available to us.
				# change this !!! when we  are determing node collection in models.csv !!!
				# for now - match code in nmis.pl for pkts collection
				if ( $NMIS::interfaceInfo{$int}{ifType} =~ /$NMIS::config{int_stats}/i 
						and $NMIS::systemTable{nodeType} =~ /router|switch/ 	# exclude server and generic for now - need MIB-II switch here !
						and $NMIS::systemTable{nodeModel} !~ /SSII 3Com|generic|PIX|MIB2/ 		# and exclude PIX and 3Com as well - should handle with models.csv MIBII switch
					) {
					# ifInUcastPkts, ifInNUcastPkts, ifInDiscards, ifInErrors, ifOutUcastPkts, ifOutNUcastPkts, ifOutDiscards, ifOutErrors
					if ( not exists $NMIS::nodeTable{$NMIS::interfaceInfo{$int}{node}}{slave2} ){
					    %pktsTable = (%pktsTable,summaryStats(node => $NMIS::interfaceInfo{$int}{node},type => "pkts",start => $reportLength,end => time,ifDescr => $tmpifDescr,speed => $NMIS::interfaceInfo{$int}{ifSpeed},key => $int));
					}
					foreach my $k (keys %{$pktsTable{$int}}) {
						$pktsTable{$int}{$k} =~ s/NaN/0/ ;
					}

					$pktsTable{$int}{node} = $NMIS::interfaceInfo{$int}{node} ;
					$pktsTable{$int}{ifDescr} = $NMIS::interfaceInfo{$int}{ifDescr} ;
					$pktsTable{$int}{Description} = $NMIS::interfaceInfo{$int}{Description} ;
					$pktsTable{$int}{totalDiscardsErrors} = ($pktsTable{$int}{ifInDiscards} + $pktsTable{$int}{ifOutDiscards} 
						+ $pktsTable{$int}{ifInErrors} + $pktsTable{$int}{ifOutErrors} ) / 4 ;
				}
				# now for the PVC stats !
				# check if this interface is a frame, if so get the pvc.dat file and map the rrd file
				if ( $NMIS::interfaceInfo{$int}{ifType} =~ /frame-relay/
	 				and $NMIS::interfaceInfo{$int}{collect} eq "true"
					) {
					# load the pvctable map file
					# note - if node not SNMPv2 - then this file will not exist
					if ( not exists $NMIS::nodeTable{$NMIS::interfaceInfo{$int}{node}}{slave2} ){
						if ( -e "$NMIS::config{'<nmis_var>'}/$NMIS::interfaceInfo{$int}{node}-pvc.dat" ) {
							my 	%pvc = &loadCSV("$NMIS::config{'<nmis_var>'}/$NMIS::interfaceInfo{$int}{node}-pvc.dat","subifDescr","\t");
							if ( exists $pvc{lc($NMIS::interfaceInfo{$int}{ifDescr})} ) {
								%pvcTable = (%pvcTable,summaryStats(node => $NMIS::interfaceInfo{$int}{node},type => "pvc",start => $reportLength,end => time,ifDescr => $pvc{lc($NMIS::interfaceInfo{$int}{ifDescr})}{rrd},key => $int));
								foreach my $k (keys %{$pvcTable{$int}}) {
									$pvcTable{$int}{$k} =~ s/NaN/0/ ;
								}

								$pvcTable{$int}{totalECNS} = $pvcTable{$int}{ReceivedBECNs} + $pvcTable{$int}{ReceivedFECNs} ;
								$pvcTable{$int}{pvc} = $pvc{lc($NMIS::interfaceInfo{$int}{ifDescr})}{pvc} ;
								$pvcTable{$int}{node} = $NMIS::interfaceInfo{$int}{node} ;
							}
						}
					}
				}
			}
		}

		# if debug, print all
		if ( $debug eq "true" ) {
			print "reportTable\n";
			print Dumper(\%reportTable);
			print "cpuTable\n";
			print Dumper(\%cpuTable);
			print "linkTable\n";
			print Dumper(\%linkTable);
			print "pktsTable\n";
			print Dumper(\%pktsTable);
			print "pvcTable\n";
			print Dumper(\%pvcTable);
		}

		rowStart;
	 	cellStart("#FFFFFF",1);

		# top10 table - Average Response Time
	 	cssTableStart("white");
	 	cssPrintCell('grey', 'Top 10 Nodes by Average Response Time', 2);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("AVERAGE RESPONSE TIME (msec)","#FFFFFF");
		 	rowEnd;
			my $i=10;
			foreach $reportnode ( sort { $reportTable{$b}{response} <=> $reportTable{$a}{response} } keys %reportTable )
			{
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a></td>\n";
				printCellNoWrap("$reportTable{$reportnode}{response}","#FFFFFF");
				rowEnd;
				# loop control
				last if --$i == 0;
			}
	 	tableEnd;

		# top10 table - Average Ping loss
	 	cssTableStart("white");
	 	cssPrintCell('grey', 'Top 10 Nodes by Average Ping loss', 3);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("PERCENT PING LOSS","#FFFFFF",3);
		 	rowEnd;
			my $i=10;
			foreach $reportnode ( sort { $reportTable{$b}{loss} <=> $reportTable{$a}{loss} } keys %reportTable )
			{
				last if $reportTable{$reportnode}{loss} == 0;	# early exit if rest are zero.
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a></td>\n";
				print "\t<td width=\"30%\" bgcolor=\"#FFFFFF\">&nbsp;$reportTable{$reportnode}{loss} %</td>\n";
				$reportTable{$reportnode}{loss} =~ /(^\d+)/;
				printCellNoWrap("<img height=\"12\" width=\"$1\" src=\"$NMIS::config{'<url_base>'}/images/bar.png\">&nbsp;","#FFFFFF");
				rowEnd;
				# loop control
				last if --$i == 0;
			}
	 	tableEnd;


		# top10 table - CPU Load
		# only for routers

	 	cssTableStart("white");
	 	cssPrintCell('grey', 'Top 10 Nodes by CPU Load (Routers only)', 3);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("CPU LOAD","#FFFFFF",2);
		 	rowEnd;
			my $i=10;
			foreach $reportnode ( sort { $cpuTable{$b}{avgBusy5min} <=> $cpuTable{$a}{avgBusy5min} } keys %cpuTable )
			{
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a></td>\n";
				print "\t<td width=\"30%\" bgcolor=\"#FFFFFF\">&nbsp;$cpuTable{$reportnode}{avgBusy5min} %</td>\n";
				$cpuTable{$reportnode}{avgBusy5min} =~ /(^\d+)/;
				printCellNoWrap("<img height=\"12\" width=\"$1\" src=\"$NMIS::config{'<url_base>'}/images/bar.png\">&nbsp;","#FFFFFF");
				rowEnd;
				# loop control
				last if --$i == 0;
		}
	 	tableEnd;

		# top10 table - ProcMemUsed
		# only for routers

	 	cssTableStart("white");
	 	cssPrintCell('grey', 'Top 10 Nodes by % Processor Memory Used (Routers only)', 3);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("PROC MEM USED","#FFFFFF",2);
		 	rowEnd;
			my $i=10;
			foreach $reportnode ( sort { $cpuTable{$b}{ProcMemUsed} <=> $cpuTable{$a}{ProcMemUsed} } keys %cpuTable )
			{
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a></td>\n";
				print "\t<td width=\"30%\" bgcolor=\"#FFFFFF\">&nbsp;$cpuTable{$reportnode}{ProcMemUsed} %</td>\n";
				$cpuTable{$reportnode}{ProcMemUsed} =~ /(^\d+)/;
				printCellNoWrap("<img height=\"12\" width=\"$1\" src=\"$NMIS::config{'<url_base>'}/images/bar.png\">&nbsp;","#FFFFFF");
				rowEnd;
				# loop control
				last if --$i == 0;
		}
	 	tableEnd;

		# top10 table - IOMemUsed
		# only for routers

	 	cssTableStart("white");
	 	cssPrintCell('grey', 'Top 10 Nodes by % IO Memory Used (Routers only)', 3);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("IO MEM USED","#FFFFFF",2);
		 	rowEnd;
			my $i=10;
			foreach $reportnode ( sort { $cpuTable{$b}{IOMemUsed} <=> $cpuTable{$a}{IOMemUsed} } keys %cpuTable )
			{
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a></td>\n";
				print "\t<td width=\"30%\" bgcolor=\"#FFFFFF\">&nbsp;$cpuTable{$reportnode}{IOMemUsed} %</td>\n";
				$cpuTable{$reportnode}{IOMemUsed} =~ /(^\d+)/;
				printCellNoWrap("<img height=\"12\" width=\"$1\" src=\"$NMIS::config{'<url_base>'}/images/bar.png\">&nbsp;","#FFFFFF");
				rowEnd;
				# loop control
				last if --$i == 0;
		}
	 	tableEnd;

		# top10 table - Interfaces by Percent Utilization
		# inputUtil, outputUtil, totalUtil
	 	cssTableStart("white");
		cssPrintCell('grey', 'Top 10 Interfaces by Percent Utilization', 6);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF",1);
		 	printHeadCell("INTERFACE","#FFFFFF",1);
		 	printHeadCell("RECEIVE","#FFFFFF",2);
		 	printHeadCell("TRANSMIT","#FFFFFF",2);
		 	rowEnd;
			my $i=10;
			foreach my $reportlink ( sort { $linkTable{$b}{totalUtil} <=> $linkTable{$a}{totalUtil}
										||
						$linkTable{$b}{node} cmp $linkTable{$a}{node}
						 } keys %linkTable )
			{
				last if $linkTable{$reportlink}{inputUtil} and $linkTable{$reportlink}{outputUtil} == 0;
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$linkTable{$reportlink}{node}}{group})}; 
				my $reportnode = $linkTable{$reportlink}{node} ;
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$linkTable{$reportlink}{node}\">$linkTable{$reportlink}{node}</a></td>\n";
				printCellNoWrap("$linkTable{$reportlink}{ifDescr} . $linkTable{$reportlink}{Description}","#FFFFFF");
				printCellNoWrap("$linkTable{$reportlink}{inputUtil} %","#FFFFFF");
				$linkTable{$reportlink}{inputUtil} =~ /(^\d+)/;
				printCellNoWrap("<img height=\"12\" width=\"$1\" src=\"$NMIS::config{'<url_base>'}/images/bar.png\">&nbsp;","#FFFFFF");
				printCellNoWrap("$linkTable{$reportlink}{outputUtil} %","#FFFFFF");
				$linkTable{$reportlink}{outputUtil} =~ /(^\d+)/;
				printCellNoWrap("<img height=\"12\" width=\"$1\" src=\"$NMIS::config{'<url_base>'}/images/bar.png\">&nbsp;","#FFFFFF");
				rowEnd;
				# loop control
				last if --$i == 0;
			}
	 	tableEnd;

		# top10 table - Interfaces by Traffic
		# inputBits, outputBits, totalBits
	 	cssTableStart("white");
	 	cssPrintCell('grey', 'Top 10 Interfaces by Traffic', 4);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("INTERFACE","#FFFFFF");
		 	printHeadCell("RECEIVE","#FFFFFF");
		 	printHeadCell("TRANSMIT","#FFFFFF");
		 	rowEnd;
			my $i=10;
			foreach my $reportlink ( sort { $linkTable{$b}{totalBits} <=> $linkTable{$a}{totalBits} 
										||
						$linkTable{$b}{node} cmp $linkTable{$a}{node} 
						 } keys %linkTable )
			{
				last if $linkTable{$reportlink}{inputBits} and $linkTable{$reportlink}{outputBits} == 0; 
				my $reportnode = $linkTable{$reportlink}{node} ;
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$linkTable{$reportlink}{node}\">$linkTable{$reportlink}{node}</a></td>\n";
				printCellNoWrap("$linkTable{$reportlink}{ifDescr} . $linkTable{$reportlink}{Description}","#FFFFFF");
				printBits($linkTable{$reportlink}{inputBits});
				printBits($linkTable{$reportlink}{outputBits});
				rowEnd;
				# loop control
				last if --$i == 0;

				sub printBits {
					$_ = shift;
					if ( $_ eq "NaN" ) { printCellNoWrap( "$_","#FFFFFF"); }
					elsif ( $_ > 1000000000 ) { $_ /= 1000000000; /(\d+\.\d\d)/; printCellNoWrap("$1 Gbps","#FFFFFF"); }
					elsif ( $_ > 1000000 ) { $_ /= 1000000; /(\d+\.\d\d)/; printCellNoWrap("$1 Mbps","#FFFFFF"); }
					elsif ( $_ > 1000 ) { $_ /= 1000; /(\d+\.\d\d)/; printCellNoWrap("$1 Kbps","#FFFFFF"); }
					else { /(\d+\.\d\d)/; printCellNoWrap("$1 bps","#FFFFFF"); }
				}
			}
	 	tableEnd;

		# top10 table - PVC fecns and becns
		# ReceivedBECNs, ReceivedFECNs
	 	cssTableStart("white");
	 	cssPrintCell('grey', "Top 10 PVC BECN's and FECN's", 4);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("PVC","#FFFFFF");
		 	printHeadCell("RECEIVE BECNS","#FFFFFF");
		 	printHeadCell("RECEIVE FECNS","#FFFFFF");
		 	rowEnd;
			my $i=10;
			foreach my $reportlink ( sort { $pvcTable{$b}{totalECNS} <=> $pvcTable{$a}{totalECNS} 
										||
						$pvcTable{$b}{node} cmp $pvcTable{$a}{node} 
						 } keys %pvcTable )
			{
				last if $pvcTable{$reportlink}{totalECNS} == 0;	# early exit if rest are zero.
				my $reportnode = $pvcTable{$reportlink}{node} ;
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$pvcTable{$reportlink}{node}\">$pvcTable{$reportlink}{node}</a></td>\n";
				printCellNoWrap("$pvcTable{$reportlink}{pvc}","#FFFFFF");
				printCellNoWrap("$pvcTable{$reportlink}{ReceivedBECNs}","#FFFFFF");
				printCellNoWrap("$pvcTable{$reportlink}{ReceivedFECNs}","#FFFFFF");
				rowEnd;
				# loop control
				last if --$i == 0;
			}
	 	tableEnd;


		# top10 table - Errors and Discards
		# ifInUcastPkts, ifInNUcastPkts, ifInDiscards, ifInErrors, ifOutUcastPkts, ifOutNUcastPkts, ifOutDiscards, ifOutErrors
	 	cssTableStart("white");
	 	cssPrintCell('grey', 'Top 10 Errors and Discards', 6);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("INTERFACE","#FFFFFF");
		 	printHeadCell("RECEIVE ERRORS","#FFFFFF");
		 	printHeadCell("RECEIVE DISCARDS","#FFFFFF");
		 	printHeadCell("TRANSMIT ERRORS","#FFFFFF");
		 	printHeadCell("TRANSMIT DISCARDS","#FFFFFF");
		 	rowEnd;
			my $i=10;
			foreach my $reportlink ( sort { $pktsTable{$b}{totalDiscardsErrors} <=> $pktsTable{$a}{totalDiscardsErrors} 
										||
						$pktsTable{$b}{node} cmp $pktsTable{$a}{node} 
						 } keys %pktsTable )
			{
				last if $pktsTable{$reportlink}{totalDiscardsErrors} == 0;	# early exit if rest are zero.
				my $reportnode = $pktsTable{$reportlink}{node} ;
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$pktsTable{$reportlink}{node}\">$pktsTable{$reportlink}{node}</a></td>\n";
				printCell("$pktsTable{$reportlink}{ifDescr} $pktsTable{$reportlink}{Description}","#FFFFFF");
				printCellNoWrap("$pktsTable{$reportlink}{ifInErrors}","#FFFFFF");
				printCellNoWrap("$pktsTable{$reportlink}{ifInDiscards}","#FFFFFF");
				printCellNoWrap("$pktsTable{$reportlink}{ifOutErrors}","#FFFFFF");
				printCellNoWrap("$pktsTable{$reportlink}{ifOutDiscards}","#FFFFFF");
				rowEnd;
				# loop control
				last if --$i == 0;
			}
	 	tableEnd;

		#  table - Down Interfaces - sorts by modified ifLastChangeTime
	 	cssTableStart("white");
	 	cssPrintCell('grey', 'Down Interfaces', 3);
		 	rowStart;
			printHeadCell("NODE","#FFFFFF");
		 	printHeadCell("INTERFACE","#FFFFFF");
		 	printHeadCell("LAST CHANGE","#FFFFFF");
		 	rowEnd;

			foreach my $reportlink ( reverse sort { $downTable{$b}{ifLastChangeTime} <=> $downTable{$a}{ifLastChangeTime}
		 										||
						$downTable{$b}{node} cmp $downTable{$a}{node} 
						 } keys %downTable )
			{
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				my $reportnode = $downTable{$reportlink}{node} ;
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				print "\t<td width=\"25%\">&nbsp;<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$downTable{$reportlink}{node}\">$downTable{$reportlink}{node}</a></td>\n";
				printCellNoWrap("$downTable{$reportlink}{ifDescr} . $downTable{$reportlink}{Description}","#FFFFFF");
				printCellNoWrap("$downTable{$reportlink}{ifLastChange}","#FFFFFF");
				rowEnd;
			}
	 	tableEnd;

		# finish the page.
		cellEnd;
	 	rowEnd;
	 	tableEnd;


	} # report eq top10

	elsif ( $report eq "outage" ) {
		my $index;
		my %logreport;
		my @logline;
		my $outageLength;
		my $outageColor;
		my $outageDetails;
		my $outageType;
		my $logfile;
		my @spacesplit;
		my $i = 0;
		my $timelog;
		my $sec;
	    my $min;
	    my $hour;
	    my $mday;
	    my $mon;
	    my $year;
	    my $wday;
	    my $yday;
	    my $isdst;

		
		
		# set the length if wanted...
		my $count;
		
		if ( $length eq "month" ) { $count=30}
		elsif ( $length eq "week" ) {$count=7}
		else {$count = 1}


		my %eventfile;
		my $dir = $NMIS::config{'<nmis_logs>'};
		# create a list of logfiles...
		opendir (DIR, "$dir");
		my @dirlist = readdir DIR;
		closedir DIR;
		
		if ($debug) { print "\tFound $#dirlist entries\n"; }
		
		foreach my $dir (@dirlist) {
			# grab file names that match the desired report type.
			# add back directory
			$dir = $NMIS::config{'<nmis_logs>'} . '/' . $dir ;
			if ( $dir =~ /^$NMIS::config{event_log}/ ) {
				$eventfile{$dir} = $dir;;
			}
		}
		# only get $count days worth of eventlog
		# init the date check variable
		($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,)=localtime;
		$timelog = time() - ($count*24*60*60);            # get the epoch time for $count days ago
	
		foreach $logfile ( sort keys %eventfile ) {
			if ( $logfile =~ /\.gz$/ ) {
				$logfile = "gzip -dc $logfile |";
			}
		 	# Open the file and store in table
			#open (DATA, $logfile)
			sysopen(DATA, "$logfile", O_RDONLY) or warn returnTime." typeReports, Cannot open the file $logfile. $!\n";
			flock(DATA, LOCK_SH) or warn "can't lock filename: $!";
			# find the line with the entry in and store in the array
			while (<DATA>) {
				chomp;
				my ( $time, $node, $event, $eventlevel, $details ) = split /,/, $_;
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$node}{group})}; 
				
				# event log time is already in epoch time
				if ($time < $timelog ) {last;}           # nothing to do unless logtime is less than $count days ago.

			  	if ($event =~ /Node Up/i and $level eq 'node') {
					$logreport{$i}{time} = $time;
					$logreport{$i}{node} = $node;
					$logreport{$i}{outageType} = "Node Outage";

					# 'Time=00:00:34 secs change=512'
					$details =~ m/Time=(.*?) secs(?:\s+(change=.*))?/i;

					$logreport{$i}{outageLength} = $1;
					$logreport{$i}{outage} = $2;

				}
			  	elsif ($event =~ /Interface Up/i and $level eq 'interface') {
					$logreport{$i}{time} = $time;
					$logreport{$i}{node} = $node;
					$logreport{$i}{outageType} = "Interface Outage";

					# 'interface=ifDescr description=some text Time=00:00:4 secs'
					$details =~ m/(interface=.*?)\s+Time=(.*?) secs/i;

					$logreport{$i}{details} = $1;
					$logreport{$i}{outageLength} = $2;
				}
				$i++;
			}
			close (DATA) or warn "can't close filename: $!";
		} # end of file list
		
		# if debug, print all
		#if ( $debug eq "true" ) {
		#	print Dumper(\%logreport);
		#}


		&typeOutage($NMIS::config{nmis_host});
		$header = "";

		if ( $NMIS::config{master_report} eq "true" ) {
			foreach my $name (keys %NMIS::slaveTable) {
				%logreport = slaveConnect(host => $name,type => 'send',func => 'report_outagetable',par1 => $length,par2 => $level);
				&typeOutage($name);
			}
		}

		sub typeOutage {
			my $server = shift;

   			cssPrintHeadRow( "$header Outage Report server $NMIS::config{nmis_host} $length @ $stamp", 'grey2','1');

		 	rowStart;
		 	cellStart("#FFFFFF",20);

		 	cssTableStart("white");

			rowStart;
			printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;level=$level&amp;length=$length&amp;sort=time\">Time</a>","#FFFFFF");
			printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;level=$level&amp;length=$length&amp;sort=node\">Node</a>","#FFFFFF");
			printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;level=$level&amp;length=$length&amp;sort=type\">Outage Type</a>","#FFFFFF");
			printHeadCell("<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=$type&amp;report=$report&amp;level=$level&amp;length=$length&amp;sort=length\">Outage Time</a>","#FFFFFF");
			printHeadCell("Interface","#FFFFFF");
			printHeadCell("Planned Outage","#FFFFFF");
			rowEnd;

			if ( $sort eq "time" or $sort eq "" ) {
				foreach $index ( sort
					{
						$logreport{$a}{time} <=> $logreport{$b}{time} ||
						$logreport{$a}{node} cmp $logreport{$b}{node}
					}
					keys %logreport )
				{
					$outageColor = colorTime($logreport{$index}{outageLength});
					my $reportnode = $logreport{$index}{node} ;
					my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
					if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
						$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
					}
					if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
						$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
							"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
					}
					rowStart;
					printCellNoWrap(returnDateStamp($logreport{$index}{time}),$outageColor);
					printCellNoWrap("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$logreport{$index}{node}\">$logreport{$index}{node}</a>",$outageColor);
					printCellNoWrap($logreport{$index}{outageType},$outageColor);
					print "<td bgcolor=$outageColor align=right>$logreport{$index}{outageLength}</td>";
					if ( $logreport{$index}{details} ) { printCellNoWrap($logreport{$index}{details},$outageColor) } else { printCellNoWrap("") }
					if ( $logreport{$index}{outage} ) { printCellNoWrap($logreport{$index}{outage},$outageColor,1,"center") } else { printCellNoWrap("") }
					rowEnd;
				} # End for loop.
			}
			elsif ( $sort eq "node" ) {
				foreach $index ( sort
					{
						$logreport{$a}{node} cmp $logreport{$b}{node} ||
						$logreport{$a}{time} <=> $logreport{$b}{time}
					}
					keys %logreport )
				{
					$outageColor = colorTime($logreport{$index}{outageLength});
					my $reportnode = $logreport{$index}{node} ;
					my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
					if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
						$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
					}
					if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
						$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
							"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
					}
					rowStart;
					printCellNoWrap(returnDateStamp($logreport{$index}{time}),$outageColor);
					printCellNoWrap("<a href=\"$slave_ref&amp;type=summary&amp;node=$logreport{$index}{node}\">$logreport{$index}{node}</a>",$outageColor);
					printCellNoWrap($logreport{$index}{outageType},$outageColor);
					print "<td bgcolor=$outageColor align=right>$logreport{$index}{outageLength}</td>";
					if ( $logreport{$index}{details} ) { printCellNoWrap($logreport{$index}{details},$outageColor) } else { printCellNoWrap("") }
					if ( $logreport{$index}{outage} ) { printCellNoWrap($logreport{$index}{outage},$outageColor,1,"center") } else { printCellNoWrap("") }
					rowEnd;
				} # End for loop.
			}
			elsif ( $sort eq "type" ) {
				foreach $index ( sort
					{
						$logreport{$a}{outageType} cmp $logreport{$b}{outageType} ||
						$logreport{$a}{node} <=> $logreport{$b}{node}
					}
					keys %logreport )
				{
					$outageColor = colorTime($logreport{$index}{outageLength});
					my $reportnode = $logreport{$index}{node} ;
					my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
					if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
						$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
					}
					if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
						$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
							"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
					}
					rowStart;
					printCellNoWrap(returnDateStamp($logreport{$index}{time}),$outageColor);
					printCellNoWrap("<a href=\"$slave_ref&amp;type=summary&amp;node=$logreport{$index}{node}\">$logreport{$index}{node}</a>",$outageColor);
					printCellNoWrap($logreport{$index}{outageType},$outageColor);
					print "<td bgcolor=$outageColor align=right>$logreport{$index}{outageLength}</td>";
					if ( $logreport{$index}{details} ) { printCellNoWrap($logreport{$index}{details},$outageColor) } else { printCellNoWrap("") }
					if ( $logreport{$index}{outage} ) { printCellNoWrap($logreport{$index}{outage},$outageColor,1,"center") } else { printCellNoWrap("") }
					rowEnd;
				} # End for loop.
			}
			elsif ( $sort eq "length" ) {
				foreach $index ( sort
					{
						$logreport{$b}{outageLength} cmp $logreport{$a}{outageLength} ||
						$logreport{$a}{node} <=> $logreport{$b}{node}
					}
					keys %logreport )
				{
					$outageColor = colorTime($logreport{$index}{outageLength});
					my $reportnode = $logreport{$index}{node} ;
					my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
					if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
						$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
					}
					if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
						$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
							"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
					}
					rowStart;
					printCellNoWrap(returnDateStamp($logreport{$index}{time}),$outageColor);
					printCellNoWrap("<a href=\"$slave_ref&amp;type=summary&amp;node=$logreport{$index}{node}\">$logreport{$index}{node}</a>",$outageColor);
					printCellNoWrap($logreport{$index}{outageType},$outageColor);
					print "<td bgcolor=$outageColor align=right>$logreport{$index}{outageLength}</td>";
					if ( $logreport{$index}{details} ) { printCellNoWrap($logreport{$index}{details},$outageColor) } else { printCellNoWrap("") }
					if ( $logreport{$index}{outage} ) { printCellNoWrap($logreport{$index}{outage},$outageColor,1,"center") } else { printCellNoWrap("") }
					rowEnd;
				} # End for loop.
			}

			tableEnd;
	 		cellEnd;
	 		rowEnd;
		} # end typeoutage
	} # end of report = outage
	elsif ( $report eq "response" ) {

		if ( $length eq "month" ) {
			$reportLength = "-1 months";
			$datestamp_start = returnDateStamp(convertTime("1","months"));
 			cssPrintHeadRow( "$header 1 Month Dynamic Reponse Time Summary from $datestamp_start to $datestamp_end", 'grey','1');
		}
		elsif ( $length eq "day" ) {
			$reportLength = "-1 days";
			$datestamp_start = returnDateStamp(convertTime("1","days"));
 			cssPrintHeadRow( "$header 1 Day Dynamic Reponse Time Summary from $datestamp_start to $datestamp_end", 'grey','1');
		}
		elsif ( $length eq "week" ) {
			$reportLength = "-1 weeks";
			$datestamp_start = returnDateStamp(convertTime("1","weeks"));
 			cssPrintHeadRow( "$header 1 Week Dynamic Reponse Time Summary from $datestamp_start to $datestamp_end", 'grey','1');
		}
		else {
			$reportLength = "-6 hours";
			$datestamp_start = returnDateStamp(convertTime("6","hours"));
  			cssPrintHeadRow( "$header 6 Hours Dynamic Reponse Time Summary from $datestamp_start to $datestamp_end", 'grey','1');
		}

		# Get each of the nodes info in a HASH for playing with
		if ( $NMIS::config{master_report} eq "true" ) {
			foreach my $name (keys %NMIS::slaveTable) {
				%reportTable = (%reportTable,slaveConnect(host => $name,type => 'send',func => 'report_reporttable',par1 => $reportLength,par2 => time));
			}
		}
		# Get each of the nodes info in a HASH for playing with
		foreach $reportnode (sort(keys(%NMIS::nodeTable))) {
			if ((exists $NMIS::nodeTable{$reportnode}{slave} or exists $NMIS::nodeTable{$reportnode}{slave2})
					and $NMIS::config{master_report} ne "true" ) {
				next;
			}
			if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
			## AS 16 Mar 02, implementing David Gay's requirement for deactiving
			# a node, ie keep a node in nodes.csv but no collection done.
			if ( $NMIS::nodeTable{$reportnode}{active} ne "false" ) {
				if ( not exists $NMIS::nodeTable{$reportnode}{slave} and not exists $NMIS::nodeTable{$reportnode}{slave2} ) {
					loadSystemFile($reportnode);
	    			%reportTable = (%reportTable,summaryStats(node => $reportnode,type => "health",start => $reportLength,end => time,key => $reportnode));
				}
				$reportTable{$reportnode}{devicetype} = $NMIS::nodeTable{$reportnode}{devicetype};
				$reportTable{$reportnode}{node} = $reportnode;
			}
		}

		# if debug, print all
		if ( $debug eq "true" ) {
			print Dumper(\%reportTable);
		}

	 	rowStart;
	 	cellStart("#FFFFFF",20);

	 	cssTableStart("white");
	 	printHeadRow("Average Response Time for All Devices","#FFFFFF",10);
		 	rowStart;
			printHeadCell("Node","#FFFFFF");
		 	printHeadCell("Node Type","#FFFFFF");
		 	printHeadCell("Response Time","#FFFFFF");
		 	rowEnd;
			# drop the NaN's like this: @sorted = sort { $a <=> $b } grep { $_ == $_ } @unsorted 
			foreach $reportnode ( 
				sort { $reportTable{$b}{response} <=> $reportTable{$a}{response} }
				grep { $reportTable{$_}{response} == $reportTable{$_}{response} } 
				keys %reportTable 
				) {
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				rowStart;
				printCellNoWrap("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a>");
				printCellNoWrap("$reportTable{$reportnode}{devicetype}");
				$cellColor = colorResponseTime($reportTable{$reportnode}{response});
				printCellRight("$reportTable{$reportnode}{response}",$cellColor);
				rowEnd;
			}
	 	tableEnd;

	 	cellEnd;
	 	rowEnd;
	} # report eq response
	### Node Availability (Reachable)
	elsif ( $report eq "avail" ) {

		if ( $length eq "month" ) {
			$reportLength = "-1 months";
			$datestamp_start = returnDateStamp(convertTime("1","months"));
			$header .= "Monthly Availability Metric from $datestamp_start to $datestamp_end";
		}
		elsif ( $length eq "day" ) {
			$reportLength = "-1 days";
			$datestamp_start = returnDateStamp(convertTime("1","days"));
			$header .= "Daily Availability Metric from $datestamp_start to $datestamp_end";
		}
		else {
			$reportLength = "-1 weeks";
			$datestamp_start = returnDateStamp(convertTime("1","weeks"));
			$header .= "Weekly Availability Metric from $datestamp_start to $datestamp_end";
		}
 		cssPrintHeadRow( $header, 'grey','1');

		if ( $NMIS::config{master_report} eq "true" ) {
			foreach my $name (keys %NMIS::slaveTable) {
				%reportTable = (%reportTable,slaveConnect(host => $name,type => 'send',func => 'report_reporttable',par1 => $reportLength,par2 => time));
			}
		}
		# Get each of the nodes info in a HASH for playing with
		foreach $reportnode (sort keys %NMIS::nodeTable ) {
			if ((exists $NMIS::nodeTable{$reportnode}{slave} or exists $NMIS::nodeTable{$reportnode}{slave2})
				and $NMIS::config{master_report} ne "true" ) {
				next;
			}
			if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
			## AS 16 Mar 02, implementing David Gay's requirement for deactiving
			# a node, ie keep a node in nodes.csv but no collection done.
			if ( $NMIS::nodeTable{$reportnode}{active} ne "false" ) {
				loadSystemFile($reportnode);
				# get reachable, available, health, response
				if ( not exists $NMIS::nodeTable{$reportnode}{slave} and not exists $NMIS::nodeTable{$reportnode}{slave2} ) {
					loadSystemFile($reportnode);
	    			%reportTable = (%reportTable,summaryStats(node => $reportnode,type => "health",start => $reportLength,end => time,key => $reportnode));
				}
				$reportTable{$reportnode}{devicetype} = $NMIS::nodeTable{$reportnode}{devicetype};
				$reportTable{$reportnode}{node} = $reportnode;
			}
		}

		# if debug, print all
		if ( $debug eq "true" ) {
			print Dumper(\%reportTable);
		}

	 	rowStart;
	 	cellStart("#FFFFFF",20);

	 	cssTableStart("white");
	 	printHeadRow("% Availability ( Reachability) for all Devices","#FFFFFF",10);
		 	rowStart;
			printHeadCell("Node","#FFFFFF");
		 	printHeadCell("Node Type","#FFFFFF");
		 	printHeadCell("% Availability","#FFFFFF");
		 	rowEnd;
			foreach $reportnode (
				reverse sort { $reportTable{$b}{reachable} <=> $reportTable{$a}{reachable}
				|| $reportTable{$b}{node} cmp $reportTable{$a}{node} }
				grep { $reportTable{$_}{reachable} == $reportTable{$_}{reachable} }
				keys %reportTable
				) {
				if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$reportnode}{group})}; 
				my $slave_ref = "http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf";
				if ( exists $NMIS::nodeTable{$reportnode}{slave} ) {
					$slave_ref = "http://$NMIS::nodeTable{$reportnode}{slave}/cgi-nmis/nmiscgi.pl";
				}
				if ( exists $NMIS::nodeTable{$reportnode}{slave2}) {
					$slave_ref = "http://$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Host}/cgi-nmis/nmiscgi.pl".
						"?file=$NMIS::slaveTable{$NMIS::nodeTable{$reportnode}{slave2}}{Conf}";
				}
				rowStart;
				printCellNoWrap("<a href=\"$slave_ref&amp;type=summary&amp;node=$reportnode\">$reportnode</a>");
				printCellNoWrap("$reportTable{$reportnode}{devicetype}");
				if ( $reportTable{$reportnode}{reachable} >=99.9 )  { $cellColor = "#00FF00"; }
				elsif ( $reportTable{$reportnode}{reachable} >= 99 )  { $cellColor = "#FF9900"; }
				else { $cellColor = "#FF0000"; }
				printCellRight("$reportTable{$reportnode}{reachable}",$cellColor);
				rowEnd;
			}
	 	tableEnd;
	 	cellEnd;
	 	rowEnd;
	} # report eq available
	elsif ( $report eq "port" ) {
		my $intHash;
		my %portCount;
		my $countHash;
		my $countHead;
		my $floor;
		my $print;
		my $percentage;
		my $color;

		loadInterfaceInfo;
		# slave
		if ( $NMIS::config{master_report} eq "true" ) {
			foreach my $name (keys %NMIS::slaveTable) {
				%NMIS::interfaceInfo = (%NMIS::interfaceInfo,slaveConnect(host => $name,type => 'send',func => 'loadInterfaceInfo'));
			}
		}

		# Get each of the nodes info in a HASH for playing with
		foreach $intHash (sort(keys(%NMIS::interfaceInfo))) {
			if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$NMIS::interfaceInfo{intHash}{node}}{group})}; 
			if ( $NMIS::interfaceInfo{$intHash}{ifDescr} !~ /nu|atm|lec|vlan|sc|sl/i  ) {

				++$portCount{Total}{totalportcount};
				++$portCount{Total}{"admin-$NMIS::interfaceInfo{$intHash}{ifAdminStatus}"};
				++$portCount{Total}{"oper-$NMIS::interfaceInfo{$intHash}{ifOperStatus}"};
				++$portCount{Total}{"speed-$NMIS::interfaceInfo{$intHash}{ifSpeed}"};
				++$portCount{Total}{"duplex-$NMIS::interfaceInfo{$intHash}{portDuplex}"};
				++$portCount{Total}{'collect'} if $NMIS::interfaceInfo{$intHash}{collect} eq 'true';
			}
		}
 		cssPrintHeadRow( "$header Port Count Summary Report @ $datestamp_end", 'grey','1');

	 	rowStart;
	 	cellStart("#FFFFFF",20);
	 	cssTableStart("white");

       	cssPrintCell('grey', 'Summary Port Counts', 3);
       	printRow("The port count summary is indicative.  Consideration should be given to weight the port counts<BR>according to day of week port types etc.","#FFFF00",3);

		$intHash = "Total";
       	printHeadRow("$intHash Port Totals","#FFFFFF",3);

		rowStart;
		printCellNoWrap("Port Count");
		printCellNoWrap("$portCount{$intHash}{totalportcount}","#FFFFFF",1,"right");
		printCellNoWrap("");
		rowEnd;

		$color = "#FFFFFF";
		rowStart;
		printCellNoWrap("Admin Up Port Count");
		printCellNoWrap("$portCount{$intHash}{'admin-up'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'admin-up'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Admin Down Port Count");
		printCellNoWrap("$portCount{$intHash}{'admin-down'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'admin-down'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Oper Up Port Count");
		printCellNoWrap("$portCount{$intHash}{'oper-ok'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-ok'} / $portCount{$intHash}{totalportcount} * 100);
		$color = colorPort($percentage);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Oper Down Port Count");
		printCellNoWrap("$portCount{$intHash}{'oper-other'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-other'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Oper Minor Fault Port Count");
		printCellNoWrap("$portCount{$intHash}{'oper-minorFault'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-minorFault'} / $portCount{$intHash}{totalportcount} * 100);
		if ( $portCount{$intHash}{'oper-minorFault'} > 0 ) { $color = "#FFFF00"; } else { $color = "#00FF00"; }
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		$color = "#FFFFFF";
		rowStart;
		printCellNoWrap("Full Duplex Port Count");
		printCellNoWrap("$portCount{$intHash}{'duplex-full'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'duplex-full'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Half Duplex Port Count");
		printCellNoWrap("$portCount{$intHash}{'duplex-half'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'duplex-half'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("10 megabit Port Count");
		printCellNoWrap("$portCount{$intHash}{'speed-10000000'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-10000000'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("100 megabit Port Count");
		printCellNoWrap("$portCount{$intHash}{'speed-100000000'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-100000000'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("1 gigabit Port Count");
		printCellNoWrap("$portCount{$intHash}{'speed-1000000000'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-1000000000'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;
		printRow;

                rowStart;
                printCellNoWrap("Collect Port Count");
                printCellNoWrap("$portCount{$intHash}{'collect'}","#FFFFFF",1,"right");
                $percentage = sprintf("%.0f",$portCount{$intHash}{'collect'} / $portCount{$intHash}{totalportcount} * 100);
                printCellNoWrap("$percentage%",$color,1,"right");
                rowEnd;
                printRow;

		# Do the summaries for everthing but Total and Level summaries
		foreach $intHash ( keys %portCount ) {
			if ( $intHash =~ /Level|Total/ ) { $print = "false"; }
			else { $print = "true"; }

			if ( $print eq "true" ) {
				printHeadRow("$intHash Port Totals","#FFFFFF",3);

				rowStart;
				printCellNoWrap("Port Count");
				printCellNoWrap("$portCount{$intHash}{totalportcount}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{totalportcount} / $portCount{Total}{totalportcount} * 100);
				$color = colorLowGood($percentage);
				printCellNoWrap("$percentage% of Total",$color,1,"right");
				rowEnd;

				$color = "#FFFFFF";
				rowStart;
				printCellNoWrap("Admin Up Port Count");
				printCellNoWrap("$portCount{$intHash}{'admin-up'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'admin-up'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Admin Down Port Count");
				printCellNoWrap("$portCount{$intHash}{'admin-down'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'admin-down'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Oper Up Port Count");
				printCellNoWrap("$portCount{$intHash}{'oper-ok'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-ok'} / $portCount{$intHash}{totalportcount} * 100);
				$color = colorPort($percentage);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Oper Down Port Count");
				printCellNoWrap("$portCount{$intHash}{'oper-other'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-other'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Oper Minor Fault Port Count");
				printCellNoWrap("$portCount{$intHash}{'oper-minorFault'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-minorFault'} / $portCount{$intHash}{totalportcount} * 100);
				if ( $portCount{$intHash}{'oper-minorFault'} > 0 ) { $color = "#FFFF00"; } else { $color = "#00FF00"; }
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				$color = "#FFFFFF";
				rowStart;
				printCellNoWrap("Full Duplex Port Count");
				printCellNoWrap("$portCount{$intHash}{'duplex-full'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'duplex-full'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Half Duplex Port Count");
				printCellNoWrap("$portCount{$intHash}{'duplex-half'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'duplex-half'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("10 megabit Port Count");
				printCellNoWrap("$portCount{$intHash}{'speed-10000000'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-10000000'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("100 megabit Port Count");
				printCellNoWrap("$portCount{$intHash}{'speed-100000000'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-100000000'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("1 gigabit Port Count");
				printCellNoWrap("$portCount{$intHash}{'speed-1000000000'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-1000000000'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;
				printRow;
			}
		}

	 	tableEnd;
		paragraph;
	 	cellEnd;
	 	rowEnd;
	}
	elsif ( $report eq "counts" ) {
		my $intHash;
		my %portCount;
		my $countHash;
		my $countHead;
		my $floor;
		my $print;
		my $percentage;
		my $color;

		loadInterfaceInfo;
		# slave
		if ( $NMIS::config{master_report} eq "true" ) {
			foreach my $name (keys %NMIS::slaveTable) {
				%NMIS::interfaceInfo = (%NMIS::interfaceInfo,slaveConnect(host => $name,type => 'send',func => 'loadInterfaceInfo'));
			}
		}

		# Get each of the nodes info in a HASH for playing with
		foreach $intHash (sort(keys(%NMIS::interfaceInfo))) {
			if (defined $user) {next unless $user->InGroup($NMIS::nodeTable{$NMIS::interfaceInfo{$intHash}{node}}{group})}; 
			if ( $NMIS::interfaceInfo{$intHash}{ifDescr} !~ /nu|atm|lec|vlan|sc|sl/i  ) {
				$countHash = "Switch";
				$floor = "$NMIS::interfaceInfo{$intHash}{node}";
				++$portCount{Total}{totalportcount};
				++$portCount{Total}{"admin-$NMIS::interfaceInfo{$intHash}{ifAdminStatus}"};
				++$portCount{Total}{"oper-$NMIS::interfaceInfo{$intHash}{ifOperStatus}"};
				++$portCount{Total}{"speed-$NMIS::interfaceInfo{$intHash}{ifSpeed}"};
				++$portCount{Total}{"duplex-$NMIS::interfaceInfo{$intHash}{portDuplex}"};
				++$portCount{$countHash}{totalportcount};
				++$portCount{$countHash}{"admin-$NMIS::interfaceInfo{$intHash}{ifAdminStatus}"};
				++$portCount{$countHash}{"oper-$NMIS::interfaceInfo{$intHash}{ifOperStatus}"};
				++$portCount{$countHash}{"speed-$NMIS::interfaceInfo{$intHash}{ifSpeed}"};
				++$portCount{$countHash}{"duplex-$NMIS::interfaceInfo{$intHash}{portDuplex}"};

				++$portCount{"$countHash $floor"}{totalportcount};
				++$portCount{"$countHash $floor"}{"admin-$NMIS::interfaceInfo{$intHash}{ifAdminStatus}"};
				++$portCount{"$countHash $floor"}{"oper-$NMIS::interfaceInfo{$intHash}{ifOperStatus}"};
				++$portCount{"$countHash $floor"}{"speed-$NMIS::interfaceInfo{$intHash}{ifSpeed}"};
				++$portCount{"$countHash $floor"}{"duplex-$NMIS::interfaceInfo{$intHash}{portDuplex}"};
			}
		}

 		cssPrintHeadRow( "$header Per Device Port Count Summary Report @ $datestamp_end", 'grey','1');

	 	rowStart;
	 	cellStart("#FFFFFF",20);
	 	cssTableStart("white");

       	cssPrintCell('grey', 'Summary of Port Counts', 3);
       	printRow("The port count summary is indicative.  Consideration should be given to weight the port counts<BR>according to day of week port types etc.","#FFFF00",3);

		$intHash = "Total";
       	printHeadRow("$intHash Port Totals","#FFFFFF",3);

		rowStart;
		printCellNoWrap("Port Count");
		printCellNoWrap("$portCount{$intHash}{totalportcount}","#FFFFFF",1,"right");
		printCellNoWrap("");
		rowEnd;

		$color = "#FFFFFF";
		rowStart;
		printCellNoWrap("Admin Up Port Count");
		printCellNoWrap("$portCount{$intHash}{'admin-up'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'admin-up'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Admin Down Port Count");
		printCellNoWrap("$portCount{$intHash}{'admin-down'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'admin-down'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Oper Up Port Count");
		printCellNoWrap("$portCount{$intHash}{'oper-ok'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-ok'} / $portCount{$intHash}{totalportcount} * 100);
		$color = colorPort($percentage);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Oper Down Port Count");
		printCellNoWrap("$portCount{$intHash}{'oper-other'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-other'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Oper Minor Fault Port Count");
		printCellNoWrap("$portCount{$intHash}{'oper-minorFault'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-minorFault'} / $portCount{$intHash}{totalportcount} * 100);
		if ( $portCount{$intHash}{'oper-minorFault'} > 0 ) { $color = "#FFFF00"; } else { $color = "#00FF00"; }
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		$color = "#FFFFFF";
		rowStart;
		printCellNoWrap("Full Duplex Port Count");
		printCellNoWrap("$portCount{$intHash}{'duplex-full'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'duplex-full'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("Half Duplex Port Count");
		printCellNoWrap("$portCount{$intHash}{'duplex-half'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'duplex-half'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("10 megabit Port Count");
		printCellNoWrap("$portCount{$intHash}{'speed-10000000'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-10000000'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("100 megabit Port Count");
		printCellNoWrap("$portCount{$intHash}{'speed-100000000'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-100000000'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;

		rowStart;
		printCellNoWrap("1 gigabit Port Count");
		printCellNoWrap("$portCount{$intHash}{'speed-1000000000'}","#FFFFFF",1,"right");
		$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-1000000000'} / $portCount{$intHash}{totalportcount} * 100);
		printCellNoWrap("$percentage%",$color,1,"right");
		rowEnd;
		printRow;
	 	tableEnd;
		paragraph;

	 	cssTableStart("white");
	 	
		# Do the summaries for Floor Levels summaries
		cssPrintCell('grey', 'Switch Port Counts', 3);
		
		foreach $intHash (sort (keys(%portCount))) {
			if ( $intHash ne "Switch" && $intHash =~ /Switch/ ) {
				$print = "true";
			}
			else {
				$print = "false";
			}
			if ( $print eq "true" ) {
				printRow;
			       	printHeadRow("$intHash Port Totals","#FFFFFF",3);

				rowStart;
				printCellNoWrap("Port Count");
				printCellNoWrap("$portCount{$intHash}{totalportcount}","#FFFFFF",1,"right");
				printCellNoWrap("","#FFFFFF",1,"right");
				rowEnd;

				$color = "#FFFFFF";
				rowStart;
				printCellNoWrap("Admin Up Port Count");
				printCellNoWrap("$portCount{$intHash}{'admin-up'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'admin-up'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Admin Down Port Count");
				printCellNoWrap("$portCount{$intHash}{'admin-down'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'admin-down'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Oper Up Port Count");
				printCellNoWrap("$portCount{$intHash}{'oper-ok'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-ok'} / $portCount{$intHash}{totalportcount} * 100);
				$color = colorPort($percentage);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Oper Down Port Count");
				printCellNoWrap("$portCount{$intHash}{'oper-other'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-other'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Oper Minor Fault Port Count");
				printCellNoWrap("$portCount{$intHash}{'oper-minorFault'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'oper-minorFault'} / $portCount{$intHash}{totalportcount} * 100);
				if ( $portCount{$intHash}{'oper-minorFault'} > 0 ) { $color = "#FFFF00"; } else { $color = "#00FF00"; }
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				$color = "#FFFFFF";
				rowStart;
				printCellNoWrap("Full Duplex Port Count");
				printCellNoWrap("$portCount{$intHash}{'duplex-full'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'duplex-full'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("Half Duplex Port Count");
				printCellNoWrap("$portCount{$intHash}{'duplex-half'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'duplex-half'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("10 megabit Port Count");
				printCellNoWrap("$portCount{$intHash}{'speed-10000000'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-10000000'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("100 megabit Port Count");
				printCellNoWrap("$portCount{$intHash}{'speed-100000000'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-100000000'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;

				rowStart;
				printCellNoWrap("1 gigabit Port Count");
				printCellNoWrap("$portCount{$intHash}{'speed-1000000000'}","#FFFFFF",1,"right");
				$percentage = sprintf("%.0f",$portCount{$intHash}{'speed-1000000000'} / $portCount{$intHash}{totalportcount} * 100);
				printCellNoWrap("$percentage%",$color,1,"right");
				rowEnd;
				printRow;
			}
		}
	 	tableEnd;
	 	cellEnd;
	 	rowEnd;
	}
	else {
		# Dynamically list the directory contents
		if ( $report ne "" ) {

			my ( $index, $type, $span );
	        opendir (DIR, "$NMIS::config{report_root}");
	        my @dirlist = readdir DIR;
	        closedir DIR;

			foreach my $dir (@dirlist) {

				# grab file names that match the desired report type.
				# index by date to allow sorting
				if ( $dir =~ /^$report/ ) {

					if ( $dir =~ m/(\d\d)-(\d\d)-(\d\d\d\d)/ ) {	# capture the date xx-xx-xxxx
						$index = $3."-".$2."-".$1;
					}
					elsif ( $dir =~ m/month-(\d\d)-(\d\d\d\d)/ ) {	# capture the date month-xx-xxxx
						$index = $2."-".$1."-01";
					}
					$reportTable{$index}{dir} = $dir;
					
					# formulate a tidy report name
					$dir =~ s/\.html//;
					if ( $dir =~ m/month-(\d\d)-(\d\d\d\d)$/ ) {		# month-01-2006.html
						$reportTable{$index}{link} = convertMonth($1) . " $2";
					}
					elsif ( $dir =~ m/(?:day|week)-(\d\d)-(\d\d)-(\d\d\d\d)-(\w+)$/ ) {		# day|week-01-01-2006-Sun.html
						$reportTable{$index}{link} = $4 . " $1 " . convertMonth($2) . " $3";
					}
					elsif ( $dir =~ m/(\w+)-(\w+)-(\d\d)-(\d\d)-(\d\d\d\d)-(\w+)$/ ) { 	# <type>-day|week|month-01-01-2006-Mon.html
						$reportTable{$index}{link} = $6 . " $3 " . convertMonth($4) . " $5";

					}
					else {
						$reportTable{$index}{link} = 'error - filename not recogonised';
					}
				}
			}
			# formulate a menu header
			if ( $report !~ m/-/ ) {
				$header .= ucfirst($report).'ly Health Stored Reports';
			}
			else {
				($type, $span ) = split /-/ , $report;
				$header .= ucfirst($span).'ly '.ucfirst($type).' Stored Reports';
			}
			$header =~ s/Dayly/Daily/;
			$header =~ s/Avail/Availability/;
			
			cssPrintHeadRow( $header, 'grey','1');
			rowStart;
			cellStart("#FFFFFF",20);
			cssTableStart("white");

			foreach $index (reverse sort keys %reportTable ) { 
				printHeadRow( "<a href=$NMIS::config{web_report_root}/$reportTable{$index}{dir}>$reportTable{$index}{link}</a></font>");
			}

			tableEnd;
			cellEnd;
			rowEnd;

		} # if report is blank

		# Show a menu of Daily, weekly, monthly if no options
		else {
			my $slaves = $NMIS::config{master_report} eq "true" ? "(slave servers included)" : "";
			print "<tr><td class='grey2'>$header<b>Report Menu $slaves</b>";
			cssTableStart("white");
			print "<tr><td valign='top'>";
			cssTableStart("white");
			rowStart;
			# section header
			cssPrintCell('grey', 'Current Status Reports', 1);
			rowEnd;
			cssPrintRow('Node Details Report', 'menubar', 1 );
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;report=nodedetails\">Node Details Report (HTML)</a> <a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;report=nodedetails&amp;csvfile=asset\">(CSV)</a>");

			cssPrintRow('Network Availability Reports', 'menubar', 1 );
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=avail&amp;length=day\">Daily Availability Report</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=avail&amp;length=week\">Weekly Availability Report</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=avail&amp;length=month\">Monthly Availability Report</a>");

			cssPrintRow( 'Network Top10 Reports', 'menubar', 1 );
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=top10&amp;length=15min\">Current Top10 Report (Last 15 min)</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=top10&amp;length=day\">Daily Top10 Report</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=top10&amp;length=week\">Weekly Top10 Report</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=top10&amp;length=month\">Monthly Top10 Report</a>");

			cssPrintRow( 'Network Health Reports', 'menubar', 1 );
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=health&amp;length=day\">Daily Health Reports</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=health&amp;length=week\">Weekly Health Reports</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=health&amp;length=month\">Monthly Health Reports</a>");

			cssPrintRow( 'Outage Reports', 'menubar', 1 );
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage&amp;length=day&amp;level=node\">Daily Outage Reports by Node</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage&amp;length=week&amp;level=node\">Weekly Outage Reports by Node</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage&amp;length=month&amp;level=node\">Monthly Outage Reports by Node</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage&amp;length=day&amp;level=interface\">Daily Outage Reports by Interface</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage&amp;length=week&amp;level=interface\">Weekly Outage Reports by Interface</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage&amp;length=month&amp;level=interface\">Monthly Outage Reports by Interface</a>");

			cssPrintRow( 'Response Time Reports', 'menubar', 1 );
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=response\">Current Response Time Report (Last 6 Hours)</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=response&amp;length=day\">Daily Response Time Report</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=response&amp;length=week\">Weekly Response Time Report</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=response&amp;length=month\">Monthly Response Time Report</a>");

			cssPrintRow( 'Port Report', 'menubar', 1 );
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=port\">Current Port Count Summary Report</a>");
				cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=counts\">Current Port Count per Device Report</a>");
			tableEnd;
			cellEnd;

			if ($auth->CheckAccess($user,"reporthistory","check")) {
				print "<td valign='top'>";
				cssTableStart("white");
				rowStart;
				cssPrintCell('grey', 'Stored History Reports', 1);
				rowEnd;

				cssPrintRow( 'Network Availability Reports', 'menubar', 1 );
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=avail-day\">Daily Availability Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=avail-week\">Weekly Availability Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=avail-month\">Monthly Availability Stored Reports</a>");

				cssPrintRow( 'Network Top10 Reports', 'menubar', 1 );
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=top10-day\">Daily Top10 Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=top10-week\">Weekly Top10 Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=top10-month\">Monthly Top10 Stored Reports</a>");

				cssPrintRow( 'Network Health Reports', 'menubar', 1 );
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=day\">Daily Health Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=week\">Weekly Health Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=month\">Monthly Health Stored Reports</a>");

				cssPrintRow( 'Outage Reports by Node', 'menubar', 1 );
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage-day\">Daily Outage Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage-week\">Weekly Outage Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=outage-month\">Monthly Outage Stored Reports</a>");

				cssPrintRow( 'Response Time Reports', 'menubar', 1 );
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=response-day\">Daily Response Time Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=response-week\">Weekly Response Time Stored Reports</a>");
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=response-month\">Monthly Response Time Stored Reports</a>");

				cssPrintRow( 'Port Reports', 'menubar', 1 );
					cssPrintRow( "<a href=\"$ENV{SCRIPT_NAME}?file=$conf&amp;type=reports&amp;report=port-day\">Daily Port Count Summary Stored Reports</a>");
				tableEnd;
				cellEnd;
				rowEnd;
			}
			tableEnd;
		cellEnd;
		rowEnd;
		}
	} # else if $report

	tableEnd if !$csvfile;
	pageEnd if !$csvfile;

	#=======================

	sub reportNodeType {
		my $netType = shift;
		my $roleType = shift;
		# Report sorting based on match the first comparison of elements, if the same uses next
		# defined elements.
		if ( $sort eq "node" or $sort eq "" ) {
			foreach $reportnode ( sort { $a cmp $b } keys %reportTable )
			{
				loadSystemFile($reportnode);
				if (	( $reportTable{$reportnode}{net} eq $netType and
					  $reportTable{$reportnode}{role} eq $roleType
					) or
					( $reportTable{$reportnode}{group} eq $netType and
					  $roleType eq ""
					)
				) {
					rowStart;
					printCellNoWrap("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a>");
					printCellNoWrap("$reportTable{$reportnode}{devicetype}");
					printCellNoWrap("$reportTable{$reportnode}{role}");
					printCellNoWrap("$reportTable{$reportnode}{net}");
					$cellColor = colorHighGood($reportTable{$reportnode}{reachable});
					printCellRight("$reportTable{$reportnode}{reachable}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{available});
					printCellRight("$reportTable{$reportnode}{available}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{health});
					printCellRight("$reportTable{$reportnode}{health}",$cellColor);
					$cellColor = colorResponseTime($reportTable{$reportnode}{response});
					printCellRight("$reportTable{$reportnode}{response}",$cellColor);
					rowEnd;
				}
			}
		} # end sort eq reachability
		elsif ( $sort eq "reachability" ) {
			foreach $reportnode ( sort
				{
					$reportTable{$a}{reachable} <=> $reportTable{$b}{reachable} ||
					$reportTable{$a}{health} <=> $reportTable{$b}{health} ||
					$a cmp $b
				}
				keys %reportTable )
			{
				loadSystemFile($reportnode);
				if (	( $reportTable{$reportnode}{net} eq $netType and
					  $reportTable{$reportnode}{role} eq $roleType
					) or
					( $reportTable{$reportnode}{group} eq $netType and
					  $roleType eq ""
					)
				) {
					rowStart;
					printCellNoWrap("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a>");
					printCellNoWrap("$reportTable{$reportnode}{devicetype}");
					printCellNoWrap("$reportTable{$reportnode}{role}");
					printCellNoWrap("$reportTable{$reportnode}{net}");
					$cellColor = colorHighGood($reportTable{$reportnode}{reachable});
					printCellRight("$reportTable{$reportnode}{reachable}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{available});
					printCellRight("$reportTable{$reportnode}{available}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{health});
					printCellRight("$reportTable{$reportnode}{health}",$cellColor);
					$cellColor = colorResponseTime($reportTable{$reportnode}{response});
					printCellRight("$reportTable{$reportnode}{response}",$cellColor);
					rowEnd;
				}
			}
		} # end sort eq reachability
		elsif ( $sort eq "availability" ) {
			foreach $reportnode ( sort
				{
					$reportTable{$a}{available} <=> $reportTable{$b}{available} ||
					$reportTable{$a}{health} <=> $reportTable{$b}{health} ||
					$a cmp $b
				}
				keys %reportTable )
			{
				loadSystemFile($reportnode);
				if (	( $reportTable{$reportnode}{net} eq $netType and
					  $reportTable{$reportnode}{role} eq $roleType
					) or
					( $reportTable{$reportnode}{group} eq $netType and
					  $roleType eq ""
					)
				) {
					rowStart;
					printCellNoWrap("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a>");
					printCellNoWrap("$reportTable{$reportnode}{devicetype}");
					printCellNoWrap("$reportTable{$reportnode}{role}");
					printCellNoWrap("$reportTable{$reportnode}{net}");
					$cellColor = colorHighGood($reportTable{$reportnode}{reachable});
					printCellRight("$reportTable{$reportnode}{reachable}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{available});
					printCellRight("$reportTable{$reportnode}{available}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{health});
					printCellRight("$reportTable{$reportnode}{health}",$cellColor);
					$cellColor = colorResponseTime($reportTable{$reportnode}{response});
					printCellRight("$reportTable{$reportnode}{response}",$cellColor);
					rowEnd;
				}
			}
		} # end sort eq reachability
		elsif ( $sort eq "response" ) {
			foreach $reportnode ( sort
				{
					$reportTable{$b}{response} <=> $reportTable{$a}{response} ||
					$reportTable{$a}{health} <=> $reportTable{$b}{health} ||
					$a cmp $b
				}
				keys %reportTable )
			{
				loadSystemFile($reportnode);
				if (	( $reportTable{$reportnode}{net} eq $netType and
					  $reportTable{$reportnode}{role} eq $roleType
					) or
					( $reportTable{$reportnode}{group} eq $netType and
					  $roleType eq ""
					)
				) {
					rowStart;
					printCellNoWrap("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a>");
					printCellNoWrap("$reportTable{$reportnode}{devicetype}");
					printCellNoWrap("$reportTable{$reportnode}{role}");
					printCellNoWrap("$reportTable{$reportnode}{net}");
					$cellColor = colorHighGood($reportTable{$reportnode}{reachable});
					printCellRight("$reportTable{$reportnode}{reachable}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{available});
					printCellRight("$reportTable{$reportnode}{available}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{health});
					printCellRight("$reportTable{$reportnode}{health}",$cellColor);
					$cellColor = colorResponseTime($reportTable{$reportnode}{response});
					printCellRight("$reportTable{$reportnode}{response}",$cellColor);
					rowEnd;
				}
			}
		} # end sort eq reachability
		elsif ( $sort eq "health" ) {
			foreach $reportnode ( sort
				{
					$reportTable{$a}{health} <=> $reportTable{$b}{health} ||
					$a cmp $b
				}
				keys %reportTable )
			{
				loadSystemFile($reportnode);
				if (	( $reportTable{$reportnode}{net} eq $netType and
					  $reportTable{$reportnode}{role} eq $roleType
					) or
					( $reportTable{$reportnode}{group} eq $netType and
					  $roleType eq ""
					)
				) {
					rowStart;
					printCellNoWrap("<a href=\"http://$NMIS::config{nmis_host}$NMIS::config{nmis}?file=$conf&amp;type=summary&amp;node=$reportnode\">$reportnode</a>");
					printCellNoWrap("$reportTable{$reportnode}{devicetype}");
					printCellNoWrap("$reportTable{$reportnode}{role}");
					printCellNoWrap("$reportTable{$reportnode}{net}");
					$cellColor = colorHighGood($reportTable{$reportnode}{reachable});
					printCellRight("$reportTable{$reportnode}{reachable}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{available});
					printCellRight("$reportTable{$reportnode}{available}",$cellColor);
					$cellColor = colorHighGood($reportTable{$reportnode}{health});
					printCellRight("$reportTable{$reportnode}{health}",$cellColor);
					$cellColor = colorResponseTime($reportTable{$reportnode}{response});
					printCellRight("$reportTable{$reportnode}{response}",$cellColor);
					rowEnd;
				}
			}
		} # end elsif
		# default value for sort is reachability

		# Print the summaries!!!!
		if ( $netType ne "" and $roleType eq "" ) { $summaryhash = $netType; }
		else { $summaryhash = "$netType-$roleType"; }

		rowStart;
		printHeadCell("Group Averages","#FFFFFF",4);
			$cellColor = colorHighGood($summaryTable{$summaryhash}{avgreachable});
			printHeadCell($summaryTable{$summaryhash}{avgreachable},$cellColor);
			$cellColor = colorHighGood($summaryTable{$summaryhash}{avgavailable});
			printHeadCell($summaryTable{$summaryhash}{avgavailable},$cellColor);
			$cellColor = colorHighGood($summaryTable{$summaryhash}{avghealth});
			printHeadCell($summaryTable{$summaryhash}{avghealth},$cellColor);
			$cellColor = colorResponseTime($summaryTable{$summaryhash}{avgresponse});
			printHeadCell($summaryTable{$summaryhash}{avgresponse},$cellColor);
		rowEnd;
	}

	# AS 14.05.02 Adding Ambrose Li's sort patch
	sub alpha {
		#my $a = shift;
		#my $b = shift;
		local($&, $`, $', $1, $2, $3, $4);
		# Sort numbers numerically
		return $a <=> $b if $a !~ /\D/ && $b !~ /\D/;
		# Sort IP addresses numerically within each dotted quad
		if ($a =~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/) {
			my($a1, $a2, $a3, $a4) = ($1, $2, $3, $4);
			if ($b =~ /^(\d+)\.(\d+)\.(\d+)\.(\d+)$/) {
				my($b1, $b2, $b3, $b4) = ($1, $2, $3, $4);
				return ($a1 <=> $b1) || ($a2 <=> $b2)
				|| ($a3 <=> $b3) || ($a4 <=> $b4);
			}
		}
		# Handle things like Level1, ..., Level10
		if ($a =~ /^(.*\D)(\d+)$/) {
		    my($a1, $a2) = ($1, $2);
		    if ($b =~ /^(.*\D)(\d+)$/) {
				my($b1, $b2) = ($1, $2);
				return $a2 <=> $b2 if $a1 eq $b1;
		    }
		}
		# Default is to sort alphabetically
		return $a cmp $b;
	}


	# clean up if a file print.
	if ( $fileprint ) {
		print "\n";
		close (STDOUT) or warn "can't close filename: $!";
	}
} # end typeReports


