#!/usr/bin/perl
#
# $Id: summary.pl,v 1.8 2006/01/24 17:07:45 ibrunello Exp $
#
#
#    summary.pl - NMIS CGI Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 
# 
#****** Shouldn't be anything else to customise below here *******************

use Time::ParseDate; 
use strict;
use NMIS;
use func;

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();
 
# This reads in the information sent when the user pressed Submit
my %FORM = getCGIForm($ENV{'QUERY_STRING'});
my $scriptname = $ENV{SCRIPT_NAME};

# Break the queary up for the names
my $query = $FORM{query};
my $group = $FORM{group};
my $type = $FORM{type};
my $node = $FORM{node};
# Allow program to use other configuration files
my $conf;
if ( $FORM{file} ne "" ) { $conf = $FORM{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

my $version = "1.01";

# Before going any further, check to see if we must handle
# an authentication login or logout request
$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();
my $tb = ();

# set minimal test for security and authorization used throughout
# code. Otherwise, if nauth.pm module is available then
# create nauth object for security and authorization methods
#
#eval {
#       require NMIS::Auth or die "NO_NAUTH module";
#       require NMIS::Users or die "NO_USERS module";
#};
if ( $@ =~ /NO/ ) {
	$auth = \{ Require => 0 };
} else {
	$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
	$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth
}

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
	# check for username from other sources
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
}

# generate the cookie if $auth->user is set
#
if ( $auth->Require and $user->user ) {
	push @cookies, $auth->generate_cookie($user->user);
	$headeropts{-cookie} = [@cookies];
}

# verify access to this command/tool bar/button
#
if ( $auth->Require ) {
	# CheckAccess will throw up a web page and stop if access is not allowed
	# $auth->CheckAccess($user, "nmisconf") or die "Attempted unauthorized access";
}

loadNodeDetails;
loadEventStateNoLock;
loadEventStateSlave;

&pageStart("NMIS Summary");

# make the default action to be info
if 	( $query eq "status" and $node ne "" ) 	{ &nodestatus($node); }
elsif 	( $query eq "status" ) 			{ &groupstatus($group); }
elsif 	( $query eq "graph" ) 			{ &graph($node); }
elsif 	( $query eq "list" ) 			{ &list($group); }
elsif 	( $query eq "groups" ) 			{ &list("nonodes"); }
else 						{ &noquery; }

&pageEnd;

exit 0;

sub list {
	my $group = shift;
	my $node;
	my $event_status;
	my $event_color;
	my $groupStatus;

	print "<a href=\"$ENV{SCRIPT_NAME}?file=$conf\">Menu</a><br>\n";

	if (($group ne "nonodes" and $group ne "") and $user->InGroup($group) ) {
		print "Group <a href=\"$ENV{SCRIPT_NAME}?query=status&group=$group\">$group</a><br>\n";
	}
	# Insert some nice status info about the devices for the summary menu.
	if ( $group eq "" or $group eq "nonodes" ) {
	        foreach $group (sort ( keys (%NMIS::groupTable) ) ) {
			next unless $user->InGroup($group);
			$groupStatus = overallNodeStatus($group);
			print "Group <a href=\"$ENV{SCRIPT_NAME}?query=list&group=$group\">$group</a> $groupStatus<br>\n";
		}
	}
	if ( $group ne "nonodes" ) {
		foreach $node (sort ( keys (%NMIS::nodeTable) ) ) {
			next unless $user->InGroup($group);
			#Only do the group
			if ( $group eq $NMIS::nodeTable{$node}{group} or $group eq "") {
				if ( eventExist($node,"Node Down","Ping failed") eq "true" ) {
					($event_status,$event_color) = eventLevel("Node Down",$NMIS::nodeTable{$node}{role});
				}
				else {
					($event_status,$event_color) = eventLevel("Node Up",$NMIS::nodeTable{$node}{role});
				}
				print "Node <a href=\"$ENV{SCRIPT_NAME}?query=status&node=$node\">$node</a> $event_status<br>\n";	
			}
		}
	}
}

sub groupstatus {
	my $group = shift;
	my $start_time = shift;
	my $end_time = shift;
	my %summaryHash;
	my $groupStatus;

	if ( $start_time eq "" ) { $start_time = "-8 hours"; }
	if ( $end_time eq "" ) { $end_time = time; }

 	return 0 unless $user->InGroup($group);

	%summaryHash = &getGroupSummary("",$start_time,$end_time);
	$groupStatus = overallNodeStatus($group);

	print "<a href=\"$ENV{SCRIPT_NAME}?file=$conf\">Menu</a><br>\n";
	print "group=<a href=\"$ENV{SCRIPT_NAME}?query=list&group=$group\">$group</a><br>\n";
	print "status=$groupStatus<br>\n";
	print "reachable=$summaryHash{average}{reachable}<br>\n";
	print "available=$summaryHash{average}{available}<br>\n";
	print "health=$summaryHash{average}{health}<br>\n";
	print "response=$summaryHash{average}{response}<br>\n";
	print "metric=$summaryHash{average}{metric}<br>\n";
	print "count=$summaryHash{average}{count}<br>\n";
}

sub nodestatus {
	my $node = shift;
	my $start_time = shift;
	my $end_time = shift;
	
	my @tmparray;
	my @tmpsplit;
	my %summaryHash;
	my $overallStatus;
	my $reportStats;
	my $index;

	if ( $start_time eq "" ) { $start_time = "-8 hours"; }
	if ( $end_time eq "" ) { $end_time = time; }

 	return 0 unless $user->InGroup($NMIS::nodeTable{$node}{group});

	if ( eventExist($node,"Node Down","Ping failed") eq "true" ) {
		($summaryHash{$node}{event_status},$summaryHash{$node}{event_color}) = eventLevel("Node Down",$NMIS::nodeTable{$node}{role});
	}
	else {
		($summaryHash{$node}{event_status},$summaryHash{$node}{event_color}) = eventLevel("Node Up",$NMIS::nodeTable{$node}{role});
	}

	loadSystemFile($node);
##	$reportStats = summaryStats($node,"health",$start_time,$end_time);
	%summaryHash = (%summaryHash,summaryStats(node => $node,type => "health",start => $start_time,end => $end_time,key => $node));
##	if ( $reportStats != 1 and $reportStats ne "" ) {
##		@tmparray = split " ","@$reportStats";
##		for ( $index = 0; $index <= $#tmparray; ++$index ) {
##			@tmpsplit = split "=",@tmparray[$index];
##			$summaryHash{$node}{$tmpsplit[0]} = $tmpsplit[1];
##		}
##	}
	$summaryHash{$node}{metric} = sprintf("%.3f",( ( $summaryHash{$node}{reachable} + $summaryHash{$node}{available} + $summaryHash{$node}{health} ) / 3) );
	#$overallStatus = overallNodeStatus($group);

	print "<a href=\"$ENV{SCRIPT_NAME}?file=$conf\">Menu</a><br>\n";
	print "node=<a href=\"$ENV{SCRIPT_NAME}?query=graph&node=$node\">$node</a><br>\n";
	print "group=<a href=\"$ENV{SCRIPT_NAME}?query=list&group=$NMIS::nodeTable{$node}{group}\">$NMIS::nodeTable{$node}{group}</a><br>\n";
	print "status=$summaryHash{$node}{event_status}<br>\n";
	print "reachable=$summaryHash{$node}{reachable}<br>\n";
	print "available=$summaryHash{$node}{available}<br>\n";
	print "health=$summaryHash{$node}{health}<br>\n";
	print "response=$summaryHash{$node}{response}<br>\n";
	print "metric=$summaryHash{$node}{metric}<br>\n";
}

sub graph {
	$node = shift;
	return 0 unless $user->InGroup($NMIS::nodeTable{$node}{group});
	print "<img BORDER=\"0\" ALT=\"$node Health\" SRC=\"$NMIS::config{nmis}?type=drawgraph&node=$node&graph=health&length=1day&start=0&end=0&width=200&height=200&title=short\">\n";
}

sub noquery {
	print "Menu<br>\n";
	print "<a href=\"$ENV{SCRIPT_NAME}?query=groups\">Group List</a><br>\n";
	print "<a href=\"$ENV{SCRIPT_NAME}?query=list\">List All</a><br>\n";
	print "<a href=\"$ENV{SCRIPT_NAME}?query=status\">Status</a><br>\n";
	print "<a href=\"$NMIS::config{nmis}?file=$conf\">Full NMIS</a><br>\n";
}


sub pageStart {
  	my $string = shift;
	print <<ENDHTML;
Content-type: text/html\n
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<HEAD>
<title>$string</title>
</head>
<body>

ENDHTML
}

sub pageEnd { print "</BODY>\n</html>"; }

