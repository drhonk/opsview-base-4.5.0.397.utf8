#!/usr/bin/perl
#
# $Id: admin.pl,v 1.6 2006/10/04 09:23:50 decologne Exp $
#
#    admin.pl - NMIS Perl Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";

# 
#****** Shouldn't be anything else to customise below here *******************

use strict;
use web;
use NMIS;

# Perl and External modules
use Fcntl qw(:DEFAULT :flock);
#use Time::ParseDate;
#use File::Basename;

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;

# Prefer to use CGI for html processing
use CGI qw(:standard);

# declare holder for CGI objects
use vars qw($q);
$q = new CGI; # This processes all parameters passed via GET and POST

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();


#
# This reads in the information sent when the user pressed Submit
#

my $type = $q->param('type');
my $node = $q->param('node');
my $admin = $q->param('admin');
my $space = $q->param('space');
my $summary = $q->param('summary');
my $firstname = $q->param('firstname');
my $surname = $q->param('surname');
my $username = $q->param('username');
my $group = $q->param('group');
my $action = $q->param('action');
my $makeitso = $q->param('makeitso');
my $tool = $q->param('tool');
my $conf = $q->param('file');

# Allow program to use other configuration files
$conf = "nmis.conf" if $conf eq "";
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

if ( $admin ne "" ) { $tool = $admin; }

# Before going any further, check to see if we must handle
# an authentication login or logout request

$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) { 
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# verify access to this action
	# check access for table
	if ($tool ne "") {
		$auth->CheckAccess($user, lc $tool) or die "Attempted unauthorized access";
	} else {
		$auth->CheckAccess($user, "tools") or die "Attempted unauthorized access";
	}

	# logout ?
	if ( $type eq 'logout' ) {
       	$auth->do_logout;
		exit 0;
	}
	# generate the cookie if $user->user is set
	if ( $user->user ) {
        push @cookies, $auth->generate_cookie($user->user);
        $headeropts{-cookie} = [@cookies];
	}
}

my $scriptname = $NMIS::config{admin};

my $datestamp=NMIS::returnDateStamp;
my $tooloutput;

if ( $action ne "" ) { $admin = "newuser"; }

# Select function to be performed
if ($tool eq "") {
	pageStart("Admin Menu","false", \%headeropts);
	tableStart;

	&adminMenu; 

	tableEnd;
	pageEnd;
}
else { 
	if ($tool eq "ping") { $tooloutput=`ping -c 3 $node`; }
	elsif ($tool eq "trace") { $tooloutput=`traceroute -n -m 15 $node`;	}
	elsif ($tool eq "nslookup") { $tooloutput=`nslookup $node`; }
	elsif ($tool eq "finger") { $tooloutput=`finger \@$node`; }
	elsif ($tool eq "who") { $tooloutput=`who`; }
	elsif ($tool eq "man") { $tooloutput=`man $node`; }
	elsif ($tool eq "mank") { $tooloutput=`man -k $node`; }
	elsif ($tool eq "ps") { $tooloutput=`ps -ef`; }
	elsif ($tool eq "iostat") { $tooloutput=`iostat 1 10`; }
	elsif ($tool eq "vmstat") { $tooloutput=`vmstat 1 10`; }
	elsif ($tool eq "df") { $tooloutput=`df -k`; }
	elsif ($tool eq "lft") { $tooloutput=`lft -NASE $node`;	}
	elsif ($tool eq "mtr") { $tooloutput=`mtr --report --report-cycles=10 $node`; }
	elsif ($tool eq "cisco") { 
		if ($node eq "" ) {
			$tooloutput=`/usr/bin/tail -250 /nmis/3.0/logs/cisco.log |sort -M -r`;
		}
		else {
			$tooloutput=`/usr/bin/grep -i "$node" /nmis/3.0/logs/cisco.log|tail -250 |sort -M -r`;
		}
	} 
	elsif ($tool eq "event") { 
		if ($node eq "" ) {
			$tooloutput=`/usr/bin/tail -250 /nmis/3.0/logs/event.log |sort -M -r`;
		}
		else {
			$tooloutput=`/usr/bin/grep -i "$node" /nmis/3.0/logs/event.log|tail -100 |sort -M -r`;
		}
	} 
	elsif ($tool eq "syslog") { $tooloutput=`/usr/bin/tail -250 /nmis/3.0/logs/syslog |sort -M -r`; } 
	elsif ($tool eq "messages") { $tooloutput=`/usr/bin/tail -250 /var/log/messages |sort -M -r`; } 
	elsif ($tool eq "newuser") { 
		if ( $ENV{'REMOTE_USER'} =~ /hligonis|ksinclai/ ) { &newUser; }
	 	$tooloutput="Not allowed by this user";
	}

	
	pageStart("Admin","false", \%headeropts);
	tableStart;

	&adminMenu; 

    	headerBar("$admin results for $node at $datestamp");
	print "<td COLSPAN=9 bgcolor=#FFFFFF><font color=#000000><pre>\n$tooloutput\n</pre></font></td>";
	tableEnd;
	pageEnd;
	exit;

}

sub adminMenu {
print <<EOF;
<FORM ACTION="$scriptname">
<TR>
	<TD bgcolor="#FFFFFF">
		<a style="font-size:large" href="$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl">Dash</a>
	</TD>
	<TD bgcolor="#FFFFFF">
		<span>Tool Name 
		<SELECT NAME=admin SIZE=1>
	            <option value="$admin">$admin</option>
	            <option value="cisco">cisco log</option>
	            <option value="event">event log</option>
	            <option value="newuser">newuser</option>
	            <option value="man">man</option>
	            <option value="mank">man -k</option>
	            <option value="df">df -k</option>
	            <option value="ps">ps -ef</option>
	            <option value="iostat">iostat 1 10</option>
	            <option value="vmstat">vmstat 1 10</option>
	            <option value="who">who</option>
	            <option value="syslog">syslog</option>
	            <option value="messages">messages</option>
	            <option value="finger">finger</option>
	            <option value="ping">ping</option>
	            <option value="trace">traceroute</option>
	            <option value="nslookup">nslookup</option>
EOF
	if ( $NMIS::config{mtr} ne "false" ) { print "<option value=\"mtr\">mtr</option>\n"; }
	if ( $NMIS::config{lft} ne "false" ) { print "<option value=\"lft\">lft</option>\n"; }

	print <<EOF;
		</SELECT>
		Input
	<INPUT NAME=node size="40" VALUE="$node">
	</span>
	<INPUT TYPE=submit VALUE="GO">
	</TD>
</TR>
</FORM> 
EOF
}

sub newUser {
	my $out;
	my $user;
	my $command;
	my %passwdHash;
	
	# Remove offending characters from namestring
	$firstname =~ s/ |\'|\"|-|_|\.//g;
	$surname =~ s/ |\'|\"|-|_|\.//g;

	my $newuser = lc(substr($firstname,0,1)).lc(substr($surname,0,7));
	
	if ($action eq "" ) {
		pageStart("Admin Menu - New User","false", \%headeropts);
		tableStart;

		&adminMenu; 

		headerBar("Adding or Deleting a User");
		&newUserMenu;

		tableEnd;
		pageEnd;
		exit 0;
	}
	else {
		pageStart("Admin Menu - New User","false", \%headeropts);
		tableStart;

		&adminMenu; 

		headerBar("Adding or Deleting a User");

		&newUserMenu;

		rowStart;
		cellStart("#FFFFFF",7);

			if ( $action eq "add" ) {
				$command = "/usr/local/bin/sudo /usr/sbin/useradd -c \"$firstname $surname\" -d /export/home/$newuser -g $group -s /usr/bin/ksh $newuser";

			}
			elsif ( $action eq "delete" ) {
				$command = "/usr/local/bin/sudo /usr/sbin/userdel $username";
			}
			
			if ( $makeitso eq "true" ) {
				# Execute the command to add or delete the user
				$out = `$command`;

				# Bit of Basic Error checking
				if ( $out ne "" ) {
					print "There may have been a problem better look into it!<BR>";
					print "command output:<BR>$out<BR>";
				}
				else {
					if ( $action eq "add" ) { 
						print "User Added: $newuser<BR>"; 
						print "<P>Don't forget to set the password: \"passwd $newuser\"<BR>";
					}
					elsif ( $action eq "delete" ) { 
						print "User Deleted: $username<BR>"; 
						print "<P>Don't forget to remove the home directory<BR>";
					}
				}

				# Make the home Directory
				$command = "/usr/bin/mkdir /export/home/$newuser";
				$out = `$command`;
				if ( $out ne "" ) {
					print "There may have been a problem better look into it!<BR>";
					print "command = $command<BR>";
					print "output:<BR>$out<BR>";
				}
				
				# Change permissions on the directory
				$command = "\/usr\/bin\/chown -R $newuser \/export\/home\/$newuser; \/usr\/bin\/chmod -R u+wr g+r o-rwx \/export\/home\/$newuser";
				$out = `$command`;
				if ( $out ne "" ) {
					print "There may have been a problem better look into it!<BR>";
					print "command = $command<BR>";
					print "output:<BR>$out<BR>";
				}
			} 
			else {
				if ( $action eq "add" ) {
					print "<STRONG>Adding User</STRONG><BR>";
					print "username = $newuser<BR>";
					print "Group = $group<BR>";
					print "Description = \"$firstname $surname\"<BR>";
					print "Home = \/export\/home\/$newuser<BR>";
 					print "Shell = \/usr\/bin\/ksh<BR>";
 					print "<BR>";
				 	print "<A HREF=\"$scriptname?action=$action&firstname=$firstname&surname=$surname&group=$group&makeitso=true\">\"MAKE IT SO\"</A>";
			}
				elsif ( $action eq "delete" ) {
					print "<STRONG>Deleting User</STRONG><BR>";
					print "username = $username<BR>";
					print "<BR>";
				 	print "<A HREF=\"$scriptname?action=$action&username=$username&makeitso=true\">\"MAKE IT SO\"</A>";
				}
				
			}
		cellEnd;
		rowEnd;
		rowStart;
		cellStart("#FFFFFF",7);

			print "<STRONG>Password File Contents</STRONG>";

			%passwdHash = NMIS::readPasswordFile;
			preStart;			
			foreach $user (sort ( keys (%passwdHash) ) )  {
		                print "$user uid=$passwdHash{$user}{uid} gid=$passwdHash{$user}{gid} shell=$passwdHash{$user}{shell} home=$passwdHash{$user}{home}\n";
			}
			preEnd;			

		cellEnd;
		rowEnd;

		tableEnd;
		pageEnd;
		exit 0;
	}
}
sub newUserMenu {
	my $user;
	my %groupHash;
	my %passwdHash;
	
	%passwdHash = NMIS::readPasswordFile;
	%groupHash = NMIS::readGroupFile;

print<<EOF;
<FORM ACTION="$scriptname">
<TR>
	<TH bgcolor="#FFFFFF"><INPUT TYPE=submit VALUE="ACTION"></TH>
	<TD bgcolor="#FFFFFF">
		Action<BR>
		<SELECT NAME=action SIZE=1>
	            <option value="add">add</option>
        	    <option value="delete">delete</option>
		</SELECT>
	</TD>
	<TD bgcolor="#FFFFFF">
		Group<BR>
		<SELECT NAME=group SIZE=1>
	            <option value="nws">nws</option>
	            <option value="img">img</option>
        	    <option value="guest">guest</option>
		</SELECT>
	</TD>
	<TD bgcolor="#FFFFFF">
		username<BR>
	     	<SELECT NAME=username SIZE=1>
	            <OPTION VALUE=""></OPTION>
EOF
        foreach $user (sort ( keys (%passwdHash) ) )  {
		if (	( $groupHash{nws}{gid} eq $passwdHash{$user}{gid} ) ||
			( $groupHash{guest}{gid} eq $passwdHash{$user}{gid} ) ||
			( $groupHash{img}{gid} eq $passwdHash{$user}{gid} ) 
		) {
	                print "<OPTION VALUE=\"$user\">$user</OPTION>\n";
        	}

	}

	print <<EOF;
		</SELECT>
	</TD>
	<TD bgcolor="#FFFFFF">First Name<BR><INPUT NAME=firstname VALUE="$firstname"></TD>
	<TD bgcolor="#FFFFFF">Surname<BR><INPUT NAME=surname VALUE="$surname"></TD>
</TR>
</FORM> 
EOF
}

exit(0);

