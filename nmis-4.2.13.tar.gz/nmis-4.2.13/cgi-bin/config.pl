#!/usr/bin/perl
#
# $Id: config.pl,v 1.5 2006/02/09 15:09:50 decologne Exp $
#
#    config.pl - NMIS View Tables Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 
# 
#****** Shouldn't be anything else to customise below here *******************

use strict;
use web;
use NMIS;
use func;
use csv;
use Fcntl qw(:DEFAULT :flock);

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;

# Prefer to use CGI for html processing
use CGI qw(:standard);

# declare holder for CGI objects
use vars qw($q);
$q = new CGI; # This processes all parameters passed via GET and POST

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

my $scriptname = $ENV{SCRIPT_NAME};

# This reads in the information sent when the user pressed Submit
my %FORM = getCGIForm($ENV{'QUERY_STRING'});

# Allow program to use other configuration files
my $conf;
if ( $FORM{file} ne "" ) { $conf = $FORM{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }


# Before going any further, check to see if we must handle
# an authentication login or logout request

$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# verify access to this plugin
	$auth->CheckAccess($user, "nmisconf") or die "Attempted unauthorized access";

	# logout ?
	if ( $FORM{type} eq 'logout' ) {
       	$auth->do_logout;
		exit 0;
	}
	# generate the cookie if $user->user is set
	if ( $user->user ) {
        push @cookies, $auth->generate_cookie($user->user);
        $headeropts{-cookie} = [@cookies];
	}
}



# Break the query up for the names
my $type = $FORM{type};

my $counter;
my $group;

my $colspan = 5;

my %types;
my %categories;
my @fields;
my $nmis_url = "<a href=\"$NMIS::config{nmis}?file=$conf\"><img alt=\"NMIS Dash\" src=\"$NMIS::config{nmis_icon}\" border=\"0\"></a>";
my $back_url = "<a href=\"$ENV{HTTP_REFERER}\"><img alt=\"Back\" src=\"$NMIS::config{back_icon}\" border=\"0\"></a>";
my $help_url = "<a href=\"$NMIS::config{help_file}#$FORM{table}\"><img alt=\"Help\" src=\"$NMIS::config{help_icon}\" border=\"0\"></a>";

if ( $FORM{edit} eq "true" and $FORM{change} ne "true" and $FORM{row} ne "" ) {
        &editRowMenu(file => $configfile, row => $FORM{row}, value => $FORM{value});
}
elsif ( $FORM{edit} eq "true" and $FORM{change} eq "true" and $FORM{row} ne "" ) {
        &editRow(file => $configfile, row => $FORM{row}, value => $FORM{value});
        &displayConfig(file => $configfile);
}
else {
        &displayConfig(file => $configfile);
}

exit;

sub displayConfig {
	my %args = @_;
	my $file = $args{file};
	my @row;
	my $header = "NMIS Configuration";
	my $header2 = "$back_url$nmis_url$help_url NMIS Configuration";
	
	pageStart($header,"false", \%headeropts);
	print Tr(td({width=>"100%"}, &do_dash_banner($auth->Require, $user->user) ));
	tableEnd;
	cssTableStart("white");
	print "<tr><td class=\"view_header\" colspan=\"2\">$header2</td></tr>\n";

	sysopen (IN, "$file", O_RDONLY) or warn "Cannot open $file";
	flock (IN, LOCK_SH) or warn "can't lock filename: $!";
	while (<IN>) {
		chomp;
		if ( $_ !~ /^#|^;|^\n/ ) {
			$_ =~ s/</&lt;/g;
			$_ =~ s/>/&gt;/g;
			@row = split(/=/, $_);
			print <<EO_HTML;
	<tr>
	  <td class="head"><a href="$ENV{SCRIPT_NAME}?edit=true&amp;row=$row[0]&amp;value=$row[1]">$row[0]</a></td>
	  <td class="view">$row[1]</td>
	</tr>
EO_HTML
		}
	}
	close (IN) or warn "can't close filename: $!";

	tableEnd;
	pageEnd;
}

sub editRowMenu {
	my %args = @_;
	my $file = $args{file};
	my $row = $args{row};
	my $value = $args{value};
	my @info;
	my $flag;
	
	my $header = "NMIS Configuration - $row";
	my $header2 = "$back_url$nmis_url$help_url NMIS Configuration - $row";
	$row =~ s/</&lt;/g;
	$row =~ s/>/&gt;/g;

	pageStart($header,$NMIS::config{style}, \%headeropts);
	print Tr(td({width=>"100%"}, &do_dash_banner($auth->Require, $user->user) ));
	cssTableStart("plain");

	print "<tr><td class=\"view_header\" colspan=\"2\">$header2</td></tr>\n";
	
	print "<form action=\"$ENV{SCRIPT_NAME}\" method=\"get\">\n";
	my $l = (length $value) * 1.2;
	$l = 20 if $l < 20;
	print <<EO_HTML;
	<tr>
	  <td class="head">$row</td>
	  <td class="view"><input type="text" size="$l" name="value" value="$value"></td>
	</tr>
	<input type=\"hidden\" name=\"row\" value=\"$row\">
	<input type=\"hidden\" name=\"change\" value=\"true\">
	<input type=\"hidden\" name=\"edit\" value=\"true\">
	<tr>
	  <td class=\"menugrey\" colspan=\"2\"><input type=\"submit\" value=\"EDIT\"></td>
	</tr>
EO_HTML
	print "</form>\n";
	tableEnd;
# look for help info
	sysopen (IN, "$file", O_RDONLY) or warn "Cannot open $file";
	flock (IN, LOCK_SH) or warn "can't lock filename: $!";
	while (<IN>) {
		chomp;
		if ( $_ =~ /^#/ ) {
			@info = () if (!$flag);
			push @info, $_ if ($_ !~ /^##/);
			$flag++;
		} else {
			my @row = split(/=/, $_);
			if ( $row[0] eq $row ) {
				last ; # found, stop search
			}
			$flag = 0; # empty @info
		}
	}
	close (IN) or warn "can't close filename: $!";
	foreach (@info) {
		print "$_<br>";
	}
	pageEnd;
}

sub editRow {
	my %args = @_;
	my $file = $args{file};
	my $row = $args{row};
	my $value = $args{value};
	
	my @buffer;
	my @rowbits;
	my $line = 0;
	sysopen (IN, "$file", O_RDONLY) or warn "Cannot open $file for reading. $!";
	flock (IN, LOCK_SH) or warn "can't lock filename: $!";
	while (<IN>) {
		chomp;
		$buffer[$line] = $_;
		++$line;
	}
	close (IN) or warn "can't close filename: $!";

	open (OUT, ">$file") or warn "Cannot open $file for writing. $!";
	flock(OUT, LOCK_EX) or warn "can't lock filename: $!";
	for ($line = 0; $line <= $#buffer; ++$line) {
		@rowbits = split(/=/, $buffer[$line]);
		if ( $rowbits[0] eq $row ) {
			print OUT "$row=$value\n";
		} else {
			print OUT "$buffer[$line]\n";
		}
	}
	close (OUT) or warn "can't close filename: $!";
}
