#!/usr/bin/perl
#
#
# $Id: map.pl,v 1.10 2006/10/02 18:22:49 decologne Exp $
#
#    map.pl - NMIS map Perl Package - Network Mangement Information System
#    Copyright (C) 2000,2001 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
# 
# map.pl - the maps stuff to make new maps easy.
#
# Uses syslocation data from a router
# snmp-server location latitude,longitude,altitude,label
# for example: snmp-server location -43.55,172.67,0,CHC1
# also need to enable sysLoc in nmis.conf - see V4 nmis.conf for details on that and associated regex.
#  
# By eric.greenwood@imlnetwork.com and daniel.parson@imlnetwork.com with the flash built by Mike Ferrar at
# Atmosphere Design Limited (Thanks Mike!).
#
# How this all works:
#
# showmap() is called with a map name e.g. showmap( \%map, \%sites, \%links ); This then looks for
# map.swf and map.jpg in the NMIS images. There needs to be an onload event called on
# the body tag to initialise the data e.g. onload="map()". 
# The %map hash variable needs to be defined and is an hash of the following form:
#
# %map = (	map => map name,
#			mapurl => image directory url,
#			mapwidth => pixel width of map jpeg,
#			mapheight => pixel height of map jpeg, 
#			toplat => degrees latitude of the top left corner,
#			toplon => degrees longitude of the top left corner,
#			botlat => degrees latitude of the bottom right corner,
#			botlon => degrees longitude of the bottom right corner,
#			legendx   => legend x value (pixels),
#			legendy   => legend y value (pixels),
# 			);
#
#
# You must specify the %sites and %links hash
#
#  %sites = ( SITE1 => { latlong => "51.63;-0.77" , label => 'label1', pos => 1, url => 'http://url', status => 1 }, 
#             SITE2 => { latlong => "45.47;9.20" , label => 'label2', pos => 1,  url => 'http://url', status => 1 },
#           ); 
# pos is a value for positioning the label wrt to the node location from 1 to 8: 1=top, 3=right, 5=bottom, 7=left, the others are in between.
#
#
#  %links = ( 'SITE1;SITE2' => { 'util' => .1,  'url' => 'http://url'},
#             'SITE1;SITE3' => { 'util' => .2,  'url' => 'http://url'},
#           );
# Utilisation is a number from 0 -> 1.00 and will colour the links based on the legend values.
#
# to test, call this script with http://host/map.pl?map=test
# if no map name given, will default to mapping nodes and links based on NMIS nodes.csv, router sysLocation, and links.csv, on a world style layout
#
# tested on IE6 - should work on all later versions of IE.
#
# As of Oct 2003 Mozilla compatible - thanks always to John Gruber
# tested on  Redhat 9.0, Mozilla 1.2.1, Flash plugin 6.0r79.
# Check "about" screens for Mozilla and Flash versions.
# If the flash plug-in is version 5.x, it's not scriptable for Mozilla. (can not set variables from JavaScript) 
# when installing the flash plugin, double check the Mozilla path, it may be something like /usr/lib/mozilla-1.2.1 
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 
# 
#****** Shouldn't be anything else to customise below here *******************

require 5;
use Fcntl qw(:DEFAULT :flock);

use RRDs;
use strict;
use web;
use csv;
use NMIS;
use func;
use rrdfunc;

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

my $my_data;
my $conf;
my $formmap;
my $debug = "";

my %FORM;
my %nvp;
$conf = 'nmis.conf';
if ( $ENV{'REQUEST_METHOD'} eq "GET" ) {
   	$my_data = $ENV{'QUERY_STRING'};
	my @pairs = split(/&/, $my_data);
	foreach (@pairs) {
	    my ($name, $value) = split(/=/, $_);
	    $value =~ tr/+/ /;
	    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
		$FORM{$name} = $value;
	}

	$conf = $FORM{file} ? $FORM{file} : "nmis.conf";
	$formmap = $FORM{map};
}

my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }


# Before going any further, check to see if we must handle
# an authentication login or logout request
$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();
my $tb = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
      # check for username from other sources
      # either set by the web server or via a set cookie
      $user->SetUser( $auth->verify_id );

      # $user should be set at this point, if not then redirect
      unless ( $user->user ) {
              $auth->do_force_login("Authentication is required. Please login.");
              exit 0;
      }
	# verify access to this command/tool bar/button
	#
	# CheckAccess will throw up a web page and stop if access is not allowed
	$auth->CheckAccess($user, "map") or die "Attempted unauthorized access";

	# generate the cookie if $auth->user is set
	#
	push @cookies, $auth->generate_cookie($user->user);
	$headeropts{-cookie} = [@cookies];

}


# if using map=xxx - add hook for it here.
#
if ( $formmap eq "test" ) { &testmap; }
elsif ( $formmap eq "" ) { &nmismap; }
else {
	pageStart;
	print "<h1>No map type defined</h1>\n\n";
	print "<p><a href=\"$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl\">Home</a><\p>\n\n</BODY>\n</HTML>\n";
	exit(0);
}



# try and find some data in the nmis database....
sub nmismap {

	# start with the nodes and locate them. get data from nodes.csv and device sysLocation.
	my %sites;
	my %links;
	my $lat;
	my $long;
	my $label;
	my $status;
	my $node;
	my $shortnode;
	my $sysLocation;
	my $linkname;
	my $reportStats;
	my %reportTable;
	my $nodex;
	my %seen;
	

	loadNodeDetails;
	foreach $node (sort keys %NMIS::nodeTable ) {
		next unless $user->InGroup($NMIS::nodeTable{$node}{group});
		loadSystemFile($node);

		# If sysLocation is formatted for GeoStyle, then get long, lat and alt
		if ( ($NMIS::systemTable{sysLocation}  =~/$NMIS::config{sysLoc_format}/ ) and $NMIS::config{sysLoc} eq "on") { 
			# Node has sysLocation that is formatted for Geo Data
			( $lat, $long, my $alt, $sysLocation) = split(',',$NMIS::systemTable{sysLocation});
	
			# get node status
			if ( eventExist($node,"Node Down","Ping failed") eq "true" ) {
				$status = 0;
			}
			else {
				$status=1;
			}
			# populate the hash
			# but before we do that, lets look at label position and see if we can move labels around on some fuzzy logic basis.
			# take the int value of latlong and if we are within 5 points, move the label.
			my $key = int($lat/5).";".int($long/5);
			if ( exists $seen{$key} ) {
				$seen{$key} += 2;	# rotate the label by 2
			}
			else {
				$seen{$key} = 1;
			}

			$sites{$node}{latlong} = "$lat;$long";
			$sites{$node}{label} = "$sysLocation";
			$sites{$node}{pos} = "$seen{$key}";
			$sites{$node}{url} = "$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl?file=$conf&node=$node&type=summary";
			$sites{$node}{status} = "$status";

		} elsif ( ($NMIS::systemTable{DNSloc}  ne 'unknown') and $NMIS::config{DNSLoc} eq "on") {
			# Node has DNS LOC data for Geo Data
			( $lat, $long, my $alt) = split(',',$NMIS::systemTable{DNSloc});
			if ($NMIS::systemTable{sysLocation} ne 'default') { 
				$sysLocation = $NMIS::systemTable{sysLocation};
			}
			$sysLocation = $NMIS::systemTable{sysName} ;

				# get node status
			if ( eventExist($node,"Node Down","Ping failed") eq "true" ) {
				$status = 0;
			}
			else {
				$status=1;
			}
			# populate the hash
			# but before we do that, lets look at label position and see if we can move labels around on some fuzzy logic basis.
			# take the int value of latlong and if we are within 5 points, move the label.
			my $key = int($lat/5).";".int($long/5);
			if ( exists $seen{$key} ) {
			        $seen{$key} += 2;       # rotate the label by 2
			}
			else {
			        $seen{$key} = 1;
			}

			$sites{$node}{latlong} = "$lat;$long";
			$sites{$node}{label} = "$sysLocation";
			$sites{$node}{pos} = "$seen{$key}";
			$sites{$node}{url} = "$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl?file=$conf&node=$node&type=summary";
			$sites{$node}{status} = "$status";
		}
	} # end foreach

	# links - get data from links.csv.
	# note: 0 util value gives black line, lets keep this for down links.
	# so any util that comes up as zero, put to .01 % to keep grey

	loadLinkDetails;

	foreach $linkname ( keys %NMIS::linkTable )   {
		if ( exists $sites{$NMIS::linkTable{$linkname}{node1}}
			 and exists $sites{$NMIS::linkTable{$linkname}{node2}}
		) {

			loadSystemFile($NMIS::linkTable{$linkname}{node1});
			loadInterfaceFile($NMIS::linkTable{$linkname}{node1});

			# Get the link availability from the local node!!!
			my $tmpifDescr1 = convertIfName($NMIS::linkTable{$linkname}{interface1});
			if ( $NMIS::linkTable{$linkname}{node1} ne ""
				and $NMIS::interfaceTable{$tmpifDescr1}{collect} eq "true"
			) {
## call of summaryStats has been changed, Cologne 2005
##	    		$reportStats = summaryStats($NMIS::linkTable{$linkname}{node1},"util","-15 minutes",time,$tmpifDescr1,$NMIS::interfaceTable{$tmpifDescr1}{ifSpeed});
	    		%reportTable = (%reportTable,summaryStats(node => $NMIS::linkTable{$linkname}{node1},type => "util",start => "-2 days",end => time,ifDescr => $tmpifDescr1,speed => $NMIS::interfaceTable{$tmpifDescr1}{ifSpeed},key => $linkname));
##				if ( $reportStats != 1 and $reportStats ne "" ) {
##					my @tmparray = split " ","@$reportStats";
##					for ( my $index = 0; $index <= $#tmparray; ++$index ) {
##						my @tmpsplit = split "=",$tmparray[$index];
##						$reportTable{$linkname}{$tmpsplit[0]} = $tmpsplit[1] ;
##					}
##				}
			}
			my $key = "$NMIS::linkTable{$linkname}{node1};$NMIS::linkTable{$linkname}{node2}";

			# make sure we have the highest of in or out util, as the summary link util
			if ($reportTable{$linkname}{inputUtil} > $reportTable{$linkname}{outputUtil}) { 
				$reportTable{$linkname}{totalUtil} = $reportTable{$linkname}{inputUtil};
			} 
			else {
				$reportTable{$linkname}{totalUtil} = $reportTable{$linkname}{outputUtil};	
			}
			# normalise the result to 0->1 for 0-100%
			$reportTable{$linkname}{totalUtil} = int($reportTable{$linkname}{totalUtil}) / 100 ;

			# lets see if this link exist already ! may have been backup ISDN link with 0% util ??
			# so only add if we have higher util, ensures that highest link util displayed and backup or parallel paths with lower util are squashed.
			if ( exists $links{$key} ) {
				if ( $reportTable{$linkname}{totalUtil} > $links{$key}{util} ) {
					$links{$key}{util} = $reportTable{$linkname}{totalUtil};
					$links{$key}{url} = "$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl?file=$conf&node=$NMIS::linkTable{$linkname}{node1}&type=graph&graphtype=util&gsamount=20&gsunits=minutes&glamount=15&glunits=minutes&intf=$NMIS::linkTable{$linkname}{ifIndex1}";
				}
			}
			else {
				$links{$key}{util} = $reportTable{$linkname}{totalUtil} ? $reportTable{$linkname}{totalUtil} : .0001 ;
				$links{$key}{url} = "$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl?file=$conf&node=$NMIS::linkTable{$linkname}{node1}&type=graph&graphtype=util&gsamount=20&gsunits=minutes&glamount=15&glunits=minutes&intf=$NMIS::linkTable{$linkname}{ifIndex1}";
			}
		} # if exists in site.
	} # foreach $linkname


	# standard world map
	my %map = (	map => 'world',
				mapurl => "$NMIS::config{'<url_base>'}/images",
				mapwidth => '1080',
				mapheight => '539', 
	            toplat => '90',
	            toplon => '-170',
	            botlat => '-90',
	            botlon => '190',
	            legendx   => '500',
	            legendy   => '400'
	           );

	showmap( \%map, \%sites, \%links);
}



sub testmap {
# display a test pattern to show how all this works.
#
# this map definition table is specific to the world.jpg and world.swf flash movie in nmis/htdocs/images.
	my %map = (	map => 'world',
				mapurl => "$NMIS::config{'<url_base>'}/images",
				mapwidth => '1080',
				mapheight => '539', 
	            toplat => '90',
	            toplon => '-170',
	            botlat => '-90',
	            botlon => '190',
	            legendx   => '500',
	            legendy   => '400'
	           );

	my %sites = (  LON1 => { latlong => "51.63;-0.77" , label => 'LONDON', pos => 6, url => './map.pl', status => 1 },
	               MIL1 => { latlong => "45.47;9.20" , label => 'MIL', pos => 5,  url => './map.pl', status => 1 },
	               LAX1 => { latlong => "34.37;-118.20" , label => 'LAX', pos => 6,  url => './map.pl', status => 1 },
	               CHC1 => { latlong => "-43.55;172.67" , label => 'CHC', pos => 4,  url => './map.pl', status => 1 },
	               DEN1 => { latlong => "39.73;-104.98" , label => 'DEN', pos => 1,  url => './map.pl', status => 1 },
	               HKG1 => { latlong => "22.25;114.17" , label => 'HKG', pos => 6,  url => './map.pl', status => 1 },
	               SYD1 => { latlong => "-33.09;151.22" , label => 'SYD', pos => 5,  url => './map.pl', status => 1 },
	               BEI1 => { latlong => "39.92;116.43" , label => 'BEI', pos => 1,  url => './map.pl', status => 0 },
	               SGP1 => { latlong => "1.50;103.85" , label => 'SGP', pos => 8,  url => './map.pl', status => 1 }
	              ); 
 
	my %links = (
	               'LON1;MIL1' => { 'util' => .1,  'url' => './map.pl'},
	               'MIL1;DEN1' => { 'util' => .2,  'url' => './map.pl'},
	               'CHC1;LON1' => { 'util' => .3, 'url' => './map.pl'},
	               'CHC1;LAX1' => { 'util' => .4, 'url' => './map.pl'},
	               'CHC1;DEN1' => { 'util' => .5, 'url' => './map.pl'},
	               'DEN1;LON1' => { 'util' => .6, 'url' => './map.pl'},
	               'LAX1;LON1' => { 'util' => .7, 'url' => './map.pl'},
	               'HKG1;LAX1' => { 'util' => .8, 'url' => './map.pl'},
	               'HKG1;DEN1' => { 'util' => .9, 'url' => './map.pl'},
	               'HKG1;LON1' => { 'util' => 1.0, 'url' => './map.pl'},
	               'HKG1;CHC1' => { 'util' => .0,  'url' => './map.pl'},
	               'SYD1;CHC1' => { 'util' => .1, 'url' => './map.pl'},
	               'SYD1;LAX1' => { 'util' => .2, 'url' => './map.pl'},
	               'SYD1;LON1' => { 'util' => .3, 'url' => './map.pl'},
	               'SGP1;CHC1' => { 'util' => .4,  'url' => './map.pl'},
	               'SGP1;HKG1' => { 'util' => .5,  'url' => './map.pl'}
	              );

	showmap(\%map, \%sites, \%links);

} # end testmap

# call this with a array reference
# showmap( \%map, \%sites, \%links);
sub showmap {

	my $map = shift;
	my $sites = shift;
	my $links = shift;
	die " Not an array reference\n" if ref($map) ne "HASH";
 	die " Not an array reference\n" if ref($sites) ne "HASH";
	die " Not an array reference\n" if ref($links) ne "HASH";

	print <<EOHTML;
Content-type: text/html\n
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	  <head>
	    <title>World Map</title>
		<META HTTP-EQUIV="imagetoolbar" CONTENT="no">
 		<META HTTP-EQUIV="refresh" CONTENT="300"> 
	    <link href="http://$NMIS::config{nmis_host}$NMIS::config{styles}" rel="stylesheet" type="text/css">
	  </head>
<body onload="$$map{map}()">

  <h1>World Map</h1>
  <p>Here is the map of the network showing the traffic between sites.
    Click on the sites or links for more information.</p>
  <p><a href="$ENV{SCRIPT_NAME}?file=$conf&amp;map=$formmap">Refresh this page.</a></p>
   <hr>

<p>&nbsp;</p>
<center>
EOHTML

  # Check if this is IE or else use the DOM format.  IE uses classid for object location.  DOM uses MINE type
  if($ENV{'HTTP_USER_AGENT'} =~ "MSIE"){
     print "<OBJECT classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\" codebase=\"http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab\#version=6,0,0,0\" width=\"$$map{mapwidth}\" height=\"$$map{mapheight}\" id=\"$$map{map}\" ALIGN=\"\">\n";
  }else{
     print "<object id=\"$$map{map}\" data=\"$$map{mapurl}/$$map{map}.swf\" type=\"application/x-shockwave-flash\" width=\"$$map{mapwidth}\" height=\"$$map{mapheight}\">\n";  
  }
         print <<EOHTML;
    <PARAM NAME=movie VALUE="$$map{mapurl}/$$map{map}.swf">
    <PARAM NAME=quality VALUE=high> 
    <PARAM NAME=bgcolor VALUE=#FFFFFF>
  </OBJECT>
</center>

<script>
EOHTML
       # If this is IE, use document.objectref ... and the setVariable syntax
       # If this is not IE, use the DOM document.getElementById("myObject").SetVariable("variable","value" syntax
       if($ENV{'HTTP_USER_AGENT'} =~ "MSIE"){
         print <<EOHTML;

function $$map{map}(){
	with(document.$$map{map}){		
		setVariable("img", "$$map{mapurl}/$$map{map}.jpg");
		setVariable("fgColor", "0x000000"); 
		setVariable("nodeSize", "10");
		setVariable("fontSize", "10");
		setVariable("nodeOnColor", "0x00cc00");
		setVariable("nodeOffColor", "0xee0000");
		setVariable("lineSize", "4");
		setVariable("topLat", "$$map{toplat}");
		setVariable("topLong", "$$map{toplon}");
		setVariable("botLat", "$$map{botlat}");
		setVariable("botLong", "$$map{botlon}");
		setVariable("legend", "$$map{legendx};$$map{legendy};100;125;Link Utilisation;10");
		setVariable("entry_1", "0;0.005;0x666666; < 1 %");
		setVariable("entry_2", "0.005;0.5;0x00bb33;1 - 50 %");
		setVariable("entry_3", "0.5;0.6;0xffff33;50 - 60 %");
		setVariable("entry_4", "0.6;0.7;0xffe533;60 - 70 %");
		setVariable("entry_5", "0.7;0.8;0xffcc33;70 - 80 %");
		setVariable("entry_6", "0.8;0.9;0xffb233;80 - 90 %");
		setVariable("entry_7", "0.9;10;0xff9933;90 - 100 %");
EOHTML

	# print this to display a node
	# node_status = 0 for down, 1 for up
	# setVariable("node_###","nodeid;lat;long;node_label;label_position;url;node_status");
	#
	# print this draw a links between nodes.
	# utilisation is some number between 0 and 1 for 0-100%
	# setVariable("link_###","nodeid;nodeid;utilisation;url");


	my $count = 0;
	foreach ( keys %$sites ) {
	  $count++;

		my $latlong = $$sites{$_}{latlong} ? $$sites{$_}{latlong} : "0.00;0.00";
		my $label = $$sites{$_}{label} ? $$sites{$_}{label} : "UNK";
		my $pos = $$sites{$_}{pos} ? $$sites{$_}{pos} : 1;
		my $url = $$sites{$_}{url} ? $$sites{$_}{url} : "./map.pl";
		my $status = $$sites{$_}{status} ? $$sites{$_}{status} : 0;


	  print "		setVariable(\"node_$count\", \"$_;$latlong;$label;$pos;$url;$status\");\n";
	}

	$count = 0;
	foreach ( keys %$links ) {
		$count++;

		# only print links that have sites as endpoints
		my ( $link1, $link2 ) = split ";" , $_ ;
		next if !exists $$sites{$link1};
		next if !exists $$sites{$link2};

		my $util = $$links{$_}{util} ? $$links{$_}{util} : 0;
		my $url = $$links{$_}{url} ? $$links{$_}{url} : "./map.pl";

		print "		setVariable(\"link_$count\", \"$_;$util;$url\");\n";
	}
	print "		setVariable(\"varsLoaded\", \"true\");\n	}\n}\n</script>\n<p>&nbsp;</p>\n";
	print "</body>\n</html>\n";
     }else{

         print <<EOHTML;

function $$map{map}(){
                document.getElementById("$$map{map}").SetVariable("img", "$$map{mapurl}/$$map{map}.jpg");
                document.getElementById("$$map{map}").SetVariable("fgColor", "0x000000"); 
                document.getElementById("$$map{map}").SetVariable("nodeSize", "10");
                document.getElementById("$$map{map}").SetVariable("fontSize", "10");
                document.getElementById("$$map{map}").SetVariable("nodeOnColor", "0x00cc00");
                document.getElementById("$$map{map}").SetVariable("nodeOffColor", "0xee0000");
                document.getElementById("$$map{map}").SetVariable("lineSize", "4");
                document.getElementById("$$map{map}").SetVariable("topLat", "$$map{toplat}");
                document.getElementById("$$map{map}").SetVariable("topLong", "$$map{toplon}");
                document.getElementById("$$map{map}").SetVariable("botLat", "$$map{botlat}");
                document.getElementById("$$map{map}").SetVariable("botLong", "$$map{botlon}");
                document.getElementById("$$map{map}").SetVariable("legend", "$$map{legendx};$$map{legendy};100;125;Link Utilisation;10");
                document.getElementById("$$map{map}").SetVariable("entry_1", "0;0.005;0x666666; < 1 %");
                document.getElementById("$$map{map}").SetVariable("entry_2", "0.005;0.5;0x00bb33;1 - 50 %");
                document.getElementById("$$map{map}").SetVariable("entry_3", "0.5;0.6;0xffff33;50 - 60 %");
                document.getElementById("$$map{map}").SetVariable("entry_4", "0.6;0.7;0xffe533;60 - 70 %");
                document.getElementById("$$map{map}").SetVariable("entry_5", "0.7;0.8;0xffcc33;70 - 80 %");
                document.getElementById("$$map{map}").SetVariable("entry_6", "0.8;0.9;0xffb233;80 - 90 %");
                document.getElementById("$$map{map}").SetVariable("entry_7", "0.9;10;0xff9933;90 - 100 %");
EOHTML

        # print this to display a node
        # node_status = 0 for down, 1 for up
        # setVariable("node_###","nodeid;lat;long;node_label;label_position;url;node_status");
        #
        # print this draw a links between nodes.
        # utilisation is some number between 0 and 1 for 0-100%
        # setVariable("link_###","nodeid;nodeid;utilisation;url");


        my $count = 0;
        foreach ( keys %$sites ) {
          $count++;

                my $latlong = $$sites{$_}{latlong} ? $$sites{$_}{latlong} : "0.00;0.00";
                my $label = $$sites{$_}{label} ? $$sites{$_}{label} : "UNK";
                my $pos = $$sites{$_}{pos} ? $$sites{$_}{pos} : 1;
                my $url = $$sites{$_}{url} ? $$sites{$_}{url} : "./map.pl";
                my $status = $$sites{$_}{status} ? $$sites{$_}{status} : 0;


          print "                document.getElementById(\"$$map{map}\").SetVariable(\"node_$count\", \"$_;$latlong;$label;$pos;$url;$status\");\n";
        }

        $count = 0;
        foreach ( keys %$links ) {
                $count++;

                # only print links that have sites as endpoints
                my ( $link1, $link2 ) = split ";" , $_ ;
                next if !exists $$sites{$link1};
                next if !exists $$sites{$link2};

                my $util = $$links{$_}{util} ? $$links{$_}{util} : 0;
                my $url = $$links{$_}{url} ? $$links{$_}{url} : "./map.pl";

                print "                document.getElementById(\"$$map{map}\").SetVariable(\"link_$count\", \"$_;$util;$url\");\n";
        }
        print "                document.getElementById(\"$$map{map}\").SetVariable(\"varsLoaded\", \"true\");\n}\n</script>\n<p>&nbsp;</p>\n";


        print "</body>\n</html>\n";
     }
} # end map print

