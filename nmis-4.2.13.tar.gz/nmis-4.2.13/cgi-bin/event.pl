#!/usr/bin/perl
#
# $Id: event.pl,v 1.4 2006/10/02 18:22:49 decologne Exp $
#
#
#    event.pl - NMIS CGI Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl"; 

my $configfile = "$FindBin::Bin/nmis.conf";
$configfile =~ s/bin|cgi-bin/conf/;
# 
#****** Shouldn't be anything else to customise below here *******************

use Time::ParseDate; 
use strict;
use NMIS;
use func;

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();
 
# This reads in the information sent when the user pressed Submit
my %FORM = getCGIForm($ENV{'QUERY_STRING'});
my $scriptname = $ENV{SCRIPT_NAME};

# Break the queary up for the names
my $action = $FORM{action};
my $query = $FORM{query};
my $group = $FORM{group};
my $type = $FORM{type};
my $node = $FORM{node};
# Allow program to use other configuration files
if ( $FORM{file} ne "" ) { $configfile = $FORM{file}; }

loadConfiguration($configfile);

my $version = "1.00";

# Before going any further, check to see if we must handle
# an authentication login or logout request
$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
      # check for username from other sources
      # either set by the web server or via a set cookie
      $user->SetUser( $auth->verify_id );

      # $user should be set at this point, if not then redirect
      unless ( $user->user ) {
              $auth->do_force_login("Authentication is required. Please login.");
              exit 0;
      }
	# verify access to this command/tool bar/button
	#
	# CheckAccess will throw up a web page and stop if access is not allowed
	$auth->CheckAccess($user, "eventcur") or die "Attempted unauthorized access";

	# generate the cookie if $auth->user is set
	#
	push @cookies, $auth->generate_cookie($user->user);
	$headeropts{-cookie} = [@cookies];

}


&startTextPage;

# make the default action to be info
if 	( $action eq "exist" ) 		{ &eventExistQuery; }
elsif 	( $action eq "ack" ) 		{ &eventAckQuery; }
elsif 	( $action eq "check" ) 		{ &eventCheckQuery; }
else 						{ &noquery; }

print "\nend $ENV{SCRIPT_NAME}\n";
exit 0;

sub eventExistQuery {
	my $result;

	&loadEventStateNoLock;
	$result = &eventExist($FORM{node}, $FORM{event}, $FORM{details});

	print "result=$result node=$FORM{node} event=$FORM{event} details=$FORM{details}\n";
}

sub eventAckQuery {
	my $result;

	&loadEventStateNoLock;
	$result = &eventExist($FORM{node}, $FORM{event}, $FORM{details});
	&eventAck(ack => $FORM{ack}, node => $FORM{node}, event => $FORM{event}, details => $FORM{details}); 
}

sub eventCheckQuery {
	my $result;
	&loadNodeDetails;

	my $node = $FORM{node};
	my $type = $NMIS::nodeTable{$node}{devicetype};
	my $role = $NMIS::nodeTable{$node}{role};

	loadEventStateNoLock;
	
	if ( $FORM{level} eq "" and $FORM{event} =~ /proactive/i ) { print "ERROR: no level requested for a proactive event.\n"; }
	if ( $role eq "" ) { $role = $FORM{role}; }
	if ( $type eq "" ) { $type = $FORM{type}; }

	$result = &eventExist($FORM{node}, $FORM{event}, $FORM{details});

	# see if the event exists, if yes close it.	
	if ( $result eq "true" ) {
		print "closing event\n";
		checkEvent(node => $FORM{node}, role => $role, type => $type, event => $FORM{event}, level => $FORM{level}, details => $FORM{details});
	}

	# No event exists to open one	
	if ( $result eq "false" ) {
		print "notify and create event\n";
		notify(node => $node, role => $role, type => $type, event => $FORM{event}, level => $FORM{level}, details => $FORM{details});
	}
	
	print "result=$result node=$FORM{node} event=$FORM{event} level=$FORM{level} details=$FORM{details}\n";
}

sub noquery {
	print <<EO_TEXT;
ERROR: no query requested
operations supported:
	Check if an event exists or not!
	http://server/$ENV{SCRIPT_NAME}?action=exist&node=<node>&event=<event>&details=<details>

	Check for and open an event if one exists! including notification!
	http://server/$ENV{SCRIPT_NAME}?action=check&node=<node>&event=<event>&level=<level>&details=<details>

	Acknowledge an Event!
	http://server/$ENV{SCRIPT_NAME}?action=ack&ack=<true|false>&node=<node>&event=<event>details=<details>
EO_TEXT
}

sub startTextPage {
	print "Content-type: text/plain\n\n";
}
