#!/usr/bin/perl
#
# $Id: view-event.pl,v 1.6 2006/09/28 09:32:03 decologne Exp $
#
#
#    view-event.pl - NMIS View Event Table Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    Written by Jan van Keulen
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
# 
use strict;
use web;
use NMIS;
use func;
use csv;
use Fcntl qw(:DEFAULT :flock);

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# Prefer to use CGI for html processing
use CGI qw(:standard);

# declare holder for CGI objects
use vars qw($q);
$q = new CGI; # This processes all parameters passed via GET and POST

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

my $scriptname = $ENV{SCRIPT_NAME};

my $my_data;

if($ENV{'REQUEST_METHOD'} eq "GET"){
   $my_data = $ENV{'QUERY_STRING'};
}
else {
   my $bytes_read = read(STDIN, $my_data, $ENV{'CONTENT_LENGTH'});
}

my %FORM;
my @depend = ();
my @msgroup = (); 
my @services = ();

my @pairs = split(/&/, $my_data);
foreach (@pairs) {
	my ($name, $value) = split(/=/, $_);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	# handle the event group multiselect box
	if ($name eq "depend") {
		push(@depend, $value);
	}
	if ($name eq "services") {
		push(@services, $value);
	}
	elsif ($name eq 'groups') {
        	push (@msgroup, $value);
	} 
	else {
		$FORM{$name} = $value;
	}	
}

# Allow program to use other configuration files
my $conf;
if ( $FORM{file} ne "" ) { $conf = $FORM{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }


# Before going any further, check to see if we must handle
# an authentication login or logout request

$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();
my $tb = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
	# check for username from other sources
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# verify access to this plugin
	$auth->CheckAccess($user, "view-event") or die "Attempted unauthorized access";

	if ( $FORM{type} eq 'logout' ) {
       	$auth->do_logout;
		exit 0;
	}
	# generate the cookie if $user->user is set
	if ( $user->user ) {
        push @cookies, $auth->generate_cookie($user->user);
        $headeropts{-cookie} = [@cookies];
	}
}

# Break the queary up for the names
my $node = $FORM{node};
my $event = $FORM{event};
my $details = $FORM{details};
my $role = $FORM{role};
my $type = $FORM{type};
my $level = $FORM{level};
my $func = $FORM{func};
my $hash = $FORM{hash};

my %events = ( 
		event => ["Generic Down", "Generic Up", "Interface Down", "Interface Up",
					"Node Down", "Node Reset", "Node Up", "Node Failover", "Proactive", "Proactive Closed",
					"RPS Fail", "SNMP Down", "SNMP Up"],
		role => ["core", "distribution", "access"],
		type => ["router", "switch", "server", "generic"],
		level => ["Normal", "Warning", "Major", "Critical", "Fatal"],
		node => [ sort keys %{{loadCSV($NMIS::config{Nodes_Table},$NMIS::config{Nodes_Key},"\t")}} ]
	);


my $nmis_url = "<a href=\"$NMIS::config{nmis}?file=$conf\"><img alt=\"NMIS Dash\" src=\"$NMIS::config{nmis_icon}\" border=\"0\"></a>";
my $back_url = "<a href=\"$ENV{HTTP_REFERER}\"><img alt=\"Back\" src=\"$NMIS::config{back_icon}\" border=\"0\"></a>";
my $help_url = "<a href=\"$NMIS::config{'<url_base>'}/view-event.pod.html\"><img alt=\"Help\" src=\"$NMIS::config{help_icon}\" border=\"0\"></a>";

# what shall we do
if ( $func eq "" ) {
	&displayEventList() ;
} elsif ( $func eq "delete" ) {
	&displayEvent(node => $node, event => $event, details => $details, delete => "true");
} elsif ( $func eq "dodelete" ) {
	&deleteEvent(hash => $hash);
	&displayEventList() ;
} elsif ( $func eq "database" ) {
	&displayEvent(node => $node, event => $event, details => $details);
} elsif ( $func eq "flow" ) {
	&displayEventFlow(node => $node, event => $event, details => $details, role => $role, type => $type);
}
exit;

#
# display the event flow request fields and the event database entries
#
sub displayEventList{

	my $header = "View Events";
	my $header2 = "$back_url$nmis_url$help_url NMIS Event processing";
	
	# Load the event table into the hash
	&loadEventStateNoLock;

	pageStart($header,"false",\%headeropts);
	print Tr(td({width=>"100%"}, &do_dash_banner($auth->Require, $user->user) ));
	tableEnd;
	cssTableStart("white");
	print "<tr><td class=\"view_header\" colspan=\"8\">$header2</td></tr>\n";

	# first print header and boxes for event flow analyzing
	print "<tr><td class=\"view_header\" colspan=\"8\">View Event Flow</td></tr>\n";

	my @headers = ( "Event", "Role", "Type", "Level", "Node", "Details","view" );
	rowStart;
		foreach my $field (@headers) {
			cssPrintCell("head","$field",1);
		}
	rowEnd;

	print "<form action=\"$ENV{SCRIPT_NAME}\" method=\"get\">\n";
	rowStart;
		foreach my $field (@headers) { 
			$field = lc $field;
			if ($field eq "view" ) {
				print "<td class=\"menugrey\"  width=\"8%\"><input type=\"submit\" value=\"GO\"></td>\n";
			} else {
				if ( exists $events{$field} ) {
					print "<td class=\"view\" width=\"12%\"><select  style=\"width:100%\" size=\"1\" name=\"$field\">\n";
					foreach my $option  ( @{$events{$field}} ) {
				 		print "<option value=\"$option\">$option</option>\n";
				 	}
					print "</select></td>\n";
				} else {
					print "<td class=\"view\" width=\"12%\"><input type=\"text\" style=\"width:100%\" size=\"1\" name=\"$field\"></td>\n";
				}
			}
		}
	rowEnd;
	print "<input type=\"hidden\" name=\"file\" value=\"$conf\">\n";
	print "<input type=\"hidden\" name=\"func\" value=\"flow\">\n";
	print "</form>\n";

	# second print a list of event database entries
	print "<tr><td class=\"view_header\" colspan=\"8\">View Event Database</td></tr>\n";
	my $flag = 0;
	foreach my $event_hash ( sort keys %NMIS::eventTable )  {
		my $start = $NMIS::eventTable{$event_hash}{startdate};
		my $date = returnDate($NMIS::eventTable{$event_hash}{startdate});
		my $time = returnTime($NMIS::eventTable{$event_hash}{startdate});
		my $node = $NMIS::eventTable{$event_hash}{node};
		my $event = $NMIS::eventTable{$event_hash}{event};
		my $details = $NMIS::eventTable{$event_hash}{details};
		my $line = "$date $time $node $event";
		$event =~ s/=/%3D/g ; # convert special signs
		$event =~ s/</&lt;/g ;
		$event =~ s/>/&gt;/g ;
		$event =~ s/ /%20/g ;
		$details =~ s/=/%3D/g ;
		$details =~ s/</&lt;/g ;
		$details =~ s/>/&gt;/g ;
		$details =~ s/ /%20/g ;
		$flag++;
		print <<EO_HTML;
	<tr>
	  <td class="view" colspan="5"><a href="$ENV{SCRIPT_NAME}?func=database&node=$node&amp;event=$event&amp;details=$details">$line</a></td>
          <td class="view" colspan="1"><a href=\"$NMIS::config{nmis}?file=$conf\&node=$node">see node</a></td>
	  <td class="view" colspan="1"><a href="$ENV{SCRIPT_NAME}?func=delete&node=$node&amp;event=$event&amp;details=$details">delete</a></td>
	</tr>
EO_HTML
	}
	if (!$flag) { printRow(1,"info","no entries available");}
	tableEnd;
	pageEnd;
}

#
# display one entry of the event database
#
sub	displayEvent {
	my %args = @_;
	my $node = $args{node};
	my $event = $args{event};
	my $details = $args{details};
	my $delete = $args{delete};

	my $header = "View Event database - $node";
	my $header2 = "$back_url$nmis_url$help_url NMIS Event Database for node $node";

	pageStart($header,"false",\%headeropts);
	print Tr(td({width=>"100%"}, &do_dash_banner($auth->Require, $user->user) ));
	tableEnd;
	cssTableStart("plain");

	print "<tr><td class=\"view_header\" colspan=\"6\">$header2</td></tr>\n";
	
	&displayEventItems(node => $node, event => $event, details => $details, delete => $delete);

	tableEnd;
	pageEnd;
}

#
# display the event flow using the event policy table and the event escalation table
#
sub displayEventFlow {
	my %args = @_;
	my $node = $args{node};
	my $event = $args{event};
	my $details = $args{details};
	my $role = $args{role};
	my $type = $args{type};
	my $pol_event;
	my %event_result;
	my $contact;
	my $target;

	my $header = "View Event Flow";
	my $header2 = "$back_url$nmis_url$help_url NMIS Event Flow";

	pageStart($header,"false",\%headeropts);
	print Tr(td({width=>"100%"}, &do_dash_banner($auth->Require, $user->user) ));
	tableEnd;
	cssTableStart("plain");

	print "<tr><td class=\"view_header\" colspan=\"6\">$header2</td></tr>\n";

	print "<tr><td class=\"head\" colspan=\"6\">Event Policy</td></tr>\n";

	# Get the event policy and the rest is easy.
	if ( 	$event =~ /Proactive.*Closed/ ) { $pol_event = "Proactive Closed"; }
	elsif ( $event =~ /Proactive/ ) 	{ $pol_event = "Proactive"; }
	elsif ( $event =~ /down/i and $event !~ /SNMP|Node|Interface/ ) { 
		$pol_event = "Generic Down";
	}
	elsif ( $event =~ /up/i and $event !~ /SNMP|Node|Interface/ ) { 
		$pol_event = "Generic Up";
	}
	else 	{ $pol_event = $event; }

	printRow(1,"event",$event);
	printRow(1,"role",$role);
	printRow(1,"type",$type);
	printRow(1,"level",$level);

	%event_result = eventPolicy(event => $pol_event, role => $role, type => $type, level => $level);

	my $notify = $event_result{notify};
	my $mail = $event_result{mail};
	my $pager = $event_result{pager};
	$level = $event_result{level};
	my $log = $event_result{log};
	if ( $notify eq "" or $log eq "" ) { 
		printRow(2,"status","no match found in Event Policy table","error");
		return;
	}

	if ($log eq "true") {
		printRow(2,"log","event will be logged in event log");
	}

	if ( $mail eq "true" ) {
		### AS 1/4/2001 - set target to be whatever the sysContact email is.
		my %contact_table = loadCSV($NMIS::config{Contacts_Table},$NMIS::config{Contacts_Key},"\t");
		$contact = $NMIS::systemTable{sysContact};
		$target = $contact_table{'$contact'}{Email};
		# quick test to make sure the the target is never blank.
		if ( $target eq "" and $contact ne "default" ) {
			$target = $contact_table{default}{Email};
		} else { $target = $contact_table{default}{Email}; }
		printRow(2,"email",$target);
	}

	if ( $notify eq "true" and $event !~ /Proactive.*Closed/ ) {	
		# Push the event onto the event table.
		printRow(2,"notify","event will be stored in event database");
		print "<tr><td class=\"head\" colspan=\"6\">Event Escalation</td></tr>\n";
		$details = " " if ($details eq "");
		&displayEventItems(node => $node, event => $event, level => $level, details => $details, flag =>"true");
	}


	tableEnd;
	pageEnd;

}

#
# display the items of a event using the escalation table
#
sub displayEventItems {
	my %args = @_;
	my $node = $args{node};
	my $event = $args{event};
	my $details = $args{details};
	my $level = $args{level};
	my $flag = $args{flag};
	my $delete = $args{delete};

	my $event_hash;
	my $time;
	my $date;
	my $line;
	my %contact_table;
	my %esc_table;
	my %keyhash;
	my $esc_key;
	my $field;
	my $target;
	my @x;
	my $contact;

	my $colspan = 6;

	# load Contact table into %contact_table
	%contact_table = &loadCSV($NMIS::config{Contacts_Table},$NMIS::config{Contacts_Key},"\t");
	# load the escalation policy table into %esc_table
	%esc_table = &loadCSVarray($NMIS::config{Escalation_Table},"Group:Role:Type:Event","\t");
	# load Node table into %nodeTable
	&loadNodeDetails();
	# Load the event table into %eventTable
	&loadEventStateNoLock;

	# Lets try node_event_details!!
	$event_hash = &eventHash($node, $event, $details);

	if ($flag eq "true" ) {
		# generate entry for display event flow
		$NMIS::eventTable{$event_hash}{current} = "true";
		$NMIS::eventTable{$event_hash}{startdate} = time;
		$NMIS::eventTable{$event_hash}{lastchange} = time;
		$NMIS::eventTable{$event_hash}{node} = $node;
		$NMIS::eventTable{$event_hash}{event} = $event;
		$NMIS::eventTable{$event_hash}{event_level} = $level;
		$NMIS::eventTable{$event_hash}{details} = $details;
		$NMIS::eventTable{$event_hash}{ack} = "true";
		$NMIS::eventTable{$event_hash}{escalate} = -1;
		$NMIS::eventTable{$event_hash}{notify} = "false";
	}

	# note - all sent to lowercase here to get a match - as loadCVS sets all to lc
	loadSystemFile($NMIS::eventTable{$event_hash}{node}); # into systemTable
	my $group = lc($NMIS::nodeTable{$NMIS::eventTable{$event_hash}{node}}{group}); # group of node
	my $role = lc($NMIS::systemTable{roleType}); # role of node
	my $type = lc($NMIS::systemTable{nodeType}); # type of node
	my $escalate = $NMIS::eventTable{$event_hash}{escalate};	# save this as a flag

	# set the current event time
	my $outage_time = time - $NMIS::eventTable{$event_hash}{startdate};

	$date = returnDate($NMIS::eventTable{$event_hash}{startdate});
	$time = returnTime($NMIS::eventTable{$event_hash}{startdate});
	printRow(1,"start time","$date $time");

	$date = returnDate($NMIS::eventTable{$event_hash}{lastchange});
	$time = returnTime($NMIS::eventTable{$event_hash}{lastchange});
	printRow(1,"last change","$date $time");

	printRow(1,"node",$NMIS::eventTable{$event_hash}{node});

	# info
	my $ack_str = ($NMIS::eventTable{$event_hash}{ack} eq "true") ?  ", event waiting for activating" : ", event active"; 
	my $esc_str = ($NMIS::eventTable{$event_hash}{escalate} eq -1) ? ", no level set" : "";
	my $ntf_str = ($NMIS::eventTable{$event_hash}{notify} eq "false") ? ", no UP notify sending" : ", UP notify entry in Escalation";

	printRow(1,"event",$NMIS::eventTable{$event_hash}{event});
	printRow(1,"event level",$NMIS::eventTable{$event_hash}{event_level});
	printRow(1,"details",$NMIS::eventTable{$event_hash}{details});
	printRow(1,"acknowledge",$NMIS::eventTable{$event_hash}{ack}.$ack_str);
	printRow(1,"escalate","level $NMIS::eventTable{$event_hash}{escalate} $esc_str");
	printRow(1,"notify","$NMIS::eventTable{$event_hash}{notify} $ntf_str");

	if ( &outageCheck($NMIS::eventTable{$event_hash}{$node},time) eq "true" and $NMIS::eventTable{$event_hash}{ack} eq "false" ) {
		# check outage
		printRow(1,"status","node at outage");
	}

	if ( exists $NMIS::nodeTable{$NMIS::eventTable{$event_hash}{node}}{depend} ) {
		# we have list of nodes that this node depends on in $NMIS::nodeTable{$runnode}{depend}
		# if any of those have a current Node Down alarm, then lets just move on with a debug message
		# should we log that we have done this - maybe not....

		foreach my $node_depend ( split /,/ , lc($NMIS::nodeTable{$NMIS::eventTable{$event_hash}{node}}{depend}) ) {
			next if $node_depend eq "N/A" ;		# default setting
			next if $node_depend eq $NMIS::eventTable{$event_hash}{node};	# remove the catch22 of self dependancy.
			if ( &eventExist($node_depend, "Node Down", "Ping failed" ) eq "true" ) {
				printRow(1,"status","dependant $node_depend is reported as down");
				return;
			}
		}
	}

	# checking that we have a valid node -the node may have been deleted.
	if ( !exists $NMIS::nodeTable{$NMIS::eventTable{$event_hash}{node}}{node} ) {
		printRow(1,"status","node deleted");
		return;
	}


	# trim the (proactive) event down to the first 4 keywords or less.
	$event = "";
	my $i = 0;
	foreach my $index ( split /( )/ , lc($NMIS::eventTable{$event_hash}{event}) ) {		# the () will pull the spaces as well into the list, handy !
		$event .= $index;
		last if $i++ == 6;				# max of 4 splits, with no trailing space.
	}

	# Escalation_Key=Group:Role:Type:Event
	my @keylist = (
						$group."_".$role."_".$type."_".$event ,
						$group."_".$role."_".$type."_"."default",
						$group."_".$role."_"."default"."_".$event ,
						$group."_".$role."_"."default"."_"."default",
						$group."_"."default"."_".$type."_".$event ,
						$group."_"."default"."_".$type."_"."default",
						$group."_"."default"."_"."default"."_".$event ,
						$group."_"."default"."_"."default"."_"."default",
						"default"."_".$role."_".$type."_".$event ,
						"default"."_".$role."_".$type."_"."default",
						"default"."_".$role."_"."default"."_".$event ,
						"default"."_".$role."_"."default"."_"."default",
						"default"."_"."default"."_".$type."_".$event ,
						"default"."_"."default"."_".$type."_"."default",
						"default"."_"."default"."_"."default"."_".$event ,
						"default"."_"."default"."_"."default"."_"."default"
		);

	# lets allow all possible keys to match !
	# so one event could match two or more escalation rules
	# can have specific notifies to one group, and a 'catch all' to manager for example.
	my $k;
	my %keyhash;
	my $flag = 0;
	foreach ( @keylist ) {
		if  ( exists $esc_table{$_} and defined ($k=testNode($event_hash, $_)) ) { $keyhash{$_} = $k; $flag++; }
	}

	printRow(1,"escalation rule",$group."_".$role."_".$type."_".$event);
	if (!$flag) {
		printRow(1,"status","no match found in Event Escalation table","error");
		return;
	}

	foreach $esc_key ( keys %keyhash ) {
		# have a matching escalation record for the hash key, and an index into the array.
		$k = $keyhash{$esc_key};	# readability	
			
		# display the escalation entry
		my @field = split /_/, $esc_key;
		printRow(2,"group",$field[0]);
		printRow(2,"role",$field[1]);
		printRow(2,"type",$field[2]);
		printRow(2,"event",$field[3]);
		printRow(2,"message","Escalation $NMIS::eventTable{$event_hash}{node} $NMIS::eventTable{$event_hash}{event_level} $NMIS::eventTable{$event_hash}{event}\n $NMIS::eventTable{$event_hash}{details}");
		my $not_str = ($esc_table{$esc_key}{UpNotify}[$k] eq "true") ? ", an UP event notification will be sent to the list of Contacts who received a \'down\' event notification" : "";
		printRow(2,"upnotify","$esc_table{$esc_key}{UpNotify}[$k] $not_str");


		for my $lvl (0..10) {
			# get the string of type email:contact1:contact2,netsend:contact1:contact2,pager:contact1:contact2,email:sysContact
			$level = lc ($esc_table{$esc_key}{'Level'.$lvl}[$k]);
			my $escalate = "escalate".$lvl;
			if ( $level ne "" ) {
				printRow(2,"level$lvl",$level);
				$date = returnDate($NMIS::eventTable{$event_hash}{startdate}+$NMIS::config{$escalate});
				$time = returnTime($NMIS::eventTable{$event_hash}{startdate}+$NMIS::config{$escalate});
				printRow(3,"time","$date $time");
				# Now we have a string, check for multiple notify types
				foreach $field ( split "," , $level ) {
					$target = "";
					@x = split /:/ , $field;
					$type = shift @x;			# netsend, email, or pager ?
					if ( $type eq "email" ) {
						my $contact_cnt = 0;
						foreach $contact (@x) {
							# if sysContact, use device syscontact as key into the contacts table hash
							if ( $contact eq "syscontact" ) {
								my $contact_p = $contact;
								$contact = $NMIS::systemTable{sysContact};
								printRow(3,"contact","$contact_p replaced by $contact");
							}
							if ( exists $contact_table{$contact} ) {
								$contact_cnt++;
								printRow(3,"contact",$contact);
								printRowDutyTime(4,$contact);
								printRowTimeZone(5,$contact);
								printRowEmail(4,$contact);
								### cologne, pass on
								&printPassOn($contact,1);
								###
							} else {
								printRow(3,"contact","$contact not found in Contacts","error");
							}
						}

						if ( $contact_cnt eq 0 ) { 
							$target = $contact_table{default}{Email};
							$contact = "default";
						}
						if ($target) {
							printRow(3,"contact",$contact);
							printRowDutyTime(4,$contact);
							printRowTimeZone(5,$contact);
							printRowEmail(4,$contact);
						}
					} # email
					if ( $type eq "ccopy" ) {
						my $contact_cnt = 0;
						foreach $contact (@x) {
							# if sysContact, use device syscontact as key into the contacts table hash
							if ( $contact eq "syscontact" ) {
								my $contact_p = $contact;
								$contact = $NMIS::systemTable{sysContact};
								printRow(3,"contact","$contact_p replaced by $contact");
							}
							if ( exists $contact_table{$contact} ) {
								$contact_cnt++;
								printRow(3,"contact",$contact);
								printRowDutyTime(4,$contact);
								printRowTimeZone(5,$contact);
								printRowEmail(4,$contact,"email cc");
								### cologne, pass on
								&printPassOn($contact,1);
								###
							} else {
								printRow(3,"contact","$contact not found in Contacts","error");
							}
						}

						if ( $contact_cnt eq 0 ) { 
							$target = $contact_table{default}{Email};
							$contact = "default";
						}
						if ($target) {
							printRow(3,"contact",$contact);
							printRowDutyTime(4,$contact);
							printRowTimeZone(5,$contact);
							printRowEmail(4,$contact,"email cc");
						}
					} # ccopy
					if ( $type eq "netsend" ) {
						foreach $contact ( @x ) {
							printRow(3,"contact",$contact);
							printRow(4,"netsend","message");
						} #foreach
					} # end netsend
					if ( $type =~ /page./i ) {
						my $contact_cnt = 0;
						foreach $contact (@x) {
							# if sysContact, use device syscontact as key into the contacts table hash
							if ( $contact eq "syscontact" ) {
								my $contact_p = $contact;
								$contact = $NMIS::systemTable{sysContact};
								printRow(3,"contact","$contact_p replaced by $contact");
							}
							if ( exists $contact_table{$contact} ) {
								$contact_cnt++;
								printRow(3,"contact",$contact);			
								printRowDutyTime(4,$contact);
								printRowTimeZone(5,$contact);
								printRowPager(4,$contact);
								### cologne, pass on
								&printPassOn($contact,1);
								###
							} else {
								printRow(3,"contact","$contact not found in Contacts","error");
							}
						}
						if ( $contact_cnt eq 0 ) { 
							$target = $contact_table{default}{Pager};
							$contact = "default";
						}
						if ($target) {
							printRow(3,"contact",$contact);
							printRowDutyTime(4,$contact);
							printRowTimeZone(5,$contact);
							printRowPager(4,$contact);
						}
					} # end pager
				} # end foreach
			} # end if
		} # end for
	} # end foreach

	if ($delete ne "") {
		$event_hash =~ s/=/%3D/g ; # convert special signs
		$event_hash =~ s/</&lt;/g ;
		$event_hash =~ s/>/&gt;/g ;
		$event_hash =~ s/ /%20/g ;
		print <<EO_HTML;
		<tr><td class="head" >Delete this Event ? </td>
			<td class="view" colspan="1"><a href="$ENV{SCRIPT_NAME}?func=dodelete&hash=$event_hash">&nbsp;DELETE</a></td></tr>
EO_HTML
	}
	#=====================================================

	# parse the HoA looking for a match against the regex expression in Escalation Table:Event_Node and Event_Details fields
	# can assume that array is linear for both these fields.
	sub testNode {
		my $hash = shift;
		my $esc_key = shift;
		foreach my $i ( 0 .. $#{ $esc_table{$esc_key}{Event_Node} } ) {
			if ( $NMIS::eventTable{$hash}{node} =~ /$esc_table{$esc_key}{Event_Node}[$i]/ and $NMIS::eventTable{$hash}{details} =~ /$esc_table{$esc_key}{Event_Details}[$i]/ ) { 
				return $i;
			}
		}
		return undef;
	}

	#=====================================================

	# in column PassOn may be defined Contacts. With dutytime specified there are special possibilities.

	sub printPassOn {
		my $contact = shift;
		my $passon_lvl = shift;

		if ( exists $contact_table{$contact}{PassOn} and $contact_table{$contact}{PassOn} ne ""){
			if ($passon_lvl < 10) {
				my @passon =  split /:/, lc $contact_table{$contact}{PassOn}; # pass on an other contact
				foreach my $contact (@passon) {
					$contact = lc $contact;
					if ( exists $contact_table{$contact} ) {
						printRow(4,"pass on - $passon_lvl",$contact);
						printRowDutyTime(5,$contact);
						printRowTimeZone(5,$contact);
						printRowEmail(5,$contact);
					} else {
						printRow(4,"contact","$contact not found in Contacts","error");
					}
					printPassOn($contact,$passon_lvl+1); # walk
				}
			} else {
				printRow(4,"pass on","loop detect","error");
			}
		}
	}

	#=====================================================

	# print a table row

	sub printRow {
		my $colhead = shift; # position in the row
		my $headtxt = shift; # text of head
		my $datatxt = shift; # text of info
		my $error = shift;   # optional error sign

		my $colfront = $colhead - 1;
		my $colback = $colspan - $colhead;

		my $fill = ($colhead gt 1) ? "<td class=\"head\" colspan=\"$colfront\">&nbsp;</td>" : "" ;

		my $class = ($error ne "") ? $error : "view" ;

		print <<EO_HTML;
			<tr>$fill<td class="head" >$headtxt</td>
			<td class="$class" colspan="$colback">&nbsp;$datatxt</td></tr>
EO_HTML
	}

	#=====================================================

	sub printRowEmail {
		my $head = shift;
		my $contact = shift;
		my $mail = shift;
		$mail = ($mail ne "") ? $mail : "email";

		printRow($head,$mail,($contact_table{$contact}{Email} ne "") ? $contact_table{$contact}{Email} : "no address");

	}
	#=====================================================

	sub printRowDutyTime{
		my $head = shift;
		my $contact = shift;

		if ( $contact_table{$contact}{DutyTime} ne "" ) {
			if (checkDutyTime($contact_table{$contact}{DutyTime})) {
				printRow($head,"dutytime",$contact_table{$contact}{DutyTime});
			} else {
				printRow($head,"dutytime",$contact_table{$contact}{DutyTime},"error");
			}
		} else {
			printRow($head,"dutytime","full time");
		}

	}
	#=====================================================

	sub printRowTimeZone{
		my $head = shift;
		my $contact = shift;

		if ($contact_table{$contact}{TimeZone} ne 0) { printRow($head,"timezone","$contact_table{$contact}{TimeZone} hour");}

	}
	#=====================================================

	sub printRowPager{
		my $head = shift;
		my $contact = shift;

		printRow($head,"pager",($contact_table{$contact}{Pager} ne "") ? $contact_table{$contact}{Pager} : "no number");

	}
	#=====================================================

	# test the dutytime on syntax
	# return true if OK 
	sub checkDutyTime {
		my $dutytime = shift;
		my $today;
		my $days;
		my $start_time;
		my $finish_time;

		if ($dutytime) {
			( $start_time, $finish_time, $days) = split /:/, $dutytime, 3;
			my $num = length($days)/3 ;
			my $cnt =  $days =~ s/Sun|Mon|Tue|Wed|Thu|Fri|Sat//ig ;
			if ( $cnt eq $num and ($start_time =~ /(\d+)/) and ($finish_time =~ /(\d+)/) ) {
				return 1;
			} else {
				return 0;
			}
		}
	}
}

sub deleteEvent {
	my %args = @_;
	my $event_hash = $args{hash};

	# Load the event table into %eventTable
	my $handle = &loadEventStateLock;

	$NMIS::eventTable{$event_hash}{node} = "" ;

	writeEventStateLock($handle);
}
