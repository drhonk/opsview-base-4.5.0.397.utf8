#!/usr/bin/perl
#
# $Id: metrics.pl,v 1.4 2006/10/02 18:22:49 decologne Exp $
#
#
#    metrics.pl - NMIS CGI Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl";
# 
#****** Shouldn't be anything else to customise below here *******************

use Time::ParseDate; 
use strict;
use NMIS;
use func;
use csv;


# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

 
# This reads in the information sent when the user pressed Submit
my %FORM = getCGIForm($ENV{'QUERY_STRING'});
my $scriptname = $ENV{SCRIPT_NAME};

# Break the queary up for the names
my $size = $FORM{size};
my $size2;

# Allow program to use other configuration files
my $conf;
if ( $FORM{file} ne "" ) { $conf = $FORM{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

# Before going any further, check to see if we must handle
# an authentication login or logout request
$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();
my $tb = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
	# check for username from other sources
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# verify access to this command/tool bar/button
	#
	# CheckAccess will throw up a web page and stop if access is not allowed
	$auth->CheckAccess($user, "metrics") or die "Attempted unauthorized access";

	# generate the cookie if $auth->user is set
	#
	push @cookies, $auth->generate_cookie($user->user);
	$headeropts{-cookie} = [@cookies];
}



if ( $FORM{size} eq "" ) { $size = "medium"; }
if ( $size eq "tiny" ) { $size2 = "small"; }
elsif ( $size eq "small" ) { $size2 = "medium"; }
elsif ( $size eq "medium" ) { $size2 = "big"; }
elsif ( $size eq "big" ) { $size2 = "large"; }
elsif ( $size eq "large" ) { $size2 = "large"; }

my $version = "1.01";

# load the files we need....

loadNodeDetails;
loadEventStateNoLock;
loadEventStateSlave;

my $title = "NMIS Metrics";
&drawMetrics;

exit 0;

sub drawMetrics {
	my $net_status;
	my $net_color;
	my $group_status;
	my $net_icon;

	my $group = shift;
	my $start_time = shift;
	my $end_time = shift;
	my %summaryHash;
	my %oldSummaryHash;
	my $groupStatus;
	my %map_data;
	my $div;
	my $col; 
	my $row;
	
	if ( $start_time eq "" ) { $start_time = "-8 hours"; }
	if ( $end_time eq "" ) { $end_time = time; }
	%map_data = loadCSV($NMIS::config{Map_Table},$NMIS::config{Map_Key});
	$net_status = overallNodeStatus($group);
	$net_color = eventColor($net_status);

	print <<EOHTML;
Content-type: text/html\n
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>$title</title>
<META HTTP-EQUIV=Refresh CONTENT=300>
<STYLE TYPE="text/css">
<!--
body {
	background-color : $net_color;
	color : black;
	font-family : Arial, Helv;
	font-size : xx-small;
	font-style : normal;
	font-variant : normal;
	text-decoration : none;
	margin: 5px 5px 5px 5px;
}
.button {
	color: black;
	background: #aaaaaa;
	text-align: center;
	border : thin none black;
}
.tiny { font-size : xx-small; }
.small { font-size : x-small; }
.medium { font-size : medium; }
.big { font-size : x-large; }
.large { font-size : xx-large; }
-->
</STYLE>
</HEAD>
<BODY>

EOHTML

	#Draw a summary table.
	%summaryHash = &getGroupSummary("",$start_time,$end_time);
	%oldSummaryHash = &getGroupSummary("","-16 hours","-8 hours");
	
	$oldSummaryHash{average}{metric_diff} = sprintf("%.3f",$summaryHash{average}{metric} - $oldSummaryHash{average}{metric});
	# Arrow Icons for all the bits!
	if ( $oldSummaryHash{average}{metric} <= $summaryHash{average}{metric} ) { $summaryHash{average}{metric_icon} = "<img alt=\"Up\" src=\"$NMIS::config{arrow_up}\" border=\"0\" width=\"11\" height=\"10\">"; }
	else { $summaryHash{average}{metric_icon} = "<img alt=\"Down\" src=\"$NMIS::config{arrow_down}\" border=\"0\" width=\"11\" height=\"10\">"; }
	if ( $oldSummaryHash{average}{reachable} <= $summaryHash{average}{reachable} ) { $summaryHash{average}{reachable_icon} = "<img alt=\"Up\" src=\"$NMIS::config{arrow_up}\" border=\"0\" width=\"11\" height=\"10\">"; }
	else { $summaryHash{average}{reachable_icon} = "<img alt=\"Down\" src=\"$NMIS::config{arrow_down}\" border=\"0\" width=\"11\" height=\"10\">"; }
	if ( $oldSummaryHash{average}{available} <= $summaryHash{average}{available} ) { $summaryHash{average}{available_icon} = "<img alt=\"Up\" src=\"$NMIS::config{arrow_up}\" border=\"0\" width=\"11\" height=\"10\">"; }
	else { $summaryHash{average}{available_icon} = "<img alt=\"Down\" src=\"$NMIS::config{arrow_down}\" border=\"0\" width=\"11\" height=\"10\">"; }
	if ( $oldSummaryHash{average}{health} <= $summaryHash{average}{health} ) { $summaryHash{average}{health_icon} = "<img alt=\"Up\" src=\"$NMIS::config{arrow_up}\" border=\"0\" width=\"11\" height=\"10\">"; }
	else { $summaryHash{average}{health_icon} = "<img alt=\"Down\" src=\"$NMIS::config{arrow_down}\" border=\"0\" width=\"11\" height=\"10\">"; }
	if ( $oldSummaryHash{average}{response} <= $summaryHash{average}{response} ) { $summaryHash{average}{response_icon} = "<img alt=\"Up\" src=\"$NMIS::config{arrow_up}\" border=\"0\" width=\"11\" height=\"10\">"; }
	else { $summaryHash{average}{response_icon} = "<img alt=\"Down\" src=\"$NMIS::config{arrow_down}\" border=\"0\" width=\"11\" height=\"10\">"; }

	print <<EOHTML;
<DIV ID="Summary">
<table bgcolor=white>
<tr class="button"  bgcolor="$net_color"><td class="$size2" colspan="2" align="center"><a href="$NMIS::config{nmis}">Network Metrics</a></td></tr>
<tr class="$size2" bgcolor="$summaryHash{average}{metric_color}"><td colspan="2" align="center">$summaryHash{average}{metric} $summaryHash{average}{metric_icon}</td></tr>
<tr class="$size" bgcolor="$summaryHash{average}{metric_color}"><td>was $oldSummaryHash{average}{metric}</td><td>diff $oldSummaryHash{average}{metric_diff}</td></tr>
<tr class="$size" bgcolor="$summaryHash{average}{reachable_color}"><td>reachable</td><td>$summaryHash{average}{reachable} $summaryHash{average}{reachable_icon}</td></tr>
<tr class="$size" bgcolor="$summaryHash{average}{available_color}"><td>available</td><td>$summaryHash{average}{available} $summaryHash{average}{available_icon}</td></tr>
<tr class="$size" bgcolor="$summaryHash{average}{health_color}"><td>health</td><td>$summaryHash{average}{health} $summaryHash{average}{health_icon}</td></tr>
<tr class="$size" bgcolor="$summaryHash{average}{response_color}"><td>response</td><td>$summaryHash{average}{response} ms $summaryHash{average}{response_icon}</td></tr>
<tr class="$size" bgcolor="$net_color"><td>Status</td><td>$net_status</td></tr>
<tr class="$size2" bgcolor="$net_color"><td class="$size" colspan="2" align="center"><a href="$NMIS::config{nmis}">NMIS</a></td></tr>
</table>
</DIV>
</BODY>
</HTML>
EOHTML
}
