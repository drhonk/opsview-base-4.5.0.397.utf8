#!/usr/bin/perl
#
#
#    rttmon.pl - NMIS RTT Monitor Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    written by Cologne 2006
#	 version 1.0
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";

# the following is a workaround for bad-behaved rrdtool installations.
use lib "/usr/local/rrdtool/lib/perl";

# 
use Time::ParseDate;
use RRDs;
use strict;
use NMIS;
use func;
use csv;
use rrdfunc;
use Fcntl qw(:DEFAULT :flock);
use Data::Dumper;
$Data::Dumper::Indent = 1;

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

# use CGI for html processing
use CGI qw/:standard *table *Tr *td *Select *form -no_xhtml /;

# declare holder for CGI objects
use vars qw($q);
$q = new CGI; # Processes all parameters passed via GET 

# Allow program to use other configuration files
my $conf;
if ( $q->param('file') ne "" ) { $conf = $q->param('file'); }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

# Before going any further, check to see if we must handle
# an authentication login or logout request

$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# verify access to this plugin
	$auth->CheckAccess($user, "rttmon") or die "Attempted unauthorized access";

	# logout ?
	if ( $q->param('type') eq 'logout' ) {
       	$auth->do_logout;
		exit 0;
	}
	# generate the cookie if $user->user is set
	if ( $user->user ) {
        push @cookies, $auth->generate_cookie($user->user);
        $headeropts{-cookie} = [@cookies];
	}
}


# Break the queary up for the names
my $func = lc $q->param('func');
my $pnode = $q->param('pnode');
my $ppnode = $q->param('ppnode');
my $pcom = $q->param('pcom');
my $rnode = $q->param('rnode');
my $prnode = $q->param('prnode');
my $rcom = $q->param('rcom');
my $saddr = $q->param('saddr');
my $raddr = $q->param('raddr');
my $url = $q->param('url');
my $dport = $q->param('dport');
my $history = $q->param('history');
my $pnodechart = $q->param('pnodechart');
my $type = $q->param('type');
my $graph = $q->param('graph');
my $debug = $q->param('debug');
my $start = $q->param('start') ;
my $end = $q->param('end');
my $date_start = $q->param('date_start');
my $date_end = $q->param('date_end');
my $graphx = $q->param('graph.x');
my $graphy = $q->param('graph.y');
my $item = $q->param('item');
my $view = $q->param('view');
my $entry = $q->param('entry');
my $optype = $q->param('optype');
my $poptype = $q->param('poptype');
my $attr = $q->param('attr');
my $freq = $q->param('freq');
my $lsr = $q->param('lsr');
my $owner = $q->param('owner');
my $dsize = $q->param('dsize');
my $tout = $q->param('tout');
my $tos = $q->param('tos');
my $vrfy = $q->param('vrfy');
my $key = $q->param('key');
my $intvl = $q->param('intvl');
my $pkts = $q->param('pkts');
my $deldb = $q->param('deldb');
my $tport = $q->param('tport');
my $tas = $q->param('tas');
my $codec = $q->param('codec');
my $factor = $q->param('facor');
my $vrf = $q->param('vrf');

my $dump_data = Dump;
$q->delete_all();
my $msg; # common message

my ($graphret, $xs, $ys, $ERROR);
my $width = 600; # of rtt chart
my $height = 250; # of rtt chart

my $nmis_url = a({href=>"$NMIS::config{nmis}?file=$conf"},img({alt=>"NMIS Dash", src=>"$NMIS::config{nmis_icon}", border=>"0"}));
my $back_url = a({href=>referer()},img({alt=>"Back", src=>"$NMIS::config{back_icon}", border=>"0"}));
my $help_url = a({href=>"$NMIS::config{'<url_base>'}/rttmon.pod.html"},img({alt=>"Help", src=>"$NMIS::config{help_icon}", border=>"0"}));

my %operation = (
	'echo'=>{'responder'=>'router,server',
			'attr'=>'frequence,request-data-size,timeout,tos,verify-data,source-addr,vrf',
			'frequence'=>[5,10,30,60,120,300,600],
			'default'=>{ 'freq'=>30,'tout'=>'2','dsize'=>'28' }
			 },
	'pathEcho'=>{'responder'=>'router,server',
			'attr'=>'frequence,timeout,tos,source-addr,vrf',
			'frequence'=>[60,120,300,600],
			'default'=>{'freq'=>300,'tout'=>'5','dsize'=>'28' }
			 },
	'tcpConnect'=>{'responder'=>'router,server,dport,community,vrf',
			'attr'=>'frequence,timeout,tos',
			'frequence'=>[60,120,300,600],
			'default'=>{'freq'=>30,'tout'=>'5' }
			 },
	'udpEcho'=>{'responder'=>'router,server,dport,community',
			'attr'=>'frequence,request-data-size,timeout,tos,source-addr,vrf',
			'frequence'=>[5,10,30,60],
			'default'=>{'freq'=>30,'tout'=>'5','dsize'=>'16','dport'=>'100'}
			},
	'jitter'=>{'responder'=>'router,snmp,community',
			'attr'=>'frequence,request-data-size,timeout,tos,interval,num-pkts,tport,source-addr,vrf',
			'frequence'=>[5,10,30,60],
			'default'=>{'freq'=>'30','tport'=>'16384','tout'=>'5','dsize'=>'32','pkts'=>'100','intvl'=>'20'}
			},
	'jitter-voip'=>{'responder'=>'router,snmp,community',
			'attr'=>'frequence,request-data-size,timeout,tos,interval,num-pkts,tport,codec,factor,source-addr,vrf',
			'frequence'=>[5,10,30,60],
			'default'=>{'freq'=>'30','tport'=>'16384','tout'=>'5','dsize'=>'32','pkts'=>'100','intvl'=>'20',
				'codec'=>'1','factor'=>'0'}
			},
	'http'=>{'responder'=>'server',
			'attr'=>'frequence,timeout,tos',
			'frequence'=>[5,10,30,60],
			'default'=>{'freq'=>30,'tout'=>'5'}
			},
	'dns'=>{'responder'=>'server',
			'attr'=>'frequence,timeout,tas',
			'frequence'=>[5,10,30,60],
			'default'=>{'freq'=>30,'tout'=>'5','tas'=>'www.cisco.com'}
			},
	'dhcp'=>{'responder'=>'server',
			'attr'=>'frequence,timeout',
			'frequence'=>[10,30,60],
			'default'=>{'freq'=>30,'tout'=>'5'}
			}
	);
$operation{'echo-stats'} = $operation{'echo'};
$operation{'dhcp-stats'} = $operation{'dhcp'};
$operation{'dns-stats'} = $operation{'dns'};
$operation{'jitter-stats'} = $operation{'jitter'};
$operation{'jitter-voip-stats'} = $operation{'jitter-voip'};
$operation{'http-stats'} = $operation{'http'};
$operation{'pathEcho-stats'} = $operation{'pathEcho'};
$operation{'udpEcho-stats'} = $operation{'udpEcho'};
$operation{'tcpConnect-stats'} = $operation{'tcpConnect'};


# get RTTcfg from /var
my %RTTcfg = readVartoHash("rttmoncfg");

# get config database values if view graph is active
if ($view eq "true" and $key ne "") {
	$pnode = $RTTcfg{$key}{pnode};
	$optype = $RTTcfg{$key}{optype};
	$saddr = $RTTcfg{$key}{saddr};
	$rnode = $RTTcfg{$key}{rnode};
	$raddr = $RTTcfg{$key}{raddr};
	$dport = $RTTcfg{$key}{dport};
	$tout = $RTTcfg{$key}{timeout};
	$history = $RTTcfg{$key}{history};
	$freq = $RTTcfg{$key}{frequence};
	$lsr = $RTTcfg{$key}{lsrpath};
	$dsize = $RTTcfg{$key}{reqdatasize};
	$tos = $RTTcfg{$key}{tos};
	$intvl = $RTTcfg{$key}{interval};
	$pkts = $RTTcfg{$key}{numpkts};
	$tport = $RTTcfg{$key}{tport};
	$codec = $RTTcfg{$key}{codec};
	$factor = $RTTcfg{$key}{factor};
	$vrf = $RTTcfg{$key}{vrf};
	$url = $RTTcfg{$key}{url};
}

# define hash key
my $tnode = ($rnode eq "other") ? $raddr : $rnode;
my $dest = ($optype =~ /http/ and $url =~ m:.*//(.*)(/|$).*: ) ? $1 : $tnode ;
my $nno = "${pnode}_${dest}_${optype}"; # key for hash table %RTTcfg

# store typed community
if ($ppnode ne $pnode) { $pcom = $RTTcfg{$pnode}{community};}
if ($prnode ne $rnode) { $rcom = $RTTcfg{$rnode}{community};}
if ($pcom ne "*********" and $pcom ne "" and $pnode ne "") {
	$RTTcfg{$pnode}{community} = $pcom;
	$pcom = "*********";
	writeHashtoVar("rttmoncfg",\%RTTcfg) if $view ne "true"; # store com config on disk
}
if ($rcom ne "*********" and $rcom ne "" and $rnode ne "") {
	$RTTcfg{$rnode}{community} = $rcom;
	$rcom = "*********";
	writeHashtoVar("rttmoncfg",\%RTTcfg) if $view ne "true"; # store com config on disk
}

# what shall we do

if ($func eq "start") {
	runRTTstart();
} elsif ($func eq "stop") {
	runRTTstop();
} elsif ($func eq "remove") {
	&runRTTremove();
} elsif ($func eq "graph") {
	&displayRTTgraph($key); exit; # ready
}

displayRTTmenu();

exit;

#
# display 
#
sub displayRTTmenu{

	my $header = "NMIS RTT Monitor";
	my $header2 = "$back_url$nmis_url$help_url $header";

	my $C = \%NMIS::config;
	my @output;
	my $fields;
	my %interfaceTable;
	my @saddr = ("");
	
	# get node info from /var, this file is produced by nmis.pl type=update
	my %RTTInfo = readVartoHash("nbarpdinfo"); # node info table generated by bin/nmis.pl
	my (@pnode,@nodes);
	@pnode = @nodes = grep { $_ if $RTTInfo{$_}{nodeModel} eq "CiscoRouter" } sort keys %RTTInfo;
	@pnode = @nodes = sort keys %RTTInfo if scalar @nodes == 0; # depends on nmis.pl code
	unshift @pnode, "";

	if ($pnode eq "") { $rnode = $optype = $pcom = $rcom = $pcom = $raddr = $view = $url = $key = $vrf = ""; }
	if ($optype =~ /http/ and $url eq "") { $url = "http://"; }

	if ($poptype ne $optype and $view ne "true"){ 
		$freq = $lsr = $tout = $tos = ""; $vrfy = 0; $attr = "on"  # defaults
	}

	# create source address list of probe node
	%interfaceTable = &loadCSV("$NMIS::config{'<nmis_var>'}/$pnode-interface.dat","ifIndex","\t") if $pnode ne "";
	foreach my $k (sort keys %interfaceTable) {
		if ($interfaceTable{$k}{ifAdminStatus} eq "up") {
			push @saddr,$interfaceTable{$k}{ipAdEntAddr} if $interfaceTable{$k}{ipAdEntAddr} ne "";
		}
	}

	# Javascripts
	my $jscript = <<JSEND;
	<!--
	function viewdoc(url,width,height)
	{
		var attrib = "scrollbars=yes,resizable=yes,width=" + width + ",height=" + height;
		ViewWindow = window.open(url,"ViewWindow",attrib);
		ViewWindow.focus();
	}
	function check(frm,e)
	{
		var msg1 = "Are you sure to stop this probe ?";
		var msg2 = "Do you want to delete the database of this probe ?";
		if (frm.func.value == "STOP") {
			if (confirm(msg1 )) {
				if (confirm(msg2)) {
					frm.deldb.value = 'true';
				}
	  			return true;
			} else {
				return false;
			}
		} 
		if (frm.func.value == "REMOVE") {
			if (confirm(msg2)) {
				frm.deldb.value = 'true';
			}
		}
		return true;
	}
	function noview(loc) {
		document.rtt.view.value = 'false';
		loc.form.submit();
		return true;
	}
	function gotoURL(url)
	{
	    var Current = document.rtt.probes.selectedIndex;
	    window.location.href = url + document.rtt.probes.options[Current].value;
	    return false;
	}
	//-->
JSEND


	#start of page
	print header({-type=>"text/html",-expires=>'now'});
	print start_html(-title=>$header,
               -author=>'Cologne',
				-xbase=>&url(-base=>1)."$C->{'<url_base>'}",
                -meta=>{'keywords'=>'network management NMIS'},
				-head=>meta({-http_equiv=>'refresh', -content=>'60'}),
                -style=>{'src'=>$C->{styles}},
				-script=>$jscript,
                -BGCOLOR=>'white');
	print &do_dash_banner($auth->Require, $user->user) ;

	print start_table({class=>"white"}) ;
	print Tr(td({class=>"view_header", colspan=>"4"},$header2));

	# start of form
	print start_form( -method=>'get', -name=>"rtt", -action=>url(), -onSubmit=>"return check(this,event)");

	# row with Probe Node, Type, Source address and Community
	push @output, start_Tr;
	push @output, td({class=>"menubar", width=>"25%"},
			"Probe node<br>".
				popup_menu(-name=>"pnode", -override=>'1',
					-values=>\@pnode,
					-default=>"$pnode",
					-title=>"node to run probe",
					-onChange=>"return noview(this);"));

	my @optypes = ($pnode ne "") ? ('',sort keys %operation) : ('');
	push @output, td({class=>"menubar", width=>"25%"},"Operation type<br>".
			popup_menu(-name=>"optype", -override=>'1',
				-values=>\@optypes,
				-default=>"$optype",
				-title=>"type of probe",
					-onChange=>"return noview(this);"));

	if ($operation{$optype}{attr} =~ /source-addr/ ) {
		push @output, td({class=>"menubar", width=>"25%"}, "Source address<br>".
				popup_menu(-name=>"saddr", -override=>'1',
					-values=>\@saddr,
					-default=>"$saddr",
					-title=>"optional",
					-onChange=>"return noview(this);"));
	} else {
		push @output, td({class=>'menubar',width=>'25%'}, "&nbsp;");
	}

	# dont use CGI password field
	push @output, td({class=>"menubar"}, eval {
				if ($pnode ne "") { return "SNMP&nbsp;community&nbsp;R/W<br>".
					textfield(-name=>"pcom",-override=>1,
						-title=>"community string of probe node to send snmp commands",
						-value=>"$pcom");
				} else { return "&nbsp;" }});
	push @output, end_Tr;
	print @output;

	@output = ();
	if ($optype ne "") {
		push @output, start_Tr;
		# row with Responder Nodeor URL and optional IP address and Community
		if ($optype =~ /http/) {
			push @output, td({class=>"menubar"}, "Url<br>".
					textfield(-name=>'url',-override=>1,
						-title=>"specify an URL to get a page",
						-value=>"$url"));
		} else {
			my @choices = ($operation{$optype}{responder} =~ /server/) ? ("","other") : ("") ;
			@choices = (@choices,@nodes) if ($operation{$optype}{responder} =~ /router/);
			push @output, td({class=>"menubar"}, "Responder node<br>".
					popup_menu(-name=>"rnode", -override=>'1',
						-values=>\@choices,
						-default=>"$rnode",
					-onChange=>"return noview(this);"));
		}
		$fields = 1;

		if ($rnode eq "other") {
			push @output, td({class=>"menubar"}, "Name or IP address<br>".
				textfield(-name=>"raddr",-override=>1,
					-value=>"$raddr"));
			$fields++;
		} 

		if ($operation{$optype}{responder} =~ /dport/) {
			$dport = $operation{$optype}{default}{dport} if $dport eq "";
			push @output, td({class=>"menubar"}, "Destination port<br>".
				textfield(-name=>"dport",-align=>"right",-size=>'3',-override=>1,
					-value=>"$dport"));
			$fields++;
		} 

		if ($operation{$optype}{responder} =~ /community/ and $rnode ne "other") {
			# dont use CGI password field
			push @output,td({class=>"menubar"}, "SNMP&nbsp;community&nbsp;R/W<br>".
					textfield(-name=>'rcom',-override=>1,
						-title=>"community string of responder node to send snmp commands",
						-value=>"$rcom"));
			$fields++;
		}
		foreach ($fields..3){ push @output, td({class=>"menubar"},'&nbsp;'); }
		push @output, end_Tr;

		print @output;

		# display attributes
		displayRTTattr($nno); 

		# row with History, Nodecharts and Submit button
		print Tr(
			td({class=>"menubar"}, eval {
				if ($RTTcfg{$nno}{status} =~ /running|error/i ) {
					my $s = ($RTTcfg{$nno}{history} > 1) ? "s" : "";
					return "History of values for $RTTcfg{$nno}{history} week$s" ;
				} elsif ($optype =~ /stats/i) {
					return "History of values&nbsp;".
						popup_menu(-name=>"history",
						-values=>[qw/1 2 4 8 16 32 64 128/],
						-default=>"$history",
						-title=>"size of RRD database depends",
						-labels=>{'1'=>'1 week','2'=>'2 weeks','4'=>'4 weeks','8'=>'8 weeks',
								'16'=>'16 weeks','32'=>'32 weeks','64'=>'64 weeks','128'=>'128 weeks'});
				} else {
					return "History of values&nbsp;".
						popup_menu(-name=>"history",
						-values=>[qw/1 2 4 8/],
						-default=>"$history",
						-title=>"size of RRD database depends",
						-labels=>{'1'=>'1 week','2'=>'2 weeks','4'=>'4 weeks','8'=>'8 weeks'});
				}}),
			td({class=>"menubar"},
				"View attributes&nbsp;".
					checkbox( -name=>"attr",
						-checked=>"$attr",
						-label=>'',
						-onChange=>'JavaScript:this.form.submit()')),
			td({class=>"menubar"}, eval {
				if ($view eq "true") {
						return "View node charts&nbsp;".
							checkbox( -name=>"pnodechart",
								-checked=>"$pnodechart",
								-label=>'',
								-onChange=>'JavaScript:this.form.submit()');
				} else {return "&nbsp;"} }),
			td({class=>"menubar"}, eval {
				# button for command the daemon to start,stop and remove
				my $button;
				if ($pnode ne "" and $optype ne "" and ($rnode ne "" or $optype =~ /http/)) { 
					if ($RTTcfg{$nno}{status} eq "") {
						$button = "start" ;
					} elsif ($RTTcfg{$nno}{status} =~ /running/i ) {
						$button = "stop" ;
					} elsif ($RTTcfg{$nno}{status} =~ /error|stopped|start requested/i) {
						$button = "remove" ;
					}
				}
				return 	"Collect&nbsp;".submit(-name=>"func",
					-value=>uc $button)})
			);
	}

	# probes and status to display ?
	my @probes = ();
	my %probes = {};
	my %attr = {};
	my $url = url()."?file=$conf&view=true&key=";
	foreach my $key ( sort keys %RTTcfg ) {
		if ($RTTcfg{$key}{pnode} ne "") {
			if ($RTTcfg{$key}{status} eq "error") {
				$attr{$key}{class} = "error";
				$msg = "one of the probes is in error state";
			}
			push @probes,$key;
			$probes{$key} = "$RTTcfg{$key}{select} ($RTTcfg{$key}{status})";
		}
	}

	if (@probes or $msg ne ""){
		# probe select and status/error info
		print Tr(
			td({class=>"menubar",colspan=>"2"}, "Select probe for graph&nbsp;".
				popup_menu(-name=>"probes", -override=>'1',
					-values=>["",@probes],
					-default=>$key,
					-labels=>\%probes,
					-attributes=>\%attr,
					-onChange=>"return gotoURL(\"$url\");")), eval {
				# display status msg
				my $message;
				my $class = "menubar";
				if ($pnode ne "") {
					if ($RTTcfg{$nno}{message} ne "") {
						$class = "error";
						$message = "&nbsp;$RTTcfg{$nno}{message}";
					} elsif ( $NMIS::config{daemon_rttmon} ne "true" ) {
						$message = td({class=>"error"},"&nbsp; parameter daemon_rttmon in nmis.conf is not set on true to start the daemon rttmond.pl");
					} elsif ((not -r "$NMIS::config{'<nmis_var>'}/rttmond.pid") or ( -M "$NMIS::config{'<nmis_var>'}/rttmond.pid" > 0.0015)) { 
						$message = td({class=>"error"},"&nbsp;daemon rttmond.pl is not running");
					} elsif ($msg ne "") { 
						$message = $msg; $class = "error"; # local msg
					} else {
						$message = "$RTTcfg{$nno}{starttime}";
					}
				} elsif ($msg ne "") { 
					$message = $msg; $class = "error"; # local msg
				}
				$message = scalar @probes." probes are active" if $message eq "" and scalar @probes > 1;
				$message = "1 probe is active" if $message eq "" and scalar @probes == 1;
				return td({class=>$class,colspan=>"2"},"$message");
			}
		);
	}


	# display node charts ?
	if ($view eq "true" and $pnodechart eq "on") { displayRTTnode(); } # node charts

	# background values
	print hidden(-name=>'file', -default=>$conf,-override=>'1');
	print hidden(-name=>'ppnode', -default=>$pnode,-override=>'1');
	print hidden(-name=>'prnode', -default=>$rnode,-override=>'1');
	print hidden(-name=>'poptype', -default=>$optype,-override=>'1');
	print hidden(-name=>'deldb', -default=>'false',-override=>'1');
	print hidden(-name=>'view', -default=>$view,-override=>'1');
	print hidden(-name=>'key', -default=>$key,-override=>'1') if $view eq "true";

	print end_form;

	# start of second form
	print start_form( -method=>'get', -name=>"data", -action=>url() );

	# display data
	if ($view eq "true" and $RTTcfg{$nno}{status} eq "running") { displayRTTdata($nno); }

	# background values
	print hidden(-name=>'file', -default=>$conf,-override=>'1');
	print hidden(-name=>'start',-default=>"$start",-override=>'1');
	print hidden(-name=>'end', -default=>$end,-override=>'1');
	print hidden(-name=>'view', -default=>'true',-override=>'1');
	print hidden(-name=>'key', -default=>$key,-override=>'1');
	print hidden(-name=>'item', -default=>$item,-override=>'1');

	print end_form;

	print end_table();

	print end_html;

}

sub runCfgUpdate {

	writeHashtoVar("rttmoncfg",\%RTTcfg); # store config on disk

	# let the daemon unlink the database
	return if ($RTTcfg{$nno}{func} =~ /stop|remove/ and $RTTcfg{$nno}{deldb} eq "true");

	# run bin/rttmond.pl for accept modified configuration
	# if this system failed then the detach process rttmond.pl does it later.
	my $lines = `$NMIS::config{'<nmis_bin>'}/rttmond.pl type=update`;

	# get new values of daemon
	%RTTcfg = readVartoHash("rttmoncfg");
}

sub runRTTstart {

	# already running ?
	if ($RTTcfg{$nno}{status} eq "running") {
		$pnode = $attr = "";
		return;
	}

	if ($RTTcfg{$pnode}{community} eq "") {
		$msg = "No community specified for probe node $pnode";
	#	$pnode = "";
		return;
	}

	if ($rnode eq "other" and $raddr eq "") {
		$msg = "No address specified for responder node";
		$pnode = "";
		return;
	}

	if ($pnode ne "" and $RTTcfg{$nno}{func} eq "" and $RTTcfg{$nno}{status} !~ /start|running|remove|error/) {
		$RTTcfg{$nno}{func} = "start";
		$RTTcfg{$nno}{select} = "${pnode}::${dest}::${optype}";
		$RTTcfg{$nno}{pnode} = $pnode; # probe node
		$RTTcfg{$nno}{optype} = $optype; # probe type
		$RTTcfg{$nno}{saddr} = $saddr; # source address
		$RTTcfg{$nno}{rnode} = $rnode; #
		$RTTcfg{$nno}{raddr} = $raddr if $raddr ne ""; #
		$RTTcfg{$nno}{tnode} = $tnode if $tnode ne ""; # responder node
		$RTTcfg{$nno}{dport} = $dport if $dport ne ""; # destination port
		$RTTcfg{$nno}{url} = $url if $url ne "";
		$RTTcfg{$nno}{history} = $history;
		$RTTcfg{$nno}{frequence} = $freq;
		$RTTcfg{$nno}{lsrpath} = $lsr if $lsr ne "";
		$RTTcfg{$nno}{reqdatasize} = $dsize if $dsize ne "";
		$RTTcfg{$nno}{timeout} = $tout if $tout ne "";
		$RTTcfg{$nno}{tos} = $tos if $tos ne "";
		$RTTcfg{$nno}{interval} = $intvl if $intvl ne "";
		$RTTcfg{$nno}{numpkts} = $pkts if $pkts ne "";
		$RTTcfg{$nno}{tport} = $tport if $tport ne "";
		$RTTcfg{$nno}{tas} = $tas if $tas ne "";
		$RTTcfg{$nno}{codec} = $codec if $codec ne "";
		$RTTcfg{$nno}{factor} = $codec if $factor ne "";
		$RTTcfg{$nno}{vrf} = $vrf if $vrf ne "";
		$RTTcfg{$nno}{deldb} = $deldb; # delete database
		$RTTcfg{$nno}{verify} = ($vrfy == 0) ? 2 : $vrfy;
		my $n = $nno; $n =~ s/[\._]/-/g ;
		$RTTcfg{$nno}{database} = "$NMIS::config{database_root}/misc/rttmon-${n}.rrd";

		$RTTcfg{$nno}{status} = "start requested";
		$RTTcfg{$nno}{message} = "";

		$pnode = $pcom = $rnode = $rcom = $view = $attr = "";
		runCfgUpdate();
	}
}

sub runRTTstop {

	if ($RTTcfg{$nno}{func} eq "" and $RTTcfg{$nno}{status} =~ /start|running|error/) {

		$RTTcfg{$nno}{func} = "stop";
		$RTTcfg{$nno}{status} = "stop requested";
		$RTTcfg{$nno}{message} = "";
		$RTTcfg{$nno}{deldb} = $deldb;

		$pnode = $pcom = $rnode = $rcom = $view = $attr = "";
		runCfgUpdate();
	}
}

sub runRTTremove {

	return if not exists $RTTcfg{$nno}{pnode};
	if ($RTTcfg{$nno}{func} eq "" and $RTTcfg{$nno}{pnode} ne "" and
			$RTTcfg{$nno}{status} !~ /remove|running|start/) {

		$RTTcfg{$nno}{func} = "remove";
		$RTTcfg{$nno}{status} = "remove requested";
		$RTTcfg{$nno}{message} = "";
		$RTTcfg{$nno}{deldb} = $deldb;
		runCfgUpdate();
	} else { 
		delete $RTTcfg{$nno} ;
		writeHashtoVar("rttmoncfg",\%RTTcfg);
	}
	$pnode = $pcom = $rnode = $rcom = $view = $attr = $url = "";
}


# display the attributes depending of probe type
sub displayRTTattr {

	my $nno = shift;
	my $field_cnt = 0;

	# it's the lazy way
	if ($optype ne "" ) {
		print start_Tr if $attr eq "on";

		if ($operation{$optype}{attr} =~ /frequence/) {
			$freq = $operation{$optype}{default}{freq} if $freq eq "";
			if ($attr eq "on") {
				print td({class=>"menubar"}, 
					"interval&nbsp;".
						popup_menu(-name=>"freq", -override=>'1',
							-values=>$operation{$optype}{frequence},
							-default=>"$freq")."&nbsp;sec.");
				$field_cnt++;
			} else {
				print hidden(-name=>'freq', -default=>$freq, -override=>'1');
			}
		}
		if ($operation{$optype}{attr} =~ /lsr-path/) {
			if ($attr eq "on") {
				print td({class=>"menubar"},"lsr path, ip addr.&nbsp;".
							textfield(-name=>'lsr',-override=>1,
							-value=>"$lsr"));
				$field_cnt++;
			} else {
				print hidden(-name=>'lsr', -default=>$lsr, -override=>'1');
			}
		}
		if ($operation{$optype}{attr} =~ /request_data_size/) {
			$dsize = $operation{$optype}{default}{dsize} if $dsize eq "";
			if ($attr eq "on") {
				print td({class=>"menubar"},"req data size".
						textfield(-name=>'dsize',-override=>'1',-size=>'2',-align=>'right',
							-title=>"optional, range 1 - 1500",
							-value=>"$dsize"));
				$field_cnt++;
			} else {
				print hidden(-name=>'dsize', -default=>$dsize, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /timeout/) {
			$tout = $operation{$optype}{default}{tout} if $tout eq "";
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar", align=>"right"},"timeout&nbsp;".
					popup_menu(-name=>"tout", -override=>'1',
						-values=>["",1,2,3,4,5,10,20,30],
						-default=>"$tout"));
				$field_cnt++;
			} else {
				print hidden(-name=>'tout', -default=>$tout, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /tport/) {
			$tport = $operation{$optype}{default}{tport} if $tport eq "";
			if ($attr eq "on") {
				print td({class=>"menubar"},"port&nbsp;".
						textfield(-name=>'tport',-override=>'1',-size=>'2',-align=>'right',
							-title=>"even number in range 16384 - 32766 or 49152 - 65534",
							-value=>"$tport"));
				$field_cnt++;
			} else {
				print hidden(-name=>'tport', -default=>$tport, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /tos/) {
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar", align=>"right"},"tos&nbsp;".
					popup_menu(-name=>"tos", -override=>'1',
						-values=>["",(0..255)],
						-title=>"optional, defines the IP ToS byte",
						-default=>"$tos"));
				$field_cnt++;
			} else {
				print hidden(-name=>'tos', -default=>$tos, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /codec/) {
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar"},"codec&nbsp;".
					popup_menu(-name=>"codec", -override=>'1',
						-values=>[qw/1 2 3/],
						-labels=>{'1'=>'g711ulaw','2'=>'g711alaw','3'=>'g729a'}, 
						-default=>"$codec"));
				$field_cnt++;
			} else {
				print hidden(-name=>'codec', -default=>$codec, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /factor/) {
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar"},"ICPIF factor&nbsp;".
					popup_menu(-name=>"factor", -override=>'1',
						-values=>[qw/0 5 10 20/],
						-default=>"$factor"));
				$field_cnt++;
			} else {
				print hidden(-name=>'factor', -default=>$factor, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /verify-data/) {
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar"}, 
					"verify data&nbsp;".
						popup_menu(-name=>"vrfy", -override=>'1',
							-values=>[2,1],
							-labels=>{'2' => 'no','1' => 'yes'},
							-default=>"$vrfy"));
				$field_cnt++;
			} else {
			print hidden(-name=>'vrfy', -default=>$vrfy, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /interval/) {
			$intvl = $operation{$optype}{default}{intvl} if $intvl eq "";
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar"},"interval&nbsp;".
						textfield(-name=>'intvl',-override=>1,-size=>'2',-align=>'right',
							-title=>"time in msec. between packets",
							-value=>"$intvl")." msec");
				$field_cnt++;
			} else {
			print hidden(-name=>'intvl', -default=>$intvl, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /num-pkts/) {
			$pkts = $operation{$optype}{default}{pkts} if $pkts eq "";
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar"},"# of packets&nbsp;".
						textfield(-name=>'pkts',-override=>1,-size=>'2',-align=>'right',
							-title=>"number of packets per probe operation, range 1 to 60000",
							-value=>"$pkts"));
				$field_cnt++;
			} else {
			print hidden(-name=>'pkts', -default=>$pkts, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /tas/) {
			$tas = $operation{$optype}{default}{tas} if $tas eq "";
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar"},"dns addr. of request&nbsp;".
						textfield(-name=>'tas',-override=>1,
							-title=>"can be in IP address format or a hostname",
							-value=>"$tas"));
				$field_cnt++;
			} else {
			print hidden(-name=>'tas', -default=>$tas, -override=>'1');
			}
		}
		if ($field_cnt > 3) { print end_Tr; $field_cnt = 0;}
		if ($operation{$optype}{attr} =~ /vrf/) {
			$vrf = $operation{$optype}{default}{vrf} if $vrf eq "";
			if ($attr eq "on") {
				if ($field_cnt == 0) { print start_Tr; }
				print td({class=>"menubar"},"vrf name&nbsp;".
						textfield(-name=>'vrf',-override=>1,
							-title=>"optional vrf name, max 30 char",
							-value=>"$vrf"));
				$field_cnt++;
			} else {
			print hidden(-name=>'vrf', -default=>$vrf, -override=>'1');
			}
		}
		if ($attr eq "on" and $RTTcfg{$nno}{entry} ne "") {
			print td({class=>"menubar",align=>"center"},"probe entry is $RTTcfg{$nno}{entry}");
			$field_cnt++;
		}
		if ($attr eq "on") {
			foreach ($field_cnt..3) {print td({class=>"menubar"},"&nbsp;"); $field_cnt++;}
			print end_Tr if $field_cnt > 0;
		}
	}

}

sub displayRTTnode {

	if ($pnode ne "") {
		print Tr( hprint(["CPU","CPU Utilisation","cpu"]),hprint(["Mem","Router Memory","mem-router"]));
	}


#==
	sub hprint {
		my $aref = shift;
		my $glamount = $NMIS::config{graph_amount};
		my $glunits = $NMIS::config{graph_unit};
		my $win_width = $NMIS::config{graph_width} + 100;
		my $win_height = $NMIS::config{graph_height} + 320;
		my $nmiscgi_script = "$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl";
		my $tmpurl="$nmiscgi_script?file=$conf&type=graph&graphtype=$aref->[2]&glamount=&glunits=&node=$pnode";

		return td({align=>"center", colspan=>"2", bgcolor=>"white"},
			a({href=>$tmpurl, target=>"ViewWindow", onMouseOver=>"window.status='Drill into $aref->[1].';return true",
					 onClick=>"viewdoc('$tmpurl',$win_width,$win_height)"},
				img({border=>"0", alt=>"$aref->[1]", 
					src=>"$nmiscgi_script?file=$conf&type=drawgraph&node=$pnode&graph=$aref->[2]&glamount=$glamount&glunits=$glunits&start=0&end=0&width=350&height=50&title=small"})));
	}
}

sub displayRTTdata {
	my $nno = shift;

	my $time = time;

	if ( $start eq "" ) { $start = $time - (24*3600); } # 24 hour window
	if ( $end eq "" ) { $end = $time; }

	my $window = $end - $start;

	my $sec_start = ($date_start eq "") ? $start : parsedate($date_start) ; # convert string to number seconds
	my $sec_end = ($date_end eq "") ? $end : parsedate($date_end) ;

	# check if date boxes are changed by user
	if ( $start != $sec_start or $end != $sec_end ) {
		$start = $sec_start;
		$end = $sec_end;
	}
	# calculate moving graph window on click
	#left, if clicked on graph
	elsif ( $graphx != 0 and $graphx < 150 ) {
		$start -= ($window / $NMIS::config{graph_factor});
		$end = $start + $window;
	}
	#right
	elsif ( $graphx != 0 and $graphx > $width + 94 - 150 ) {
		my $move = $time - ($end + ($window / $NMIS::config{graph_factor}));
		$move = 0 if $move > 0 ;
		$end += ($window / $NMIS::config{graph_factor}) + $move;
		$start = $end - $window;
	}
	#zoom in
	elsif ( $graphx != 0 and ( $graphy != 0 and $graphy <= $height / 2 ) ) {
		$start += ($window / $NMIS::config{graph_factor});
	}
	#zoom out
	elsif ( $graphx != 0 and ( $graphy != 0 and $graphy > $height / 2 ) ) {
		$start -= $window;
	}

	# Stop from drilling into the future!
	$end = $time if $end > $time;
	$start = $time if $start > $time;

	$start = int $start;
	$end = int $end;

	$date_start = returnDateStamp($start); # for display date/time fields
	$date_end = returnDateStamp($end);

	my @items = split ":", $RTTcfg{$nno}{items};				

	my $numrows = scalar( map { /^\d+L\d+.*/ } @items); # number of Lines in RRD graph

	if ($numrows == 0) { print Tr(td("Waiting for data")); return; }

	# date time and column name fields
	print Tr(th({class=>"menubar",colspan=>"2",align=>"center"},"Start&nbsp;",
				textfield(-name=>"date_start",-value=>"$date_start",-override=>1),
				"&nbsp;End&nbsp;",
				textfield(-name=>"date_end",-value=>"$date_end",-override=>1),
				submit(-name=>"date",-value=>"View")),
				th({class=>"menubar"},$RTTcfg{$nno}{select}),
				eval {
					my $str = $RTTcfg{$nno}{optype} =~ /echo/i ? "Target / Responder": "Item";
					return th({class=>"menubar"},$str); 
				} # eval
			);

	# image
	$item = $RTTcfg{$nno}{items} if $item eq ""; 
	$numrows++; # correction
	print Tr(td({colspan=>"3",rowspan=>"$numrows",align=>"left",valign=>"top"},
		image_button(-name=>"graph",-src=>url()."?file=$conf&func=graph&view=true&key=$nno&start=$start&end=$end&item=$item")));
	foreach my $nm (@items) {
		if ($nm =~ /^\d+L(\d+)_(.*)/) {
			$_ = $2;
			s/_/\./g;
			my $addr = "$_<br><small>$RTTcfg{$nno}{$_}</small>";
			print Tr(td({align=>"center"},a({href=>url()."?file=$conf&view=true&key=$nno&start=$start&end=$end&item=$nm"},$addr)));
		}
	}
	print Tr(th({colspan=>"3",align=>"center"},"Clickable graphs: Left -> Back; Right -> Forward; Top Middle -> Zoom In; Bottom Middle-> Zoom Out, in time"),
				th("&nbsp"));
}

# generate chart
sub displayRTTgraph {
	my $nno = shift;

	my $color;
	my @items = split(/\:/,$item);
	my $database = $RTTcfg{$nno}{database};

	my @colors = ("880088","00CC00","0000CC","CC00CC","FFCC00","00CCCC",
			"000044","BBBB00","BB00BB","00BBBB");

	my $datestamp_start = returnDateStamp($start);
	my $datestamp_end = returnDateStamp($end);

	# select the vertical label, first digit of first item
	my $vlabel = "RTT Avg msec."; 
	if ($items[0] =~ /^(\d+)[A-Z]\d+_.*/) {
		$vlabel = "Impairment/Calculated Imp. Planning Factor" if $1 == 2;
		$vlabel = "Mean opinion scores" if $1 == 3;
		$vlabel = "Jitter Avg msec." if $1 == 4;
		$vlabel = "Number of packets" if $1 == 5;
		$vlabel = "Hourly RTT Avg msec." if $1 == 6;
		$vlabel = "Hourly Jitter Avg msec." if $1 == 7;
		$vlabel = "Hourly Impairment/Calculated Imp. Planning Factor" if $1 == 8;
		$vlabel = "Hourly Mean opinion scores" if $1 == 9;
	}

	my @options = (
			"--title", "$RTTcfg{$nno}{select} from $datestamp_start to $datestamp_end",
			"--vertical-label", $vlabel,
			"--start", "$start",
			"--end", "$end",
			"--width", "$width",
			"--height", "$height",
			"--imgformat", "PNG",
			"--interlace");

	my $cnt = 0;
	my @p_options = ();
	foreach (@items) {
		if ( /^\d+([A-Z])(\d+)_(.*)/ ) {
			my $az = $1;
			my $gp = $2;
			my $ds = $3;
			$color = shift @colors if $cnt++ < 10;
			push @options,"DEF:avg$cnt=$database:${ds}:AVERAGE" if $az =~ /[LP]/ ;
			push @options,"DEF:max$cnt=$database:${ds}:MAX" if $az =~ /M/ ;
			$ds =~ s/_/\./g ; # back to IP address format if needed
			if ($az eq "L") {
				push @options,"LINE1:avg$cnt#$color:${ds}";
				push @options,"GPRINT:avg$cnt:AVERAGE:Avg %0.1lf msec." if $gp == 1;
				push @options,"GPRINT:avg$cnt:AVERAGE:Avg %0.1lf" if $gp == 2;
			} elsif ($az eq "P") {
				push @p_options,"GPRINT:avg$cnt:AVERAGE:$ds Avg %0.1lf msec." if $gp == 1 ;
				push @p_options,"GPRINT:avg$cnt:AVERAGE:$ds Avg %0.1lf" if $gp == 2;
			} elsif ($az eq "M") {
				push @p_options,"GPRINT:max$cnt:MAX:$ds %0.1lf msec." if $gp == 1 ;
			}
		}
	}

	@options = (@options,@p_options);

	# buffer stdout to avoid Apache timing out on the header tag while waiting for the PNG image stream from RRDs
	select((select(STDOUT), $| = 1)[0]);
	print header({-type=>'image/png',-expires=>'now'});

	my ($graphret,$xs,$ys) = RRDs::graph('-', @options);
	select((select(STDOUT), $| = 0)[0]);			# unbuffer stdout

	if ($ERROR = RRDs::error) {
		logMessage("RTTMON: RRDgraph, $database Graphing Error: $ERROR");
	}
}


