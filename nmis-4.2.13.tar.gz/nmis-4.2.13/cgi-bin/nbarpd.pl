#!/usr/bin/perl
#
# $Id: nbarpd.pl,v 1.8 2006/10/08 13:10:51 decologne Exp $
#
#    nbarpd.pl - NMIS NBAR Protocol Discovery Program - Network Mangement Information System
#    Copyright (C) 2001 Sinclair InterNetworking Services Pty Ltd 
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#    written by Cologne 2005
#
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";

# the following is a workaround for bad-behaved rrdtool installations.
use lib "/usr/local/rrdtool/lib/perl";

# 
use Time::ParseDate;
use RRDs;
use strict;
use web;
use NMIS;
use func;
use csv;
use rrdfunc;
use Fcntl qw(:DEFAULT :flock);
use GD::Graph::pie;
use GD::Graph::bars;
use GD::Graph::hbars;
use Data::Dumper;
$Data::Dumper::Indent = 1;

# NMIS Authentication module
use NMIS::Users;
use NMIS::Auth;
use NMIS::Toolbar;

# variables used for the security mods
use vars qw(@cookies); @cookies = ();
use vars qw(%headeropts); %headeropts = ();

# use CGI for html processing
use CGI qw/:standard *table *Tr *td *Select *form -no_xhtml /;

# declare holder for CGI objects
use vars qw($q);
$q = new CGI; # Processes all parameters passed via GET 

# Allow program to use other configuration files
my $conf;
if ( $q->param('file') ne "" ) { $conf = $q->param('file'); }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

# Before going any further, check to see if we must handle
# an authentication login or logout request

$NMIS::config{auth_require} = 0 if ( ! defined $NMIS::config{auth_require} );
$NMIS::config{auth_require} =~ s/^[fn0].*/0/i;
$NMIS::config{auth_require} =~ s/^[ty1].*/1/i;

my $auth = ();
my $user = ();

$auth = NMIS::Auth->new;  # NMIS::Auth::new will reap init values from $NMIS::config
$user = NMIS::Users->new;   # NMIS::Users is dependent upon NMIS::Auth

# NMIS::Auth::new () and NMIS::Auth::Initialize () will eventually do all this
#
if ( $auth->Require ) {
	# either set by the web server or via a set cookie
	$user->SetUser( $auth->verify_id );

	# $user should be set at this point, if not then redirect
	unless ( $user->user ) {
		$auth->do_force_login("Authentication is required. Please login.");
		exit 0;
	}
	# verify access to this plugin
	$auth->CheckAccess($user, "nbarpd") or die "Attempted unauthorized access";

	# logout ?
	if ( $q->param('type') eq 'logout' ) {
       	$auth->do_logout;
		exit 0;
	}
	# generate the cookie if $user->user is set
	if ( $user->user ) {
        push @cookies, $auth->generate_cookie($user->user);
        $headeropts{-cookie} = [@cookies];
	}
}


# Break the queary up for the names
my $func = lc $q->param('func');
my $node = $q->param('node');
my $intf = $q->param('intf');
my $community = $q->param('com');
my $history = $q->param('history');
my $nodechart = $q->param('nodechart');
my $type = $q->param('type');
my $graph = $q->param('graph');
my $debug = $q->param('debug');
my $start = $q->param('start') ;
my $end = $q->param('end');
my $date_start = $q->param('date_start');
my $date_end = $q->param('date_end');
my $graphx = $q->param('graph.x');
my $graphy = $q->param('graph.y');
my $item = $q->param('item');
my $view = $q->param('view');

my $dump_data = Dump;

my ($graphret, $xs, $ys, $ERROR);
my $width = 550; # of nbarpd chart
my $height = 250; # of nbarpd chart

my $nmis_url = a({href=>"$NMIS::config{nmis}?file=$conf"},img({alt=>"NMIS Dash", src=>"$NMIS::config{nmis_icon}", border=>"0"}));
my $back_url = a({href=>referer()},img({alt=>"Back", src=>"$NMIS::config{back_icon}", border=>"0"}));
my $help_url = a({href=>"$NMIS::config{'<url_base>'}/nbarpd.pod.html"},img({alt=>"Help", src=>"$NMIS::config{help_icon}", border=>"0"}));


# what shall we do

if ($func eq "start") {
	runPDstart();
} elsif ($func eq "stop") {
	runPDstop();
} elsif ($func eq "remove") {
	&runPDremove();
} elsif ($func eq "graph") {
	&displayPDgraph(); exit; # ready
}

displayPDmenu();

exit;

#
# display 
#
sub displayPDmenu{

	my $header = "NMIS Protocol Discovery";
	my $header2 = "$back_url$nmis_url$help_url $header";
	my $ni = "$node-$intf"; # key
	my $C = \%NMIS::config;
	
	# get nbarpdinfo from /var, this file is produced by nmis.pl type=update
	my %NBARPDInfo = readVartoHash("nbarpdinfo"); # node table

	# get NBARPDcfg from /var
	my %NBARPDcfg = readVartoHash("nbarpdcfg"); # configuration

	# get interface info if node selected
	my %interfaceTable;
	if ($node ne "") { 
		%interfaceTable = &loadCSV("$C->{'<nmis_var>'}/$node-interface.dat","ifIndex","\t");
	}

	# build interface popup-menu info
	my %intfdescr = ( '0' => '' );
	my @intfindx = ('');;
	foreach my $i (sort keys %interfaceTable) {
		if ( $interfaceTable{$i}{collect} eq "true" ) {
			$intfdescr{$i} = $interfaceTable{$i}{ifDescr};
			push @intfindx, $i;
		}
	}

	# dont use CGI password field
	if (not exists $NBARPDcfg{$node}{community} ) { $community = ""; }
	if ($NBARPDcfg{$node}{community} ne "") { $community = "*********"; }

	$history = "1" if ($history eq "") ; # default

	# button for command the daemon to start or stop protocol discovery for this node::interface
	my $func_uc;
	if ($node ne "" and $intf ne "" ) { 
		if ($NBARPDcfg{"$node-$intf"}{status} eq "") {
			$func_uc = uc "start" ;
		} elsif ($NBARPDcfg{"$node-$intf"}{status} =~ /running/i ) {
			$func_uc = uc "stop" ;
		} elsif ($NBARPDcfg{"$node-$intf"}{status} =~ /error|stopped|start requested/i) {
			$func_uc = uc "remove" ;
		}
	}

	my $jscript = <<JSEND;
	function viewdoc(url,width,height)
	{
		var attrib = "scrollbars=yes,resizable=yes,width=" + width + ",height=" + height;
		ViewWindow = window.open(url,"ViewWindow",attrib);
		ViewWindow.focus();
	}
JSEND

	#start of page
	print header({-type=>"text/html",-expires=>'now'});
	print start_html(-title=>$header,
               -author=>'Cologne',
				-xbase=>&url(-base=>1)."$C->{'<url_base>'}",
                -meta=>{'keywords'=>'network management NMIS'},
				-head=>meta({-http_equiv=>'refresh', -content=>'60'}),
                -style=>{'src'=>$C->{styles}},
				-script=>$jscript,
                -BGCOLOR=>'white');
	print &do_dash_banner($auth->Require, $user->user) ;

	print start_table({class=>"white"}) ;
	print Tr(td({class=>"view_header", colspan=>"3"},$header2));

	# start of form
	print start_form( -method=>'get', -name=>"nbarpd", -action=>url() );

	# row with Node, Interface and Community
	print Tr(
		td({class=>"menubar", width=>"33%"},
			"Node&nbsp;".
				popup_menu(-name=>"node", -override=>'1',
					-values=>['',sort keys %NBARPDInfo],
					-default=>"$node",
					-onChange=>'JavaScript:this.form.submit()')),
		td({class=>"menubar", width=>"33%"},
			"Interface&nbsp;".
				popup_menu(-name=>"intf",
					-values=>\@intfindx,
					-labels=>\%intfdescr,
					-default=>"$intf",
					-onChange=>'JavaScript:this.form.submit()')),
		td({class=>"menubar"},
			"SNMP&nbsp;community&nbsp;R/W&nbsp;".
				textfield(-name=>"com",-override=>1,
					-value=>"$community"))
			);

	# row with History, Nodecharts and Submit button
	print Tr(
		td({class=>"menubar", width=>"33%"}, &history),
		td({class=>"menubar", width=>"33%"},
			"View node charts&nbsp;".
				checkbox( -name=>"nodechart",
					-checked=>"$nodechart",
					-label=>'',
					-onChange=>'JavaScript:this.form.submit()')),
		td({class=>"menubar"},
			submit(-name=>"func",
				-value=>"$func_uc")."&nbsp;discovery")
		);

	sub history { 	
		my %hist = ( '1' => '1 week, (6Mb)',
					 '2' => '2 weeks, (9Mb)',
					 '4' => '4 weeks, (14Mb)',
					 '8' => '8 weeks, (24Mb)' );
		if ($NBARPDcfg{$ni}{status} =~ /running|error/i ) {
			my $s = ($NBARPDcfg{$ni}{history} > 1) ? "s" : "";
			return "History of values for $NBARPDcfg{$ni}{history} week$s" ;
		} else {
			return "History of values&nbsp;".
				popup_menu(-name=>"history",
					-values=>[qw/1 2 4 8/],
					-default=>"$history",
					-labels=>\%hist) ; }
	}

	end_table();

	print start_table({class=>"white"}) ;

	my $anchors;
	foreach my $if ( sort keys %NBARPDcfg ) {
		if ($NBARPDcfg{$if}{node} ne "") {
			$anchors .= a({class=>"button", href=>url()."?file=$conf&view=true&nodechart=$nodechart&graph=$graph&node=$NBARPDcfg{$if}{node}&intf=$NBARPDcfg{$if}{intf}"},
				"$NBARPDcfg{$if}{node}::$NBARPDcfg{$if}{descr}&nbsp;($NBARPDcfg{$if}{status})<br>");
		}
	}

	# info/error message
	my $message;
	if ($node ne "" and $intf ne "") {
		if ($NBARPDcfg{"$node-$intf"}{message} ne "") {
			$message = td({class=>"error"},"&nbsp;$NBARPDcfg{$ni}{message}");
		} elsif ( $NMIS::config{daemon_nbarpd} ne "true" ) {
			$message = td({class=>"error"},"&nbsp; parameter daemon_nbarpd in nmis.conf is not set on true to start the daemon nbarpdd.pl");
		} elsif ((not -r "$NMIS::config{'<nmis_var>'}/nbarpdd.pid") or ( -M "$NMIS::config{'<nmis_var>'}/nbarpdd.pid" > 0.0015)) { 
			$message = td({class=>"error"},"&nbsp;daemon nbarpdd.pl is not running");
		} else {
			$message = td({class=>"menubar"},"&nbsp;$NBARPDcfg{$ni}{starttime}");
		}
	} else {
		$message = td({class=>"menubar"},"&nbsp;");
	}

	print Tr(
		th({class=>"menubar", width=>"50%"},
			"Select node::interface graph".
				div({align=>"center"}, $anchors)),
					$message);

	# display node charts ?
	if ($view eq "true" and $nodechart eq "on") { displayPDnode(); } # node charts

	print end_table();


	# display values
	if ($view eq "true" and $NBARPDcfg{$ni}{status} eq "running") { displayPDdata(); } # pie/bar/chart

	# background values
	print hidden(-name=>'file', -default=>$conf,-override=>'1');
	print hidden(-name=>'start',-default=>"$start",-override=>'1');
	print hidden(-name=>'end', -default=>$end,-override=>'1');
	print hidden(-name=>'view', -default=>$view,-override=>'1');

	print end_form;

	print end_html;

}

sub runCfgUpdate {
	# run bin/nbarpdd for accept modified configuration
	# if this system failed then the detach process nbarpdd.pl does it within a minute.
	system("$NMIS::config{'<nmis_bin>'}/nbarpdd.pl type=update");
}

sub runPDstart {

	# get NBARPDcfg from /var
	my %NBARPDcfg = readVartoHash("nbarpdcfg");

	my %interfaceTable;
	if ($node ne "") { 
		%interfaceTable = &loadCSV("$NMIS::config{'<nmis_var>'}/$node-interface.dat","ifIndex","\t");
	}

	if ($NBARPDcfg{"$node-$intf"}{func} eq "" and $NBARPDcfg{"$node-$intf"}{status} !~ /start|running|remove|error/) {
		if ($community ne "*********") {$NBARPDcfg{$node}{community} = $community;}
		$NBARPDcfg{"$node-$intf"}{func} = "start";
		$NBARPDcfg{"$node-$intf"}{node} = $node;
		$NBARPDcfg{"$node-$intf"}{intf} = $intf;
		$NBARPDcfg{"$node-$intf"}{descr} = $interfaceTable{$intf}{ifDescr};
		$NBARPDcfg{"$node-$intf"}{history} = $history;
		$NBARPDcfg{"$node-$intf"}{status} = "start requested";
		$NBARPDcfg{"$node-$intf"}{message} = "";

		writeHashtoVar("nbarpdcfg",\%NBARPDcfg);
		$node = "";
		$intf = "";
		$community = "";
		runCfgUpdate();
	}
}

sub runPDstop {

	# get NBARPDcfg from /var
	my %NBARPDcfg = readVartoHash("nbarpdcfg");

	if ($NBARPDcfg{"$node-$intf"}{func} eq "" and $NBARPDcfg{"$node-$intf"}{status} =~ /start|running|error/) {

		$NBARPDcfg{"$node-$intf"}{func} = "stop";
		$NBARPDcfg{"$node-$intf"}{status} = "stop requested";
		$NBARPDcfg{"$node-$intf"}{message} = "";

		writeHashtoVar("nbarpdcfg",\%NBARPDcfg);
		$node = "";
		$intf = "";
		$community = "";
		$view = "";
		runCfgUpdate();
	}
}

sub runPDremove {

	# get NBARPDcfg from /var
	my %NBARPDcfg = readVartoHash("nbarpdcfg");

	if ($NBARPDcfg{"$node-$intf"}{func} eq "" and $NBARPDcfg{"$node-$intf"}{node} ne "" and
			$NBARPDcfg{"$node-$intf"}{status} !~ /remove|running|start/) {

		$NBARPDcfg{"$node-$intf"}{func} = "remove";
		$NBARPDcfg{"$node-$intf"}{status} = "remove requested";
		$NBARPDcfg{"$node-$intf"}{message} = "";
	}
	$node = "";
	$intf = "";
	$community = "";
	$view = "";
	writeHashtoVar("nbarpdcfg",\%NBARPDcfg);
	runCfgUpdate();
}


sub displayPDnode {

	if ($node ne "") {
		rowStart;
		hprint( [ "CPU", "CPU Utilisation", "cpu" ] );
		hprint( [ "Mem", "Router Memory", "mem-router" ] );
		rowEnd;
	}


#==
	sub hprint {
		my $aref = shift;
		my $glamount = $NMIS::config{graph_amount};
		my $glunits = $NMIS::config{graph_unit};
		my $win_width = $NMIS::config{graph_width} + 100;
		my $win_height = $NMIS::config{graph_height} + 320;
		my $nmiscgi_script = "$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl";
		my $tmpurl="$nmiscgi_script?file=$conf&type=graph&graphtype=$aref->[2]&glamount=&glunits=&node=$node";

		print td({align=>"center", bgcolor=>"white"},
			a({href=>$tmpurl, target=>"ViewWindow", onMouseOver=>"window.status='Drill into $aref->[1].';return true",
					 onClick=>"viewdoc('$tmpurl',$win_width,$win_height)"},
				img({border=>"0", alt=>"$aref->[1]", 
					src=>"$nmiscgi_script?file=$conf&type=drawgraph&node=$node&graph=$aref->[2]&glamount=$glamount&glunits=$glunits&start=0&end=0&width=350&height=50&title=small"})));
	}
}

sub displayPDdata {

	my %NBARPDdata = readVartoHash("nbarpddata");
	my $ni = "$node-$intf";
	my $inrate = "inrate";
	my $outrate = "outrate";
	my $bitrate;
	my $graph_time;

	# default
	$graph = "pie" if $graph eq "";

	print start_table({class=>"white"}) ;
	print start_Tr;
	print th(
			"Graph&nbsp;".
				popup_menu(-name=>"graph",
					-values=>[qw/pie bar chart/],
					-default=>"$graph",
					-onChange=>'JavaScript:this.form.submit()'));


	if ($graph =~ /chart/) {
		runPDdata_chart($ni); ### display chart
	} else {
		### display pie or bar
		my $lastsample = "last sample ".returnDateStamp($NBARPDdata{$ni}{'000'}{lastsample}) if exists $NBARPDdata{$ni}{'000'}{lastsample};
		print th($lastsample).th("Protocol name").th("Inrate").th("Outrate");
		print end_Tr;

		print start_Tr;
		if ($graph eq "pie") {
			print td({rowspan=>"100", align=>"center", valign=>"top"},
					img({alt=>"NMIS Protocol discovery",src=>url()."?file=$conf&func=graph&node=$node&intf=$intf&type=$inrate", border=>"0"}));
			print td({rowspan=>"100", align=>"center", valign=>"top"},
					img({alt=>"NMIS Protocol discovery",src=>url()."?file=$conf&func=graph&node=$node&intf=$intf&type=$outrate", border=>"0"}));
		} elsif ($graph eq "bar") {
			print td({colspan=>"2", rowspan=>"100", align=>"center", valign=>"top"},
					img({alt=>"NMIS Protocol discovery",src=>url()."?file=$conf&func=graph&node=$node&intf=$intf&graph=$graph", border=>"0"}));
		}

		my %sumHash; # sum for sorting
		foreach my $i (keys %{$NBARPDdata{$ni}}) { 
			if ( exists $NBARPDdata{$ni}{$i}{inrate} ){
				$sumHash{$i} = $NBARPDdata{$ni}{$i}{inrate}+$NBARPDdata{$ni}{$i}{outrate};
			}
		}

		# display values of last sample, sorted by sum
		foreach my $i (sort { $sumHash{$b} <=> $sumHash{$a} } keys %sumHash) { 
			print Tr(td("$NBARPDdata{$ni}{$i}{name}"),
					td({align=>"right"},convertIfSpeedx($NBARPDdata{$ni}{$i}{inrate})),
					td({align=>"right"},convertIfSpeedx($NBARPDdata{$ni}{$i}{outrate})));
		}
		print end_Tr;
	}
	print end_table;
}

sub runPDdata_chart {
	my $ni = shift;

	my $time = time;

	if ( $start eq "" ) { $start = $time - (24*3600); } # 24 hour window
	if ( $end eq "" ) { $end = $time; }

	my $window = $end - $start;

	my $sec_start = ($date_start eq "") ? $start : parsedate($date_start) ; # convert string to number seconds
	my $sec_end = ($date_end eq "") ? $end : parsedate($date_end) ;

	# check if date boxes are changed by user
	if ( $start != $sec_start or $end != $sec_end ) {
		$start = $sec_start;
		$end = $sec_end;
	}
	#left, if clicked on graph
	elsif ( $graphx != 0 and $graphx < 150 ) {
		$start -= ($window / $NMIS::config{graph_factor});
		$end = $start + $window;
	}
	#right
	elsif ( $graphx != 0 and $graphx > $width + 94 - 150 ) {
		my $move = $time - ($end + ($window / $NMIS::config{graph_factor}));
		$move = 0 if $move > 0 ;
		$end += ($window / $NMIS::config{graph_factor}) + $move;
		$start = $end - $window;
	}
	#zoom in
	elsif ( $graphx != 0 and ( $graphy != 0 and $graphy <= $height / 2 ) ) {
		$start += ($window / $NMIS::config{graph_factor});
	}
	#zoom out
	elsif ( $graphx != 0 and ( $graphy != 0 and $graphy > $height / 2 ) ) {
		$start -= $window;
	}

	# Stop from drilling into the future!
	$end = $time if $end > $time;
	$start = $time if $start > $time;

	$start = int $start;
	$end = int $end;

	$date_start = returnDateStamp($start); # for display date/time fields
	$date_end = returnDateStamp($end);

	# date time and column name fields
	print th("Start&nbsp;",
				textfield(-name=>"date_start",-value=>"$date_start",-override=>1),
			 "&nbsp;End&nbsp;",
				textfield(-name=>"date_end",-value=>"$date_end",-override=>1),
				submit(-name=>"date",-value=>"View")),
			th("Protocol name"),
			th("Avg Inrate"),
			th("Avg Outrate"),
			end_Tr;
				
	# find the protocol names in the existing database (format ds[name].* )
	my $database = "$NMIS::config{'<nmis_var>'}/nbarpd-$ni.rrd";
	if ( not -r $database ) { print "<td>Waiting for data</td></tr>"; return; }
	my $info = RRDs::info($database);
	my @names;
	foreach my $key (keys %$info) {
		if ( $key =~ /^ds\[([a-zA-Z0-9_-]{1,16})_in\].+/) { 
			my $nm = $1;
			if ($nm ne "" and ! grep /$nm/, @names ) { push @names,"$nm";} 
		}
	}
	# get summary of the protocols
	my %summaryHash; # contains values of protocolname_in and protocolname_out
	my %sumHash; # contains values of protocolname only
	my @options = (	"--start", "$start", "--end", "$end" );
	foreach my $n ( @names ) {
		my $nn = $n;
		$nn =~ s/-//g;
		push @options, "DEF:${nn}in=$database:${n}_in:AVERAGE";
		push @options, "DEF:${nn}out=$database:${n}_out:AVERAGE";
		push @options, "CDEF:${nn}sum=${nn}in,${nn}out,+";
		push @options, "PRINT:${nn}in:AVERAGE:${n}_in=%1.3lf";
		push @options, "PRINT:${nn}out:AVERAGE:${n}_out=%1.3lf";
		push @options, "PRINT:${nn}sum:AVERAGE:${n}=%1.3lf";
	}

	($graphret,$xs,$ys) = RRDs::graph('/dev/null', @options);
	if ($ERROR = RRDs::error) { 
		logMessage("summaryStats, RRD graph error database=$database: $ERROR") unless ($ERROR =~ /without contents/);
	##	logMessage("summaryStats, @names");
	} elsif ( scalar(@$graphret) ) {
		foreach my $line ( @$graphret ) {
			(my $name, my $value) = split "=", $line;
			if ($name =~ /_in$|_out$/) { $summaryHash{"$name"} = int($value); } # separated values
			if ($name !~ /_in$|_out$/) { $sumHash{"$name"} = int($value); } # sum of in and out values
		}
		# sort protocol names on sum of bitrates (in + out)
		my @sorted = sort {$sumHash{$b}<=>$sumHash{$a}} keys %sumHash;

		my $top10;
		if ($item ne "") {
			$top10 = $item; # single protocol name from ancher
		} else {
			#select top 10 protocol names
			my $cnt = 0;
			foreach my $n (@sorted) {
				last if $cnt++ >= 10;
				if ($sumHash{${n}} != 0) {
					if ($top10 eq "") { $top10 = $n;} else { $top10 .= ":$n";}
				}
			}
		}
		if ($top10 eq "") { print td("Waiting for data"),end_Tr; return; }
		my $numrows = 1; # count num of rows to display in table
		foreach my $n ( keys %sumHash) { $numrows++ if ($sumHash{${n}} != 0) }

		# image
		print hidden(-name=>'item', -default=>$top10, -override=>'1'),
				Tr(td({colspan=>"2",rowspan=>"$numrows",align=>"center",valign=>"top"},
					image_button(-name=>"graph",-src=>url()."?file=$conf&func=graph&node=$node&graph=$graph&start=$start&end=$end&intf=$intf&item=$top10&dummy=test")));

		if (%sumHash) {
			my $bitrate;
			my $sum_in = 0;
			my $sum_out = 0;
			# display protocol names and values
			foreach my $n (sort {$sumHash{$b}<=>$sumHash{$a}} keys %sumHash) { 
				if ( $sumHash{${n}} != 0) {
					$sum_in += $summaryHash{"${n}_in"};
					$sum_out += $summaryHash{"${n}_out"};
					print Tr(td(a({href=>url()."?file=$conf&view=true&node=$node&graph=$graph&start=$start&end=$end&date_start=$date_start&date_end=$date_end&intf=$intf&item=$n"},$n)),
							td({align=>"right"},convertIfSpeedx($summaryHash{"${n}_in"})),
							td({align=>"right"},convertIfSpeedx($summaryHash{"${n}_out"})));
				}
			}
			# print totals
			print Tr(th({colspan=>"2",align=>"center"},"Clickable graphs: Left -> Back; Right -> Forward; Top Middle -> Zoom In; Bottom Middle-> Zoom Out, in time"),
					th({align=>"left"},"Total"),
					th({align=>"rigth"},convertIfSpeedx($sum_in)),
					th({align=>"rigth"},convertIfSpeedx($sum_out)));
		}
	} else {
		print td("Waiting for data"),end_Tr; 
	}
}


sub convertIfSpeedx {
	my $ifSpeed = shift;

	$ifSpeed = int($ifSpeed);
	if ( $ifSpeed eq "" ) { $ifSpeed = "N/A" }
#	elsif ( $ifSpeed == 0 ) { $ifSpeed = "N/A" }
	elsif ( $ifSpeed < 2000000 ) { $ifSpeed = $ifSpeed / 1000 ." Kbps" }
	elsif ( $ifSpeed < 1000000000 ) { $ifSpeed = $ifSpeed / 1000000 ." Mbps" }
	elsif ( $ifSpeed >= 1000000000 ) { $ifSpeed = $ifSpeed / 1000000000 ." Gbps" }

	return $ifSpeed;
}

# generate pie, bar or chart
sub displayPDgraph {

	my @pd_data;
	my @pd_name;
	my @pd_inrate;
	my @pd_outrate;
	my $pd_graph;
	my %NBARPDdata = readVartoHash("nbarpddata");
	my $ni = "$node-$intf"; # key for hash

	if ($graph eq "" or $graph eq "pie" or $graph eq "bar") {
		# sort on sum of values
		my %sumHash;
		my $sumCnt;
		foreach my $i (keys %{$NBARPDdata{$ni}}) { 
			$sumHash{$i} = $NBARPDdata{$ni}{$i}{inrate}+$NBARPDdata{$ni}{$i}{outrate} if exists $NBARPDdata{$ni}{$i}{inrate};
			++$sumCnt;
		}

		# get values in arrays
		foreach my $i (sort { $sumHash{$b} <=> $sumHash{$a} } keys %sumHash) { 
			push @pd_name, "$NBARPDdata{$ni}{$i}{name}" ;
			push @pd_inrate, "$NBARPDdata{$ni}{$i}{inrate}" ;
			push @pd_outrate, "$NBARPDdata{$ni}{$i}{outrate}" ;
		}

		if ($graph eq "" or $graph eq "pie") {
			# create array for inrate and outrate
			if ($type eq "inrate") { @pd_data = ([@pd_name],[@pd_inrate]); } else { @pd_data = ([@pd_name],[@pd_outrate]); }
			# create structure
			$pd_graph = new GD::Graph::pie(250,250);
			# configure
			$pd_graph->set(  label => ucfirst $type, axislabelclr => 'black', pie_heigth => 36, '3d' => 0,
					dclrs => [qw(lred lblue lyellow lpurple cyan lorange green orange blue marine)],
					l_margin => 15, r_margin => 15, start_angle => 90, suppress_angle => 5, transparant => 0 ) ;
		} elsif ($graph eq "bar") {
			# create array for GD
			@pd_data = ([@pd_name],[@pd_inrate],[@pd_outrate]);
			# create structure
			$pd_graph = new GD::Graph::hbars(600,($sumCnt < 12) ? 300 : 300+(($sumCnt-12)*10));
			# configure
			$pd_graph->set( x_label => 'Protocol', y_label => 'Bitrate', long_ticks => 1, bar_spacing => 3,
					shadow_depth => 2, accent_theshold => 200, transparent => 0); 
			$pd_graph->set_legend('Inrate','Outrate');
		}

		$pd_graph->plot(\@pd_data); 

		# send graph to webclient
		my $ext = $pd_graph->export_format;
		select((select(STDOUT), $| = 1)[0]);
		print "Content-type: image/gif\n\n";
		print $pd_graph->gd->$ext;
		select((select(STDOUT), $| = 0)[0]);	# unbuffer stdout
	}
	if ($graph eq "chart") {

		my @items = split(/\:/,$item);
		my $ttl = "Top 10";
		$ttl = $item if (scalar(@items) == 1);
		my $database = "$NMIS::config{'<nmis_var>'}/nbarpd-${node}-${intf}.rrd";

		my @colors = ("880088","00CC00","0000CC","CC00CC","FFCC00","00CCCC",
			"000044","BBBB00","BB00BB","00BBBB");

		my $datestamp_start = returnDateStamp($start);
		my $datestamp_end = returnDateStamp($end);

		my @options = (
			"--title", "$ttl from $datestamp_start to $datestamp_end",
			"--vertical-label", "In(-) Out(+) Avg bps",
			"--start", "$start",
			"--end", "$end",
			"--width", "$width",
			"--height", "$height",
			"--imgformat", "PNG",
			"--interlace");

		foreach my $n (@items) {
			my $color = shift @colors;
			my $nn = $n;
			$nn =~ s/-// ; # RRD dont like minus signs
			push @options,"DEF:${nn}_in=$database:${n}_in:AVERAGE" ;
			push @options,"DEF:${nn}_out=$database:${n}_out:AVERAGE" ;
			push @options,"CDEF:${nn}_inx=${nn}_in,-1,*" ;
			push @options,"LINE1:${nn}_inx#$color:${n}" ;
			push @options,"LINE1:${nn}_out#$color" ;
		}
		# buffer stdout to avoid Apache timing out on the header tag while waiting for the PNG image stream from RRDs
		select((select(STDOUT), $| = 1)[0]);
		print "Content-type: image/png\n\n";
		my ($graphret,$xs,$ys) = RRDs::graph('-', @options);
		select((select(STDOUT), $| = 0)[0]);			# unbuffer stdout

		if ($ERROR = RRDs::error) {
			logMessage("NBARPD: RRDgraph $database Graphing Error: $ERROR");
		}
	}
}


