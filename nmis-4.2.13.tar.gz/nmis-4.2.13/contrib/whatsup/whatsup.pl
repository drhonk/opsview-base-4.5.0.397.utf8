#!/usr/bin/perl
#
#    whatsup.pl - NMIS CGI Program - Network Mangement Information System
#    Copyright (C) 2000,2001 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#	Displays a raw summary of nmiscgi.pl status for use in web scripts	
#*****************************************************************************
#
# whatsup.css style sheet assumed to be in the $NMIS::config{styles} directory.
#
#****** Shouldn't be anything else to customise below here *******************

require 5;
use strict;

# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl";

use web;
use func;
use NMIS;

# This reads in the information sent when the user pressed Submit
my %FORM = getCGIForm($ENV{'QUERY_STRING'});

# Allow program to use other configuration files
my $conf;
if ( $FORM{file} ne "" ) { $conf = $FORM{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

my %groupSummary;
my $group;

# populate the %NMIS::groupTable
loadNodeDetails;
loadEventStateNoLock;
loadEventStateSlave;

print <<EO_HTML;

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <META HTTP-EQUIV="REFRESH" CONTENT="60">
  <link href="$NMIS::config{'<url_base>'}/whatsup.css" rel="stylesheet" type="text/css">
  <title>$NMIS::config{dash_title}</title>
  <base target="_top">
</head>
<body>
<h1>$NMIS::config{dash_title}</h1>
<div class="center">
  <table class="status">
    <tr>
      <td colspan=3 class="stathead"><a href="http://$NMIS::config{nmis_host}" style="color:white">Home</a></td>
    </tr>
    <tr>
    <tr class="status">
      <th class="status">Map</th>
      <th class="status">Nodes Up</th>
      <th class="status">Nodes Down</th>
    </tr>
EO_HTML

# print each group's status

foreach $group (sort ( keys (%NMIS::groupTable) ) ) {
	%groupSummary = getGroupSummary($group);
	my $href = "http://$NMIS::config{nmis_host}$NMIS::config{'<cgi_url_base>'}/nmiscgi.pl?file=$conf&group=$group";

# set the colors based on status
my $bgcolor = $groupSummary{average}{countdown} ? "statred" : "statgrey" ;

	print <<EO_HTML;
    <tr class="status">
      <td class="statpad"><a href="$href">$group Network Status</a></td>
      <td class="statgrn">$groupSummary{average}{count}</td>
      <td class="$bgcolor">$groupSummary{average}{countdown}</td>
    </tr>
EO_HTML
} # end of print group loop

print <<EO_HTML;
  </table>
</div>
</body>
</html>
EO_HTML

# end