#!/usr/bin/perl
#
#    rancid.pl - NMIS Perl Program - Network Mangement Information System
#    Copyright (C) 2000 Sinclair InterNetworking Services Pty Ltd
#    <nmis@sins.com.au> http://www.sins.com.au/nmis
#
#    This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#*****************************************************************************
#
# written 20 sep 2002 eric.greenwood@imlmnetwork.com
# parse the nmis nodes.csv file and build a rancid router.db file(s)
# using the NMIS group information.
# rancid groups must be pre-defined - or error posted
# test system file for node type - cisco, or catalyst etc.
# 25 Feb 2005 - skip slave nodes that may be present on this master
#
my $qr_skip = qr/XXXX/;					# regx to skip - nodename
my $rancidbase = "/nmis/rancid";		# rancid base directory - assume NMIS groups pre-configured below this
#
#
#****** Shouldn't be anything else to customise below here *******************
#
# run this from the <nmis>/bin directory
# ./rancid.pl [debug=true]
#
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use csv;
use strict;
use func;
use NMIS;

# this imports the LOCK_ *constants (eg. LOCK_UN, LOCK_EX)
use Fcntl qw(:DEFAULT :flock);


# Variables for command line munging
my %nvp = getArguements(@ARGV);

# See if customised config file required.
my $conf;
if ( $nvp{file} ne "" ) { $conf = $nvp{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -r $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

# Set debugging level.
my $debug = setDebug($nvp{debug});

# load node file
my %groupTable;
my $node;
my $group;

#my %nodeTable = &loadCSV($NMIS::config{Nodes_Table},$NMIS::config{Nodes_Key},"\t");
# Load the node file!!!!!!! ( and any slave node records !!)
loadNodeDetails;

my %nodeTable = %NMIS::nodeTable;

foreach $node (keys %nodeTable) {
	if ( ! defined $nodeTable{$node}{node} ) { 
		logMessage("rancid.pl: Bad node record in $NMIS::config{Nodes_Table}");
		($debug) && print "rancid.pl: Bad node record in $NMIS::config{Nodes_Table}";
		next;
	}
	next unless $nodeTable{$node}{rancid} eq 'true';		# skip unless rancid=true
	next if $nodeTable{$node}{slave};						# skip if slave;
	loadSystemFile($node);
	$groupTable{$nodeTable{$node}{group}}{$node} = $NMIS::systemTable{nodeModel};		# build multidimensional hash of groups and nodes.
}
if ($debug) {
	for $group ( keys %groupTable ) {
		print "Group = $group:\n";
		for $node ( keys %{ $groupTable{$group} } ) {
			print "\tNode $node is of type $groupTable{$group}{$node}\n";
		}
	}
}


# for each group, check that a $rancidbase/groupname/router.db files exists.
# if so, lets lock it, truncate it, and update it with all the nodes !
# rancid will compare it, and issue changelog for us.

for $group ( keys %groupTable ) {

	if ( -f "$rancidbase/$group/router.db" ) {

		sysopen(OUTFILE, "$rancidbase/$group/router.db", O_WRONLY | O_CREAT) 
			or warn scalar localtime()." rancid: Couldn't open file $rancidbase/$group/router.db $!\n";
		flock(OUTFILE, LOCK_EX) or warn "can't lock filename: $!";
		truncate(OUTFILE, 0) or warn "can't truncate filename: $!";

		if ($debug) {print "$group\n"; }
		for $node ( sort keys %{ $groupTable{$group} } ) {

			if ( $node =~ $qr_skip ) { next;}		# skip these...

			if ( $groupTable{$group}{$node} =~ /CiscoRouter|CiscoPIX|CatalystIOS/ ) {		# test the NodeModel
				print OUTFILE "$node:cisco:up\n";
				if ($debug) {print "\t$node:cisco:up\n"; }
			}
			if ( $groupTable{$group}{$node} eq "Catalyst5000" ) {
				print OUTFILE "$node:cat5:up\n";
				if ($debug) {print "\t$node:cat5:up\n"; }
			}
		}
	close OUTFILE or warn "can't close filename: $!";
	}
	else {	# no rancid group file exists
		($debug) && print "$rancidbase/$group/router.db not found\n";
		next;
	}
}