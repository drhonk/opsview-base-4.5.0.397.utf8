#!/usr/bin/perl
#*****************************************************************************
# Auto configure to the <nmis-base>/lib and <nmis-base>/files/nmis.conf
use FindBin;
use lib "$FindBin::Bin/../lib";
use lib "/usr/local/rrdtool/lib/perl";

#
#****** Shouldn't be anything else to customise below here *******************

require 5;
use Fcntl qw(:DEFAULT :flock);
use strict;
use web;
use func;
use NMIS;
my $my_data;
my %FORM;
if($ENV{'REQUEST_METHOD'} eq "GET"){
   $my_data = $ENV{'QUERY_STRING'};
}
else {
   my $bytes_read = read(STDIN, $my_data, $ENV{'CONTENT_LENGTH'});
}
my $type = $FORM{type};
my $node = $FORM{node};
my $lnode = $FORM{lnode};
my $link = $FORM{link};
my $debug = $FORM{debug};
my $graphtype = $FORM{graphtype};
my $graphlength = $FORM{graphlength};
my $graphstart = $FORM{graphstart};
my $glamount = $FORM{glamount};
my $glunits = $FORM{glunits};
my $gsamount = $FORM{gsamount};
my $gsunits = $FORM{gsunits};
my $report = $FORM{report};
my $find = $FORM{find};
my $intf = $FORM{intf};
my $health = $FORM{health};
my $length = $FORM{length};
my $sort = $FORM{sort};
my $outage = $FORM{outage};
my $start = $FORM{start};
my $end = $FORM{end};
my $date_start = $FORM{date_start};
my $date_end = $FORM{date_end};
my $change = $FORM{change};
my $group = $FORM{group};
my $menu = $FORM{menu};
my $title = $FORM{title};
my $graphx = $FORM{'graph.x'};
my $graphy = $FORM{'graph.y'};
my $sort1 = $FORM{sort1};
my $sort2 = $FORM{sort2};
my $plugins = $FORM{plugins};
my $ddescr = $FORM{interface};
# Allow program to use other configuration files
my $conf;
if ( $FORM{file} ne "" ) { $conf = $FORM{file}; }
else { $conf = "nmis.conf"; }
my $configfile = "$FindBin::Bin/../conf/$conf";
if ( -f $configfile ) { loadConfiguration($configfile); }
else { die "Can't access configuration file $configfile.\n"; }

# default graph length is 48 hours
# gl = graph length
# gs = graph start
if ( $glamount eq "" ) { $glamount = $NMIS::config{graph_amount}; }
if ( $glunits eq "" ) { $glunits = $NMIS::config{graph_unit}; }
if ( $gsamount eq "" ) { $gsamount = $NMIS::config{graph_amount}; }
if ( $gsunits eq "" ) { $gsunits = $NMIS::config{graph_unit}; }
my $win_width = $NMIS::config{graph_width} + 128;
#if ( $win_width < 800 ) { $win_width = 800; }
my $win_height = $NMIS::config{graph_height} + 235;

my @event_group = ();           # events
my @event_ack = ();                     # events
my @node_list = ();                     # outages
my @pairs = split(/&/, $my_data);
foreach (@pairs) {
    my ($name, $value) = split(/=/, $_);
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
        # handle the event group multiselect box
    if ($name eq "event_group") {
        push(@event_group, $value);
    }
        elsif ($name eq "event_ack") {
        push(@event_ack, $value);
        }
        elsif ($name eq "node_list") {
        push(@node_list, $value);
        }
        else {
                $FORM{$name} = $value;
        }
}


my $tmpurl;


#### Code starts here - above is standard nmiscgi.pl stuff

# if no form, post the input form and exit

if ( ! %FORM ) {
	print <<EO_HTML;

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Traceroute analyser output</title>
</head>

<body>

<form method="POST" name="tracert" action="$ENV{SCRIPT_NAME}">
  <p><textarea rows="30" name="tracertdetails" cols="40"></textarea></p>
  <p><input type="submit" value="Submit" name="B1"><input type="reset" value="Reset" name="B2"></p>
</form>

</body>

</html>
EO_HTML

exit;
}




# populate the %NMIS::groupTable
&loadNodeDetails;

$_=$FORM{tracertdetails};
my @test = m/((?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))/g;
my %seen;
%seen = ();
my $hop;
print <<EO_HTML;

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta name="GENERATOR" content="Microsoft FrontPage 5.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title>Traceroute analyser output</title>
</head>

<body>

<p>Traceroute details</p>
<table border="1" cellspacing="1" style="border-collapse: collapse" bordercolor="#C0C0C0"  id="AutoNumber1">

EO_HTML
loadInterfaceInfo;
my $intHash;
foreach $hop (@test) {
	if ($seen{$hop} eq ""){
	#### gotta find that hop!
	$seen{$hop}=$hop . "  is not known to NMIS";
$tmpurl="";
                foreach $intHash (sort(keys(%NMIS::interfaceInfo))) {
		if ( $NMIS::interfaceInfo{$intHash}{ipAdEntAddr} eq $hop) {
			if ( $NMIS::interfaceInfo{$intHash}{collect} eq "true" ) {
#		$seen{$hop}="found it" . $NMIS::interfaceInfo{$intHash}{ipAdEntAddr};
$tmpurl="nmiscgi.pl?file=$conf&amp;node=$NMIS::interfaceInfo{$intHash}{node}&amp;type=graph&amp;graphtype=$NMIS::config{portstats}&amp;glamount=$glamount&amp;glunits=$glunits&amp;intf=$NMIS::interfaceInfo{$intHash}{ifIndex}";
$seen{$hop}="<a href=\"$tmpurl\" ><img border=\"0\" alt=\"Device Port\" src=\"nmiscgi.pl?file=$conf&amp;type=drawgraph&amp;node=$NMIS::interfaceInfo{$intHash}{node}&amp;graph=$NMIS::config{portstats}&amp;glamount=$glamount&amp;glunits=$glunits&amp;start=0&amp;end=0&amp;width=500&amp;height=46&amp;title=short&amp;intf=$NMIS::interfaceInfo{$intHash}{ifIndex}\"></a>";
$tmpurl="<a href=\"nmiscgi.pl?file=$conf&amp;type=summary&amp;node=$NMIS::interfaceInfo{$intHash}{node}\">$NMIS::interfaceInfo{$intHash}{node}</a>";
	} else {
$seen{$hop}="No Stats collected for this interface ($NMIS::interfaceInfo{$intHash}{node}   $NMIS::interfaceInfo{$intHash}{ifDescr})";

}

		}
	} 
print <<EO_HTML;
  <tr>
    <td width="120" align="center">$hop</td>
    <td width="120" align="center">$tmpurl</td>
    <td  align="center">$seen{$hop}</td>
  </tr>
EO_HTML
}
}
print <<EO_HTML;
</table>

</body>

</html>
EO_HTML
