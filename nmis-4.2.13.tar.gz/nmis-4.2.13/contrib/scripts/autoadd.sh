#!/bin/sh
#
# To automate adding the nodes to NMIS once they come on line (before go
# live, i.e. the wan interface is hooked up 2 weeks before the ethernet.
# polls a router to find any new /32 addresses in the 172.18.x.x range and adds them to nodes.csv
#
cat nodes.csv | grep 135. | cut -f7 | sort > nodes.nmis
snmpbulkwalk -v 2c -c mycommunity 172.18.1.1 ipRouteMask.172.18 | grep "255.255.255.255" | cut -f1 -d" =" | cut -b42-80 | sort > nodes.cisco
diff nodes.cisco nodes.nmis | grep "<" | cut -b3-20 > nodes.found
cat nodes.found | while read line ; do
echo "true      true    mycommunity        router  MPLS Other      wan	$line   access  false   161" >>nodes.csv
done
