#!/bin/bash
#
# $Id: nmis-space-reclaim.sh,v 1.1 2005/12/16 15:27:44 ibrunello Exp $
#
#
# nmis-space-reclaim.sh
#
# delete stats not touched for a long time.
# just checks for modification time, and delete files older than
# the given number of days
# usage: nmis-space-reclaim.sh <age of> <new-name>
#
# 



# set this to your current NMIS base directory
# (default is /usr/local/nmis)
NMIS_BASE=/usr/local/nmis

# database and var directories are usually subdirectories of the above one
# you can override here
NMIS_DB=$NMIS_BASE/database
NMIS_VAR=$NMIS_BASE/var


# you would not need to change anything below this


if [  $# = 0 ]
then
       echo usage: $0 \<age of files - in days\> ;
       exit 1 ;
fi

cd `echo $NMIS_DB_DIR`/database
find ./ -mtime +$1 -type f -exec rm -rf {} \;

