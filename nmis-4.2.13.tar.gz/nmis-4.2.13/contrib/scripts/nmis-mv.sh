#! /bin/bash
#
# $Id: nmis-mv.sh,v 1.1 2005/12/16 13:50:13 ibrunello Exp $
#
# nmis-mv
# Change NMIS databases name, to reflect node name change.
# usage: nmis-mv <old-name> <new-name>
#
# 



# set this to your current NMIS base directory
# (default is /usr/local/nmis)
NMIS_BASE=/usr/local/nmis

# database and var directories are usually subdirectories of the above one
# you can override here
NMIS_DB=$NMIS_BASE/database
NMIS_VAR=$NMIS_BASE/var


# you would not need to change anything below this


if [  $# = 0 ]
then
       echo usage: $0 old-node-name new-node-name ;
       exit 1 ;
fi
       cd `echo $NMIS_DB_DIR`/database/health
       for i in router switch server generic ; do
               cd $i ;
               rename $1 $2 $1* > /dev/null ;
               cd .. ;
       done

       cd `echo $NMIS_DB_DIR`/database/interface
       for j in router switch server generic ; do
                cd $j ;
                mkdir $2 ;
                chmod 775 $2 ;
                chown nmis.nmis $2 ;
                mv $1/* $2 ;
                cd $2 ;
                rename $1 $2 $1* > /dev/null ;
                cd .. ;
                rmdir $1 ;
                cd .. ;
       done
#
# There also could be a rename of the ./var/*.dat files
# but it is better forcing a "runupdate" on the web interface
#
echo done


