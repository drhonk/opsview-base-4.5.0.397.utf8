#!/usr/bin/perl
#
# $Id: trap2nmis.pl,v 1.1 2005/12/16 15:40:27 ibrunello Exp $
#
# trap2nmis.pl
# 
# snmp trap script to force polling a node when 
# when a trap from that node is received



$hostname = <STDIN>;
chomp($hostname);

$touch_file = "/var/lock/subsys/".$hostname."_nmis_poll";

if(-e $touch_file ){
  exit(0);
}else{
        @touchcmd = ("/bin/touch",$touch_file);
        system(@touchcmd);
        @cmd = ("/nmis/bin/nmis.pl","type=collect","node=$hostname");
        system(@cmd);
        unlink ($touch_file);
}
